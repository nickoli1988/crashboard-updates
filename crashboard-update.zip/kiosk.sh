#!/usr/bin/env bash
# Runs inside X (started by startx from ~/.bash_profile). Shows the board fullscreen.
#   HOST mode:    shows this device's own Crash Board (one panel at a time on small screens)
#   DISPLAY mode: (data/display.conf exists) shows a Crash Board hosted on another device,
#                 in the full PC layout zoomed to fit this screen
APP_DIR="$(cd "$(dirname "$0")" && pwd)"

# WebKit (surf) draws a black window on the Pi unless its GPU paths are switched off
export WEBKIT_DISABLE_DMABUF_RENDERER=1 WEBKIT_DISABLE_COMPOSITING_MODE=1
xset s off; xset -dpms; xset s noblank        # never blank the screen
# Pi Zero / Pi 1-3 on a big TV: 1080p is too heavy for them, so drop the TV to 720p
if { [ "$(uname -m)" = "armv6l" ] || grep -qaE "Raspberry Pi [123]" /proc/device-tree/model 2>/dev/null; } && [ "${CB_KEEP_RES:-0}" = 0 ]; then
  OUT="$(xrandr 2>/dev/null | awk '/ connected/ {print $1; exit}')"
  CUR_W="$(xrandr --current 2>/dev/null | awk '/\*/ {split($1,a,"x"); print a[1]; exit}')"
  if [ -n "$OUT" ] && [ "${CUR_W:-0}" -gt 1280 ] && xrandr 2>/dev/null | grep -q " 1280x720"; then
    xrandr --output "$OUT" --mode 1280x720 && sleep 2
  fi
fi
unclutter -idle 3 -root &                       # hide the mouse pointer when it has not moved for 3 s

# Pi Zero / Pi 1 (armv6l) start with lighter animations; Pi 3 and newer get full effects.
if [ "$(uname -m)" = "armv6l" ]; then FX=low; else FX=full; fi
ZERO=0; [ "$(uname -m)" = "armv6l" ] && ZERO=1

SCALE=1
if [ -f "$APP_DIR/data/display.conf" ]; then
  # ---------------- DISPLAY MODE ----------------
  . "$APP_DIR/data/display.conf"
  LAYOUT_WIDTH="${LAYOUT_WIDTH:-1280}"
  SCREEN_W="$(xrandr --current 2>/dev/null | awk '/\*/ {split($1,a,"x"); print a[1]; exit}')"
  SCREEN_W="${SCREEN_W:-800}"
  # zoom so the page lays out LAYOUT_WIDTH px wide (never zoom in past 100%)
  SCALE="$(awk -v s="$SCREEN_W" -v l="$LAYOUT_WIDTH" 'BEGIN{z=s/l; if(z>1)z=1; printf "%.3f", z}')"
  BOARD="${HOST_URL}/?display=1&fx=${FX}&sound=1"
  ENC="$(python3 -c 'import sys,urllib.parse as u;print(u.quote(sys.argv[1],safe=""))' "$BOARD")"
  HOSTENC="$(python3 -c 'import sys,urllib.parse as u;print(u.quote(sys.argv[1],safe=""))' "$HOST_URL")"
  # local "connecting..." page: opens the board the moment the host answers
  URL="file://$APP_DIR/static/waiting.html?host=${HOSTENC}&target=${ENC}"
  echo "display: host=$HOST_URL screen=${SCREEN_W}px zoom=$SCALE"
else
  # ---------------- HOST MODE ----------------
  PORT="${CRASHBOARD_PORT:-8080}"
  sleep 3
  [ -f "$APP_DIR/data/port.txt" ] && PORT="$(cat "$APP_DIR/data/port.txt")"   # server may have moved off a busy port
  URL="http://127.0.0.1:${PORT}/?fx=${FX}&dwell=15&sound=1"   # full board on TVs, one panel at a time on small screens
  [ -f "$APP_DIR/data/slideshow" ] && URL="${URL}&kiosk=1"   # hands-off TV: rotate one panel at a time
  for i in $(seq 1 60); do                       # wait for the local server
    python3 -c "import urllib.request;urllib.request.urlopen('http://127.0.0.1:${PORT}/api/state',timeout=2)" 2>/dev/null && break
    sleep 2
  done
  # SD-card image, first start: show the setup instructions until the phone setup is done
  if [ -f /etc/crashboard-image ] && [ ! -f "$APP_DIR/data/setup-done.json" ]; then
    # (only if the setup helper answers, otherwise go straight to the board)
    for i in $(seq 1 30); do
      if python3 -c "import urllib.request;urllib.request.urlopen('http://127.0.0.1/api/status',timeout=2)" 2>/dev/null; then
        NEXT="$(python3 -c 'import sys,urllib.parse as u;print(u.quote(sys.argv[1],safe=""))' "$URL")"
        URL="http://127.0.0.1/screen?next=${NEXT}"; break
      fi
      sleep 2
    done
  fi
fi

# Pi 3 and older: Chromium's GPU path often gives a plain black screen, so draw in software there.
GPUFLAGS="--disable-gpu-compositing"
if grep -qa "Raspberry Pi [123]" /proc/device-tree/model 2>/dev/null; then GPUFLAGS="--disable-gpu --disable-gpu-compositing"; fi

# With no desktop on the Pi, Chromium doesn't know the screen size and opens smaller than the TV.
# Tell it the exact size and put it in the top-left corner.
SCR="$(xrandr --current 2>/dev/null | awk '/current/ {gsub(",","",$10); print $8 "," $10; exit}')"
case "$SCR" in [0-9]*,[0-9]*) ;; *) SCR="$(cat /sys/class/graphics/fb0/virtual_size 2>/dev/null)";; esac
case "$SCR" in [0-9]*,[0-9]*) ;; *) SCR="1280,720";; esac
WINFLAGS="--window-position=0,0 --window-size=$SCR --start-fullscreen"

# ---- sound: Pi OS Lite plays sound on the headphone jack by default. Send it to the TV (HDMI) instead,
# unless data/audio-jack exists. Only when no desktop sound system is installed, and never over your own .asoundrc.
CARD=""
if [ -r /proc/asound/cards ] && ! command -v pipewire >/dev/null && ! command -v pulseaudio >/dev/null; then
  HDMI_CARD="$(sed -n 's/^ *[0-9]* \[\(vc4hdmi[0-9]*\) *\].*/\1/p' /proc/asound/cards | head -1)"
  JACK_CARD="$(sed -n 's/^ *[0-9]* \[\(Headphones\) *\].*/\1/p' /proc/asound/cards | head -1)"
  CARD="$HDMI_CARD"; [ -f "$APP_DIR/data/audio-jack" ] && [ -n "$JACK_CARD" ] && CARD="$JACK_CARD"
  if [ -n "$CARD" ] && { [ ! -f "$HOME/.asoundrc" ] || grep -q "crashboard" "$HOME/.asoundrc"; }; then
    # sysdefault:CARD= is the card's own setup (the TV output needs IEC958 frames, which it handles).
    # (not default:CARD=, which would point back at this file's own default and fail)
    printf '# crashboard: sound output (made by kiosk.sh)\npcm.!default {\n  type plug\n  slave.pcm "sysdefault:CARD=%s"\n}\nctl.!default {\n  type hw\n  card %s\n}\n' "$CARD" "$CARD" > "$HOME/.asoundrc"
  fi
fi

# ---- Pi screen check: keep logs, and if the browser stays black or keeps crashing, switch this Pi
# to the light screen (data/use-fb). The start-up hook in ~/.bash_profile then draws the board directly.
LOGD="$APP_DIR/data"; mkdir -p "$LOGD"
BLOG="$LOGD/browser.log"; : > "$BLOG"
{ echo "$(date)  start  url=$URL"
  echo "model: $(tr -d '\0' </proc/device-tree/model 2>/dev/null)   flags: $GPUFLAGS $WINFLAGS"
  xrandr --current 2>/dev/null | head -3; free -m
  echo "sound cards:"; cat /proc/asound/cards 2>/dev/null; echo "sound output: ${CARD:-system default}"; } >> "$BLOG" 2>&1
# one short beep through the sound system at start-up, using libasound directly; the result goes in the log
if [ ! -f "$LOGD/no-start-beep" ]; then
  ( sleep 20; python3 - >> "$BLOG" 2>&1 <<'PYB'
import ctypes, ctypes.util, math, struct
print("start beep (ALSA 'default'):", end=" ")
try:
    a = ctypes.CDLL(ctypes.util.find_library("asound") or "libasound.so.2")
    a.snd_strerror.restype = ctypes.c_char_p
    h = ctypes.c_void_p()
    r = a.snd_pcm_open(ctypes.byref(h), b"default", 0, 0)
    if r < 0: raise RuntimeError("open: %s" % a.snd_strerror(r).decode())
    # S16_LE = 2, RW_INTERLEAVED = 3, 2 channels, 48 kHz, soft resample, 0.5 s latency
    r = a.snd_pcm_set_params(h, 2, 3, 2, 48000, 1, 500000)
    if r < 0: raise RuntimeError("set_params: %s" % a.snd_strerror(r).decode())
    n = 48000 * 4 // 10
    buf = b"".join(struct.pack("<hh", v, v) for v in (int(9000 * math.sin(2 * math.pi * 880 * i / 48000)) for i in range(n)))
    r = a.snd_pcm_writei(h, buf, n)
    if r < 0: raise RuntimeError("write: %s" % a.snd_strerror(r).decode())
    a.snd_pcm_drain(h); a.snd_pcm_close(h)
    print("played OK (%d frames)" % r)
except Exception as e:
    print("FAILED -", e)
PYB
  ) &
fi
for XL in "$HOME/.local/share/xorg/Xorg.0.log" /var/log/Xorg.0.log; do [ -f "$XL" ] && { cp "$XL" "$LOGD/xorg.log"; break; }; done
PI_OLD=0; grep -qaE "Raspberry Pi ([123]|Zero)" /proc/device-tree/model 2>/dev/null && PI_OLD=1
fallback() {
  echo "$(date)  SWITCHING TO THE LIGHT SCREEN: $1" | tee -a "$BLOG" > "$LOGD/browser-check.txt"
  rm -f "$LOGD/use-browser"; touch "$LOGD/use-fb"
  kill 0            # ends this screen session; the start-up hook then starts the light screen
}
if [ $PI_OLD = 1 ] && [ ! -f "$LOGD/no-screen-check" ]; then
  ( sleep 150
    python3 - "$LOGD/screen-check.png" >> "$BLOG" 2>&1 <<'PYCHK'
import os, sys
try:
    from PIL import ImageGrab
    im = ImageGrab.grab(xdisplay=os.environ.get("DISPLAY", ":0")).convert("RGB")
except Exception as e:
    print("screen-check: no screenshot (%s)" % e); sys.exit(0)
im.resize((max(1, im.width // 2), max(1, im.height // 2))).save(sys.argv[1])
g = im.convert("L"); h = g.histogram()
lit = sum(h[60:]) / float(g.width * g.height)
print("screen-check: %dx%d, lit pixels %.3f%%" % (im.width, im.height, lit * 100))
sys.exit(3 if lit < 0.002 else 0)
PYCHK
    [ $? = 3 ] && fallback "the browser screen was still black after 2.5 minutes"
  ) &
fi
# No window manager on the SD-card image, so browsers ignore "fullscreen" and open at their default size
# (surf: 800x600). Keep the board's window stretched to the whole screen.
pkill -f "setup/xfit.py" 2>/dev/null
python3 "$APP_DIR/setup/xfit.py" >> "$LOGD/xfit.log" 2>&1 &
FAST=0

while true; do
  [ -f "$BLOG" ] && [ "$(stat -c %s "$BLOG")" -gt 2000000 ] && { tail -c 500000 "$BLOG" > "$BLOG.tmp"; mv "$BLOG.tmp" "$BLOG"; }
  T_START=$(date +%s)
  START=$(date +%s)
  if command -v chromium-browser >/dev/null && [ $ZERO = 0 ]; then
    chromium-browser --kiosk --noerrdialogs --disable-infobars --incognito \
      --autoplay-policy=no-user-gesture-required --allow-file-access-from-files \
      --force-device-scale-factor="$SCALE" \
      --disable-features=Translate --check-for-update-interval=31536000 \
      $GPUFLAGS $WINFLAGS --alsa-output-device=default --overscroll-history-navigation=0 "$URL" >> "$BLOG" 2>&1
  elif command -v chromium >/dev/null && [ $ZERO = 0 ]; then
    chromium --kiosk --noerrdialogs --disable-infobars --incognito \
      --autoplay-policy=no-user-gesture-required --allow-file-access-from-files \
      --force-device-scale-factor="$SCALE" --disable-features=Translate \
      --check-for-update-interval=31536000 $GPUFLAGS $WINFLAGS --alsa-output-device=default --overscroll-history-navigation=0 "$URL" >> "$BLOG" 2>&1
  else
    # surf (Pi Zero): -z sets the zoom level. Older surf builds without -z exit at once,
    # so fall back to plain fullscreen if that happens.
    if [ "$SCALE" != "1" ] && [ "${SURF_NOZOOM:-0}" = 0 ]; then
      surf -F -z "$SCALE" "$URL"
      [ $(( $(date +%s) - START )) -lt 5 ] && SURF_NOZOOM=1
    else
      surf -F "$URL"            # fullscreen WebKit browser (light enough for Pi Zero W)
    fi
  fi
  echo "$(date)  browser closed after $(( $(date +%s) - T_START )) s" >> "$BLOG"
  if [ $(( $(date +%s) - T_START )) -lt 30 ]; then FAST=$((FAST+1)); else FAST=0; fi
  [ $PI_OLD = 1 ] && [ $FAST -ge 4 ] && fallback "the browser crashed 4 times in a row"
  sleep 3                   # browser crashed or was closed: relaunch
done
