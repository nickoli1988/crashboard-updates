#!/data/data/com.termux/files/usr/bin/bash
pkill -f "python server.py" && echo "Crash Board stopped." || echo "Crash Board was not running."
termux-wake-unlock 2>/dev/null || true
