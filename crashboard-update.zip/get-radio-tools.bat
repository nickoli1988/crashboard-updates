@echo off
REM Crash Board RADIO: downloads the RTL-SDR Blog tools (rtl_fm, rtl_power, rtl_test) into tools\rtl-sdr
REM and opens Zadig so you can give the SDR stick the WinUSB driver. Run it once, with the stick plugged in.
title Crash Board - radio tools
cd /d "%~dp0"
echo.
echo  Downloading the RTL-SDR Blog tools...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference='Stop'; [Net.ServicePointManager]::SecurityProtocol='Tls12';" ^
  "$r = Invoke-RestMethod 'https://api.github.com/repos/rtlsdrblog/rtl-sdr-blog/releases/latest';" ^
  "$a = $r.assets | Where-Object { $_.name -like '*.zip' } | Select-Object -First 1;" ^
  "if (-not $a) { throw 'No download found on the RTL-SDR Blog release page' };" ^
  "$tmp = Join-Path $env:TEMP 'cb-rtlsdr'; Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue; New-Item -ItemType Directory $tmp | Out-Null;" ^
  "Invoke-WebRequest $a.browser_download_url -OutFile (Join-Path $tmp 'r.zip');" ^
  "Expand-Archive (Join-Path $tmp 'r.zip') $tmp -Force;" ^
  "$fm = Get-ChildItem $tmp -Recurse -Filter rtl_fm.exe | Sort-Object { if ($_.FullName -match 'x64') {0} else {1} } | Select-Object -First 1;" ^
  "if (-not $fm) { throw 'rtl_fm.exe not found in the download' };" ^
  "New-Item -ItemType Directory 'tools\rtl-sdr' -Force | Out-Null;" ^
  "Copy-Item (Join-Path $fm.DirectoryName '*') 'tools\rtl-sdr' -Force;" ^
  "Write-Host ('  Installed from ' + $a.name + ' into tools\rtl-sdr');"
if errorlevel 1 (
  echo.
  echo  The download failed. Check the internet connection and try again, or download Release.zip from
  echo  https://github.com/rtlsdrblog/rtl-sdr-blog/releases and copy the x64 folder's files into tools\rtl-sdr
  pause
  exit /b 1
)
echo.
echo  Downloading Zadig (USB driver tool)...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference='Stop'; [Net.ServicePointManager]::SecurityProtocol='Tls12';" ^
  "$r = Invoke-RestMethod 'https://api.github.com/repos/pbatard/libwdi/releases/latest';" ^
  "$a = $r.assets | Where-Object { $_.name -like 'zadig*.exe' } | Select-Object -First 1;" ^
  "Invoke-WebRequest $a.browser_download_url -OutFile 'tools\zadig.exe';"
echo.
echo  =====================================================================
echo   ZADIG IS OPENING. With the SDR stick plugged in:
echo     1. Click Options, then tick "List All Devices"
echo     2. In the drop-down pick "Bulk-In, Interface (Interface 0)"
echo        (or "RTL2838UHIDIR")
echo     3. Make sure the box on the right says WinUSB
echo     4. Click "Replace Driver" (or "Install Driver") and wait
echo   Then close Zadig, restart Crash Board, and open the RADIO page.
echo  =====================================================================
if exist "tools\zadig.exe" start "" "tools\zadig.exe"
pause
