"""
CRASH BOARD regional data: local alerts, wildfires and drought outside the US.

  Canada ........ Environment Canada alerts · CWFIS active fires · Canadian Drought Monitor
  UK & Europe ... MeteoAlarm (≈38 countries) · Environment Agency floods (England) · NASA FIRMS
  Australia ..... Bureau of Meteorology warnings (personal use only, opt-in) · NSW RFS · NASA FIRMS
  New Zealand ... MetService warnings · NASA FIRMS
  Anywhere ...... NASA FIRMS satellite fire detections

Every function returns the same shapes the board already uses, so the panels don't care
which country the data came from. Helpers (fetch, XML tools...) are passed in by server.py.
"""
import csv
import io
import math
import re
import time

H = None   # helpers from server.py, set by bind()


def bind(**helpers):
    global H

    class _H:
        pass
    H = _H()
    for k, v in helpers.items():
        setattr(H, k, v)


# ---------------------------------------------------------------- countries
# code: (name, meteoalarm feed slugs to try, FIRMS region)
EU = "Europe"
COUNTRIES = {
    "US": ("United States", None, "USA_contiguous_and_Hawaii"),
    "CA": ("Canada", None, "Canada"),
    "GB": ("United Kingdom", ["united-kingdom"], EU),
    "IE": ("Ireland", ["ireland"], EU),
    "AU": ("Australia", None, "Australia_NewZealand"),
    "NZ": ("New Zealand", None, "Australia_NewZealand"),
    "AT": ("Austria", ["austria"], EU), "BE": ("Belgium", ["belgium"], EU),
    "BA": ("Bosnia and Herzegovina", ["bosnia-herzegovina", "bosnia-and-herzegovina"], EU),
    "BG": ("Bulgaria", ["bulgaria"], EU), "HR": ("Croatia", ["croatia"], EU), "CY": ("Cyprus", ["cyprus"], EU),
    "CZ": ("Czechia", ["czechia", "czech-republic"], EU), "DK": ("Denmark", ["denmark"], EU),
    "EE": ("Estonia", ["estonia"], EU), "FI": ("Finland", ["finland"], EU), "FR": ("France", ["france"], EU),
    "DE": ("Germany", ["germany"], EU), "GR": ("Greece", ["greece"], EU), "HU": ("Hungary", ["hungary"], EU),
    "IS": ("Iceland", ["iceland"], EU), "IL": ("Israel", ["israel"], EU), "IT": ("Italy", ["italy"], EU),
    "LV": ("Latvia", ["latvia"], EU), "LT": ("Lithuania", ["lithuania"], EU), "LU": ("Luxembourg", ["luxembourg"], EU),
    "MT": ("Malta", ["malta"], EU), "MD": ("Moldova", ["moldova", "republic-of-moldova"], EU),
    "ME": ("Montenegro", ["montenegro"], EU), "NL": ("Netherlands", ["netherlands"], EU),
    "MK": ("North Macedonia", ["republic-of-north-macedonia", "north-macedonia", "macedonia"], EU),
    "NO": ("Norway", ["norway"], EU), "PL": ("Poland", ["poland"], EU), "PT": ("Portugal", ["portugal"], EU),
    "RO": ("Romania", ["romania"], EU), "RS": ("Serbia", ["serbia"], EU), "SK": ("Slovakia", ["slovakia"], EU),
    "SI": ("Slovenia", ["slovenia"], EU), "ES": ("Spain", ["spain"], EU), "SE": ("Sweden", ["sweden"], EU),
    "CH": ("Switzerland", ["switzerland"], EU), "UA": ("Ukraine", ["ukraine"], EU),
    "MX": ("Mexico", None, "Central_America"), "BR": ("Brazil", None, "South_America"),
    "ZA": ("South Africa", None, "Southern_Africa"), "IN": ("India", None, "South_Asia"),
    "JP": ("Japan", None, "Russia_Asia"), "PH": ("Philippines", None, "SouthEast_Asia"),
}
# countries whose postcodes zippopotam.us can look up
POSTCODE_CC = {"US", "CA", "GB", "AU", "NZ", "DE", "FR", "ES", "IT", "NL", "BE", "AT", "CH", "DK", "SE", "NO", "FI",
               "PL", "PT", "CZ", "SK", "HU", "IE", "LU", "MX", "BR", "ZA", "IN", "JP", "PH", "HR", "SI", "BG", "RO"}
AU_STATE_FEEDS = {"new south wales": "IDZ00054", "australian capital territory": "IDZ00054", "victoria": "IDZ00059",
                  "queensland": "IDZ00056", "western australia": "IDZ00060", "south australia": "IDZ00057",
                  "tasmania": "IDZ00058", "northern territory": "IDZ00055"}
SEV_RANK = {"Extreme": 4, "Severe": 3, "Moderate": 2, "Minor": 1, "Unknown": 0}


def country_list():
    return sorted(((c, v[0]) for c, v in COUNTRIES.items()), key=lambda x: (x[0] != "US", x[1]))


def group(cc):
    cc = (cc or "").upper()
    if cc in ("US", "PR", "GU", "VI", "AS", "MP"):
        return "us"
    if cc == "CA":
        return "ca"
    if cc in ("AU",):
        return "au"
    if cc == "NZ":
        return "nz"
    if cc in COUNTRIES and COUNTRIES[cc][1]:
        return "eu"
    return "other"


# ---------------------------------------------------------------- geocoding
def geocode(q, cc=None):
    """Postcode (any supported country), 'City' or 'City, Region', or 'lat, lon'.
    Returns the location record the board stores, including region names for matching alerts."""
    q = (q or "").strip()
    cc = (cc or "").upper()
    if cc in ("", "AUTO"):
        cc = ""
    m = re.match(r"^\s*(-?\d+(?:\.\d+)?)\s*[, ]\s*(-?\d+(?:\.\d+)?)\s*$", q)
    if m:
        lat, lon = float(m.group(1)), float(m.group(2))
        guess = cc or ("US" if (18 < lat < 72 and -180 < lon < -64 and not (lat > 49.5 and lon > -141)) else "")
        return {"query": q, "name": "%.3f, %.3f" % (lat, lon), "lat": lat, "lon": lon, "country": guess, "areas": []}
    looks_post = bool(re.match(r"^[A-Za-z0-9][A-Za-z0-9 \-]{1,9}$", q)) and any(ch.isdigit() for ch in q)
    if looks_post and (cc or "US") in POSTCODE_CC:
        pcc = cc or "US"
        code = q.upper().replace(" ", "")
        if pcc == "CA":
            code = code[:3]                                    # Canada: first 3 characters (FSA)
        elif pcc == "GB":
            code = q.upper().split()[0] if " " in q.strip() else code[:-3] if len(code) > 4 else code
        try:
            d = H.fetch_json("https://api.zippopotam.us/%s/%s" % (pcc.lower(), code))
            p = d["places"][0]
            st = p.get("state") or ""
            return {"query": q, "name": "%s, %s" % (p["place name"], p.get("state abbreviation") or st or pcc),
                    "lat": float(p["latitude"]), "lon": float(p["longitude"]), "country": pcc,
                    "admin1": st, "areas": [x for x in (p.get("place name"), st) if x]}
        except Exception:
            if pcc == "US" and re.match(r"^\d{5}$", q):
                raise ValueError("ZIP code not found: " + q)
    parts = [x.strip() for x in q.split(",")]
    url = ("https://geocoding-api.open-meteo.com/v1/search?count=10&language=en&format=json&name=" +
           H.quote(parts[0]) + ("&countryCode=" + cc if cc else ""))
    res = H.fetch_json(url).get("results") or []
    if not res:
        raise ValueError("location not found: " + q + (" in " + COUNTRIES.get(cc, (cc,))[0] if cc else ""))
    pick = res[0]
    if len(parts) > 1:
        hint = parts[1].lower()
        for r in res:
            fields = [str(r.get(k, "")).lower() for k in ("admin1", "admin2", "country", "country_code")]
            if any(hint == f or (len(hint) > 2 and hint in f) for f in fields) or \
               H.us_states.get(hint.upper(), "~").lower() == fields[0]:
                pick = r
                break
    name = pick["name"] + (", " + pick["admin1"] if pick.get("admin1") else "")
    if pick.get("country_code") and pick.get("country_code") != "US":
        name += ", " + pick["country_code"]
    areas = [pick.get(k) for k in ("name", "admin4", "admin3", "admin2", "admin1") if pick.get(k)]
    return {"query": q, "name": name, "lat": pick["latitude"], "lon": pick["longitude"],
            "country": pick.get("country_code") or cc, "admin1": pick.get("admin1", ""), "areas": areas}


def _local(text, loc):
    """Does a warning's area text mention this location's town/county/region?"""
    t = (text or "").lower()
    for a in loc.get("areas") or []:
        a = (a or "").lower().strip()
        if len(a) >= 3 and (a in t or (len(t) >= 4 and t in a)):
            return True
    return False


def _alert(id_, event, severity, area, onset=None, expires=None, headline="", description="", instruction="",
           local=True, source=""):
    sev = severity if severity in SEV_RANK else "Unknown"
    return {"id": id_, "event": event, "severity": sev, "urgency": "", "certainty": "", "headline": headline or event,
            "area": area, "onset": onset, "expires": expires, "description": (description or "")[:900],
            "instruction": (instruction or "")[:600], "rank": SEV_RANK.get(sev, 0), "local": local, "source": source}


# ---------------------------------------------------------------- alerts
def alerts(loc, cfg):
    g, cc = group(loc.get("country")), (loc.get("country") or "").upper()
    if g == "ca":
        out, src = _alerts_ca(loc), "ENVIRONMENT CANADA"
    elif g == "eu":
        out, src = _alerts_meteoalarm(loc, cc), "METEOALARM"
        if cc == "GB":
            try:
                out += _floods_england(loc)
                src += " + ENVIRONMENT AGENCY"
            except Exception as e:
                H.log("EA floods:", e)
    elif g == "au":
        if not cfg.get("au_bom"):
            return {"configured": True, "supported": True, "alerts": [], "source": "BUREAU OF METEOROLOGY",
                    "note": "BoM warnings are off. Turn them on in CFG (Bureau of Meteorology allows personal, non-commercial use only)."}
        out, src = _alerts_bom(loc), "BUREAU OF METEOROLOGY"
    elif g == "nz":
        out, src = _alerts_nz(loc), "METSERVICE"
    else:
        name = COUNTRIES.get(cc, (cc or "this location",))[0]
        return {"configured": True, "supported": False, "alerts": [], "source": "",
                "note": "No local warning feed for %s yet. Weather, global disasters, quakes and fire detections still work." % name}
    t = H.now()
    out = [a for a in out if not a.get("expires") or a["expires"] > t]
    out.sort(key=lambda a: (not a["local"], -a["rank"], a["onset"] or 0))
    return {"configured": True, "supported": True, "alerts": out[:40], "source": src}


def _alerts_ca(loc):
    lat, lon = loc["lat"], loc["lon"]
    url = ("https://api.weather.gc.ca/collections/weather-alerts/items?f=json&lang=en&limit=200&bbox=%.4f,%.4f,%.4f,%.4f"
           % (lon - 0.02, lat - 0.02, lon + 0.02, lat + 0.02))
    d = H.fetch_json(url)
    out, seen = [], set()
    for f in d.get("features", []):
        p = f.get("properties") or {}
        status = str(p.get("status_en") or p.get("status") or "").lower()
        if status in ("ended", "cancelled", "terminée", "annulé"):
            continue
        name = (p.get("alert_name_en") or p.get("alert_short_name_en") or p.get("headline_en") or p.get("alert_type") or "ALERT")
        typ = str(p.get("alert_type") or "").lower()
        colour = str(p.get("risk_colour_en") or p.get("risk_colour") or "").lower()
        area = p.get("feature_name_en") or p.get("area_en") or ""
        key = (name.lower(), area.lower())
        if key in seen:
            continue
        seen.add(key)
        sev = ("Extreme" if colour == "red" else "Severe" if (typ == "warning" or colour == "orange")
               else "Moderate" if (typ == "watch" or colour == "yellow") else "Minor")
        out.append(_alert(p.get("id") or f.get("id") or "|".join(key), name.upper() if name.islower() else name, sev, area,
                          onset=H.iso_to_ts(p.get("publication_datetime") or p.get("validity_datetime")),
                          expires=H.iso_to_ts(p.get("expiration_datetime") or p.get("event_end_datetime")),
                          description=H.strip_tags(p.get("alert_text_en") or p.get("text_en") or ""),
                          source="ECCC"))
    return out


_MA_SLUG = {}


def _alerts_meteoalarm(loc, cc):
    slugs = COUNTRIES.get(cc, (None, None))[1] or []
    if cc in _MA_SLUG:
        slugs = [_MA_SLUG[cc]]
    last = None
    for slug in slugs:
        try:
            raw = H.fetch("https://feeds.meteoalarm.org/feeds/meteoalarm-legacy-atom-" + slug)
            _MA_SLUG[cc] = slug
            break
        except Exception as e:
            last, raw = e, None
    if raw is None:
        raise RuntimeError("MeteoAlarm feed unavailable (%s)" % last)
    root = H.ET.fromstring(raw)
    out = []
    for e in root:
        if H.localname(e.tag) != "entry":
            continue
        f = {}
        for c in e:
            n = H.localname(c.tag)
            if n == "link":
                f.setdefault("link", c.get("href"))
            else:
                f[n] = (c.text or "").strip()
        level = f.get("awareness_level", "")
        if level.startswith("1;") or "green" in level.lower():
            continue                                         # green = no warning
        colour = (level.split(";")[1].strip().upper() + " ") if level.count(";") >= 1 else ""
        sev = f.get("severity") or ("Extreme" if "red" in level.lower() else "Severe" if "orange" in level.lower() else "Moderate")
        area = f.get("areaDesc", "")
        event = (f.get("event") or f.get("title") or "WARNING")
        out.append(_alert(f.get("identifier") or f.get("id") or event + area, event.upper(), sev.capitalize(), area,
                          onset=H.iso_to_ts(f.get("onset") or f.get("effective")), expires=H.iso_to_ts(f.get("expires")),
                          headline=(colour + event).upper(), description=f.get("summary") or "",
                          local=_local(area, loc), source="METEOALARM"))
    return out


def _floods_england(loc):
    d = H.fetch_json("https://environment.data.gov.uk/flood-monitoring/id/floods?lat=%.4f&long=%.4f&dist=15"
                     % (loc["lat"], loc["lon"]))
    sev = {1: "Extreme", 2: "Severe", 3: "Moderate"}
    out = []
    for it in d.get("items", []):
        lvl = int(it.get("severityLevel") or 4)
        if lvl not in sev:
            continue
        out.append(_alert(it.get("@id") or it.get("floodAreaID"), (it.get("severity") or "FLOOD WARNING").upper(), sev[lvl],
                          it.get("description") or it.get("eaAreaName") or "", onset=H.iso_to_ts(it.get("timeRaised")),
                          description=it.get("message") or "", source="ENVIRONMENT AGENCY"))
    return out


def _sev_from_words(t):
    u = t.upper()
    if "EMERGENCY" in u or "RED " in u or u.startswith("RED") or "EXTREME" in u or "EVACUAT" in u:
        return "Extreme"
    if "SEVERE" in u or "ORANGE" in u or ("WARNING" in u and "CANCELLATION" not in u):
        return "Severe"
    if "WATCH" in u or "YELLOW" in u or "ADVICE" in u:
        return "Moderate"
    return "Minor"


def _rss_items(raw):
    root = H.ET.fromstring(raw)
    for it in root.iter():
        if H.localname(it.tag) in ("item", "entry"):
            yield it


def _alerts_bom(loc):
    st = (loc.get("admin1") or "").lower()
    code = AU_STATE_FEEDS.get(st)
    if not code:
        for k, v in AU_STATE_FEEDS.items():
            if k in st or st in k:
                code = v
        code = code or "IDZ00054"
    raw = H.fetch("https://www.bom.gov.au/fwo/%s.warnings_%s.xml" % (code, {
        "IDZ00054": "nsw", "IDZ00055": "nt", "IDZ00056": "qld", "IDZ00057": "sa", "IDZ00058": "tas",
        "IDZ00059": "vic", "IDZ00060": "wa"}[code]))
    out = []
    for it in _rss_items(raw):
        title = H.strip_tags(H.ctext(it, "title"))
        if not title or "CANCELLATION" in title.upper() or "FINAL" == title.upper()[:5]:
            continue
        out.append(_alert(H.ctext(it, "guid") or H.ctext(it, "link") or title, title.upper()[:90], _sev_from_words(title),
                          title, onset=H.iso_to_ts(H.ctext(it, "pubDate")), local=True,   # state feed: all relevant
                          source="BOM"))
    return out


def _alerts_nz(loc):
    raw = H.fetch("https://alerts.metservice.com/cap/rss")
    out = []
    for it in _rss_items(raw):
        title = H.strip_tags(H.ctext(it, "title"))
        desc = H.strip_tags(H.ctext(it, "description") or H.ctext(it, "summary"))
        if not title:
            continue
        out.append(_alert(H.ctext(it, "guid") or H.ctext(it, "id") or title, title.upper()[:90], _sev_from_words(title),
                          desc[:160] or title, onset=H.iso_to_ts(H.ctext(it, "pubDate") or H.ctext(it, "updated")),
                          description=desc, local=_local(title + " " + desc, loc), source="METSERVICE"))
    return out


# ---------------------------------------------------------------- wildfires
def fires(loc, cfg):
    g = group(loc.get("country"))
    lat, lon = loc["lat"], loc["lon"]
    list_km = float(cfg.get("fire_list_mi", 100)) * 1.609
    items, srcs, errs = [], [], []
    if g == "ca":
        try:
            items += _fires_cwfis(lat, lon, list_km); srcs.append("CWFIS")
        except Exception as e:
            errs.append("CWFIS: %s" % e)
    if g == "au":
        try:
            items += _fires_nsw(lat, lon, list_km); srcs.append("NSW RFS")
        except Exception as e:
            errs.append("NSW RFS: %s" % e)
    if g != "ca":                                     # Canada's own service already covers it
        try:
            hs = _firms(lat, lon, list_km, loc.get("country"))
            known = [(i["lat"], i["lon"]) for i in items]
            hs = [h for h in hs if all(H.haversine(h["lat"], h["lon"], a, b) > 5 for a, b in known)]
            items += hs; srcs.append("NASA FIRMS")
        except Exception as e:
            errs.append("FIRMS: %s" % e)
    if not srcs and errs:
        raise RuntimeError("; ".join(errs))
    items.sort(key=lambda x: x["km"])
    out = {"configured": True, "supported": True, "us": False, "fires": items[:25], "nearby": len(items),
           "list_mi": cfg.get("fire_list_mi", 100), "alert_mi": cfg.get("fire_alert_mi", 15),
           "source": " + ".join(srcs), "errors": errs}
    out["drought"], out["drought_note"] = None, ""
    if g == "ca":
        try:
            out["drought"] = _drought_ca(lat, lon)
        except Exception as e:
            out["drought_error"] = str(e)[:160]
    else:
        out["drought_note"] = "Drought data isn't available for this region yet."
    return out


def _fire(id_, name, lat, lon, here, acres=None, contained=None, status="", found=None, county="", kind="incident",
          level="", count=None):
    km = H.haversine(here[0], here[1], lat, lon)
    return {"id": id_, "name": (name or "UNNAMED").upper(), "km": round(km, 1), "dir": H.bearing(here[0], here[1], lat, lon),
            "acres": acres, "contained": contained, "status": status, "lat": lat, "lon": lon, "found": found,
            "county": county, "state": "", "kind": kind, "level": level, "count": count}


CWFIS_STAGE = {"OC": ("OUT OF CONTROL", 0), "BH": ("BEING HELD", 50), "UC": ("UNDER CONTROL", 90),
               "EX": ("EXTINGUISHED", 100), "OUT": ("OUT", 100), "MOD": ("MODIFIED RESPONSE", None)}


def _fires_cwfis(lat, lon, list_km):
    d = H.fetch_json("https://cwfis.cfs.nrcan.gc.ca/geoserver/public/ows?service=WFS&version=1.0.0&request=GetFeature"
                     "&typeName=public:activefires_current&outputFormat=json")
    out = []
    for f in d.get("features", []):
        p = {str(k).lower(): v for k, v in (f.get("properties") or {}).items()}
        c = (f.get("geometry") or {}).get("coordinates") or [p.get("lon"), p.get("lat")]
        try:
            flon, flat = float(c[0]), float(c[1])
        except (TypeError, ValueError, IndexError):
            continue
        if H.haversine(lat, lon, flat, flon) > list_km:
            continue
        stage = str(p.get("stage_of_control") or p.get("stage") or "").upper()
        if stage in ("OUT", "EX"):
            continue
        status, cont = CWFIS_STAGE.get(stage, (stage, None))
        ha = p.get("hectares") or p.get("size_ha") or p.get("size")
        try:
            acres = round(float(ha) * 2.471, 1) if ha not in (None, "") else None
        except (TypeError, ValueError):
            acres = None
        out.append(_fire(p.get("firename") or p.get("fire_name") or p.get("uid") or f.get("id"),
                         (p.get("firename") or p.get("fire_name") or "FIRE"), flat, flon, (lat, lon),
                         acres=acres, contained=cont, status=status, found=H.iso_to_ts(str(p.get("startdate") or "")),
                         county=str(p.get("agency") or "").upper()))
    return out


def _fires_nsw(lat, lon, list_km):
    d = H.fetch_json("https://www.rfs.nsw.gov.au/feeds/majorIncidents.json")
    out = []
    for f in d.get("features", []):
        p = f.get("properties") or {}
        desc = H.strip_tags((p.get("description") or "").replace("<br />", "\n").replace("<br>", "\n"))
        info = {}
        for m in re.finditer(r"([A-Z][A-Z ]{2,20}):\s*([^:]+?)(?=\s+[A-Z][A-Z ]{2,20}:|$)", desc):
            info[m.group(1).strip()] = m.group(2).strip()
        if info.get("FIRE", "Yes").lower().startswith("no"):
            continue
        g = f.get("geometry") or {}
        pts = [g] if g.get("type") == "Point" else [x for x in g.get("geometries", []) if x.get("type") == "Point"]
        if not pts:
            continue
        flon, flat = pts[0]["coordinates"][:2]
        if H.haversine(lat, lon, flat, flon) > list_km:
            continue
        ha = re.match(r"([\d.,]+)", info.get("SIZE", ""))
        acres = round(float(ha.group(1).replace(",", "")) * 2.471, 1) if ha else None
        status = (info.get("STATUS") or "").upper()
        cont = 0 if "OUT OF CONTROL" in status else 50 if "BEING CONTROLLED" in status else 90 if "UNDER CONTROL" in status else None
        out.append(_fire(p.get("guid") or p.get("title"), p.get("title"), flat, flon, (lat, lon), acres=acres,
                         contained=cont, status=status, found=H.iso_to_ts(p.get("pubDate") or ""),
                         county=(info.get("COUNCIL AREA") or "").upper(), level=(p.get("category") or "").upper()))
    return out


_FIRMS = {"t": 0, "region": None, "rows": []}


def _firms(lat, lon, list_km, cc):
    """NASA FIRMS VIIRS satellite fire detections (last 24 h), grouped into clusters."""
    region = COUNTRIES.get((cc or "").upper(), (None, None, None))[2] or _firms_region(lat, lon)
    if _FIRMS["region"] != region or H.now() - _FIRMS["t"] > 1800:
        base = "https://firms.modaps.eosdis.nasa.gov/data/active_fire/suomi-npp-viirs-c2/csv/SUOMI_VIIRS_C2_%s_24h.csv"
        try:
            raw = H.fetch(base % region, timeout=60)
        except Exception:
            raw = H.fetch(base % "Global", timeout=90)
        rows = []
        for r in csv.DictReader(io.StringIO(raw.decode("utf-8", "ignore"))):
            try:
                rows.append((float(r["latitude"]), float(r["longitude"]), r.get("confidence", ""),
                             float(r.get("frp") or 0), r.get("acq_date", ""), r.get("acq_time", "")))
            except (KeyError, ValueError):
                continue
        _FIRMS.update(t=H.now(), region=region, rows=rows)
    near = []
    for (flat, flon, conf, frp, d, tm) in _FIRMS["rows"]:
        if abs(flat - lat) > list_km / 100 or abs(flon - lon) > list_km / (100 * max(0.2, math.cos(math.radians(lat)))):
            continue                                           # quick box filter before the exact distance
        km = H.haversine(lat, lon, flat, flon)
        if km <= list_km and str(conf).lower() not in ("l", "low"):
            near.append((km, flat, flon, conf, frp, d, tm))
    near.sort()
    clusters = []
    for km, flat, flon, conf, frp, d, tm in near:
        for c in clusters:
            if H.haversine(c["lat"], c["lon"], flat, flon) <= 3:
                c["count"] += 1; c["frp"] = max(c["frp"], frp); break
        else:
            clusters.append({"lat": flat, "lon": flon, "count": 1, "frp": frp, "date": d, "time": tm})
    out = []
    for c in clusters:
        found = None
        try:
            found = time.mktime(time.strptime(c["date"] + " " + str(c["time"]).zfill(4), "%Y-%m-%d %H%M")) - time.timezone
        except Exception:
            pass
        cell = "%.1f,%.1f" % (round(c["lat"] * 10) / 10, round(c["lon"] * 10) / 10)
        out.append(_fire("h:" + cell, "SATELLITE HOTSPOT" + (" ×%d" % c["count"] if c["count"] > 1 else ""),
                         c["lat"], c["lon"], (lat, lon), status="%d DETECTION%s · %d MW" % (c["count"], "S" if c["count"] > 1 else "", c["frp"]),
                         found=found, kind="hotspot", count=c["count"]))
    return out


def _firms_region(lat, lon):
    if lon < -30:
        if lat > 50 and lon < -130:
            return "Alaska"
        if lat > 41:
            return "Canada"
        if lat > 24:
            return "USA_contiguous_and_Hawaii"
        if lat > 7:
            return "Central_America"
        return "South_America"
    if lon < 60 and lat > 35:
        return "Europe"
    if lon < 60:
        return "Northern_and_Central_Africa" if lat > -5 else "Southern_Africa"
    if lat < -10 and lon > 110:
        return "Australia_NewZealand"
    if lat > 35:
        return "Russia_Asia"
    if lon < 92:
        return "South_Asia"
    return "SouthEast_Asia"


# ---------------------------------------------------------------- drought (Canada)
DROUGHT_NAMES = ["ABNORMALLY DRY", "MODERATE DROUGHT", "SEVERE DROUGHT", "EXTREME DROUGHT", "EXCEPTIONAL DROUGHT"]


def _drought_ca(lat, lon):
    url = ("https://agriculture.canada.ca/imagery-images/rest/services/canadian_drought_monitor/ImageServer/identify?" +
           "geometry=" + H.quote('{"x":%.5f,"y":%.5f,"spatialReference":{"wkid":4326}}' % (lon, lat)) +
           "&geometryType=esriGeometryPoint&returnGeometry=false&returnCatalogItems=false&f=json")
    d = H.fetch_json(url)
    if d.get("error"):
        raise RuntimeError((d["error"] or {}).get("message") or "drought service error")
    v = str(d.get("value", "")).strip()
    try:
        lvl = int(float(v.split(",")[0]))
    except ValueError:
        lvl = -1                                            # "NoData" = no drought at this spot
    lvl = lvl if 0 <= lvl <= 4 else -1
    return {"county": "YOUR LOCATION", "point": True, "worst": lvl, "main": lvl, "cum": None,
            "date": "", "source": "CANADIAN DROUGHT MONITOR (MONTHLY)"}
