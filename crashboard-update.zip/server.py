#!/usr/bin/env python3
"""
CRASH BOARD - global threat & local hazard monitor.
Pure Python 3 standard library. Built to run on a Raspberry Pi Zero W.

  python3 server.py            -> serves on http://0.0.0.0:8080
  python3 server.py --port 80

The server polls public feeds on a schedule, caches the last good result to
disk (so the board still shows data if the internet drops), and serves one
JSON snapshot to the browser at /api/state.
"""
import argparse
import json
import regions
import lite
import irlights
import queue
import radio
import bank
import math
import os
import re
import shutil
import socket
import subprocess
import sys
import threading
import time
import traceback
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

BASE = os.path.dirname(os.path.abspath(__file__))
STATIC = os.path.join(BASE, "static")
DATA = os.environ.get("CRASHBOARD_DATA") or os.path.join(BASE, "data")   # the phone app keeps data elsewhere
CONFIG_PATH = os.path.join(DATA, "config.json")
CACHE_PATH = os.path.join(DATA, "cache.json")
MAP_PATH = os.path.join(DATA, "land.svgpath")
SEEN_PATH = os.path.join(DATA, "events.json")
os.makedirs(DATA, exist_ok=True)

VERSION = "1.2.1"
UA = "CrashBoard/%s (personal hazard dashboard)" % VERSION

DEFAULT_CONFIG = {
    "location": {"query": "", "name": "", "lat": None, "lon": None, "country": ""},
    "units": "imperial",              # imperial | metric
    "lang": "en",                     # en | es | fr | de | pt (interface only)
    "quake_min_mag": 6.0,
    "alert_quake_mag": 7.0,          # new quakes this big trigger an alert sound
    "fire_list_mi": 100,             # wildfires within this many miles are listed
    "fire_alert_mi": 15,             # a NEW wildfire this close turns the board ORANGE + alarm
    "au_bom": False,                 # Australia: Bureau of Meteorology warnings (personal, non-commercial use only)
    "doomsday": {"seconds": 85, "set": "2026-01-27",
                 "source": "Bulletin of the Atomic Scientists"},
    "defcon": {"mode": "auto", "manual_level": 5},   # auto = OSINT estimate scrape
    "news_feeds": [
        {"name": "IAEA", "url": "https://www.iaea.org/feeds/topnews"},
        {"name": "BULLETIN", "url": "https://thebulletin.org/feed/"},
    ],
    "news_keywords": ["nuclear", "missile", "warhead", "radiation", "reactor",
                      "icbm", "atomic", "uranium", "plutonium", "zaporizhzhia",
                      "enrichment", "arms control", "deterrence", "strike"],
    "callsign": "CRASH BOARD",
    "theme": "ops",                  # ops | blackout | hazard | coyote | vault | cva
    "setup_done": False,             # first-time setup finished (or skipped)
    "profile": "",
    "auto_update": True,             # install signed LL3D updates by itself (CFG > SOFTWARE)                   # home | wall | offgrid | alerts (picked in first-time setup)
    "screen": {                      # defaults for every screen (each screen can still change its own in CFG)
        "sound": True, "volume": 70, "voice": True,
        "alerts": "all",             # which events make sound: all | local | global
        "quiet": {"on": True, "start": "22:00", "end": "07:00"},
        "fx": "",                    # "" = screen decides (full on PCs, low on a Pi Zero)
        "touch": "auto",             # TOUCH MODE: auto | on | off (big buttons, one panel at a time)
        "cycle": 20,                 # seconds per panel when cycling (0 = only change when tapped)
        "layout": {},                # panel key -> "min" (hidden) | "big" (expanded)
        "set": False,                # True once setup (or the Pi's own screen) saved these
    },
    "ir": dict(irlights.DEFAULT),    # ALERT LIGHTS: IR LED strip via a Wi-Fi (Tasmota) IR blaster
    "radio": dict(radio.DEFAULT),    # RADIO tab: RTL-SDR listening + offline NOAA alert decoding
    "bank": dict(bank.DEFAULT),      # CRASH BANK (PRO): local file library
    "mesh": {                        # MESHTASTIC radio (COMMS). Off until a radio is set up (setup wizard or CFG).
        "enabled": False,
        "mode": "auto",              # auto (USB) | serial | tcp (Wi-Fi) | ble (Bluetooth)
        "address": "",               # serial port, IP/hostname, or BLE name/address; blank = auto
        "broadcast_alerts": True,    # send big alerts to the mesh as "[CB] ..." (PRO)
        "alert_min_sev": 2,          # 2 = alert + critical, 3 = critical only
        "alert_channel": 0,
        "relay_inbound": True,       # show "[CB]" alerts heard from other boards
    },
}
THEMES = ("ops", "blackout", "hazard", "coyote", "vault", "cva", "halloween", "nvg", "lab")

INTERVALS = {   # seconds
    "quakes": 120, "alerts": 120, "tsunami": 120,
    "weather": 600, "gdacs": 600, "space": 600,
    "defcon": 1800, "news": 1800, "outbreaks": 1800, "fire": 600,
}
# Data-saver mode for phones on cell data (set by start-android.sh, or CRASHBOARD_MOBILE=1).
# Urgent feeds every 5 min, everything else 5x less often, and smaller quake downloads.
MOBILE = os.environ.get("CRASHBOARD_MOBILE") == "1"
APP = os.environ.get("CRASHBOARD_APP") == "1"    # running inside the Crash Board Android app
APP_NOTIFY = None
APP_RESTART = None                                 # set by the Android app: reopens the app so a downloaded update loads
if MOBILE:
    INTERVALS = {k: (300 if v <= 120 else v * 5) for k, v in INTERVALS.items()}
PORT = 8080

LOCK = threading.Lock()
STATE = {}          # name -> {"ok":bool, "updated":ts, "error":str, "data":...}
CONFIG = {}


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------
def now():
    return time.time()


def log(*a):
    print(time.strftime("%H:%M:%S"), *a, flush=True)


def fetch(url, timeout=20, accept=None):
    req = urllib.request.Request(url, headers={
        "User-Agent": UA,
        "Accept": accept or "*/*",
    })
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def fetch_json(url, **kw):
    return json.loads(fetch(url, accept="application/geo+json, application/json", **kw).decode("utf-8"))


def deep_merge(base, over):
    out = dict(base)
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def load_config():
    global CONFIG
    cfg = {}
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH) as f:
                cfg = json.load(f)
        except Exception as e:
            log("config read failed:", e)
    CONFIG = deep_merge(DEFAULT_CONFIG, cfg)
    if "setup_done" not in cfg and (cfg.get("location") or {}).get("query"):
        CONFIG["setup_done"] = True              # set up before first-time setup existed


def save_config():
    tmp = CONFIG_PATH + ".tmp"
    with open(tmp, "w") as f:
        json.dump(CONFIG, f, indent=2)
    os.replace(tmp, CONFIG_PATH)


def load_cache():
    if os.path.exists(CACHE_PATH):
        try:
            with open(CACHE_PATH) as f:
                d = json.load(f)
            for k, v in d.items():
                v["ok"] = False          # stale until refreshed
                v["error"] = "cached (awaiting refresh)"
                STATE[k] = v
        except Exception as e:
            log("cache read failed:", e)


def save_cache():
    with LOCK:
        snap = {k: v for k, v in STATE.items() if v.get("data") is not None}
    tmp = CACHE_PATH + ".tmp"
    try:
        with open(tmp, "w") as f:
            json.dump(snap, f)
        os.replace(tmp, CACHE_PATH)
    except Exception as e:
        log("cache write failed:", e)


def put(name, data):
    with LOCK:
        STATE[name] = {"ok": True, "updated": now(), "attempted": now(), "error": "", "data": data}


def fail(name, err):
    with LOCK:
        prev = STATE.get(name, {})
        STATE[name] = {"ok": False, "updated": prev.get("updated"), "attempted": now(),
                       "error": str(err)[:200], "data": prev.get("data")}


def iso_to_ts(s):
    if not s:
        return None
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00")).timestamp()
    except Exception:
        try:
            return parsedate_to_datetime(s).timestamp()
        except Exception:
            return None


def strip_tags(s):
    s = re.sub(r"<[^>]+>", " ", s or "")
    s = re.sub(r"&nbsp;", " ", s)
    s = re.sub(r"&amp;", "&", s)
    s = re.sub(r"&#8217;|&rsquo;", "'", s)
    s = re.sub(r"&#8220;|&#8221;|&ldquo;|&rdquo;|&quot;", '"', s)
    s = re.sub(r"&#\d+;|&\w+;", "", s)
    return re.sub(r"\s+", " ", s).strip()


def localname(tag):
    return tag.split("}", 1)[-1] if "}" in tag else tag.split(":")[-1]


def child(el, name):
    for c in el:
        if localname(c.tag) == name:
            return c
    return None


def ctext(el, name, default=""):
    c = child(el, name)
    return (c.text or "").strip() if c is not None and c.text else default


def has_location():
    loc = CONFIG.get("location", {})
    return loc.get("lat") is not None and loc.get("lon") is not None


# --------------------------------------------------------------------------
# geocoding (used by settings)
# --------------------------------------------------------------------------
def geocode(query, cc=None):
    q = (query or "").strip()
    if not q:
        raise ValueError("empty location")
    cc = (cc or "").upper()
    if cc and cc not in ("AUTO", "US"):
        loc = regions.geocode(q, cc)
        loc["cc_pref"] = cc
        return loc
    if cc == "AUTO" or not cc:
        if not re.match(r"^\s*-?\d+(?:\.\d+)?\s*[, ]\s*-?\d+(?:\.\d+)?\s*$", q) and not re.match(r"^\d{5}$", q):
            loc = regions.geocode(q, "")                # city name anywhere in the world
            loc["cc_pref"] = "AUTO"
            return loc
    m = re.match(r"^\s*(-?\d+(?:\.\d+)?)\s*[, ]\s*(-?\d+(?:\.\d+)?)\s*$", q)
    if m:
        lat, lon = float(m.group(1)), float(m.group(2))
        return {"query": q, "name": "%.3f, %.3f" % (lat, lon), "lat": lat, "lon": lon,
                "country": "US" if (18 < lat < 72 and -180 < lon < -64) else ""}
    if re.match(r"^\d{5}$", q):
        d = fetch_json("https://api.zippopotam.us/us/" + q)
        p = d["places"][0]
        return {"query": q, "name": "%s, %s" % (p["place name"], p["state abbreviation"]),
                "lat": float(p["latitude"]), "lon": float(p["longitude"]), "country": "US"}
    # "City, ST" -> search city name then prefer matching admin/country
    parts = [x.strip() for x in q.split(",")]
    url = ("https://geocoding-api.open-meteo.com/v1/search?count=10&language=en&format=json&name="
           + urllib.parse.quote(parts[0]))
    res = fetch_json(url).get("results") or []
    if not res:
        raise ValueError("location not found: " + q)
    pick = res[0]
    if len(parts) > 1:
        hint = parts[1].lower()
        for r in res:
            fields = [str(r.get(k, "")).lower() for k in ("admin1", "country", "country_code")]
            if any(hint == f or (len(hint) > 2 and hint in f) for f in fields) or \
               US_STATES.get(hint.upper(), "~").lower() == fields[0]:
                pick = r
                break
    name = pick["name"]
    if pick.get("admin1"):
        name += ", " + pick["admin1"]
    if pick.get("country_code") and pick.get("country_code") != "US":
        name += ", " + pick["country_code"]
    return {"query": q, "name": name, "lat": pick["latitude"], "lon": pick["longitude"],
            "country": pick.get("country_code", "")}


US_STATES = dict(AL="Alabama", AK="Alaska", AZ="Arizona", AR="Arkansas", CA="California",
                 CO="Colorado", CT="Connecticut", DE="Delaware", FL="Florida", GA="Georgia",
                 HI="Hawaii", ID="Idaho", IL="Illinois", IN="Indiana", IA="Iowa", KS="Kansas",
                 KY="Kentucky", LA="Louisiana", ME="Maine", MD="Maryland", MA="Massachusetts",
                 MI="Michigan", MN="Minnesota", MS="Mississippi", MO="Missouri", MT="Montana",
                 NE="Nebraska", NV="Nevada", NH="New Hampshire", NJ="New Jersey",
                 NM="New Mexico", NY="New York", NC="North Carolina", ND="North Dakota",
                 OH="Ohio", OK="Oklahoma", OR="Oregon", PA="Pennsylvania", RI="Rhode Island",
                 SC="South Carolina", SD="South Dakota", TN="Tennessee", TX="Texas", UT="Utah",
                 VT="Vermont", VA="Virginia", WA="Washington", WV="West Virginia",
                 WI="Wisconsin", WY="Wyoming", DC="District of Columbia", PR="Puerto Rico")


# --------------------------------------------------------------------------
# collectors
# --------------------------------------------------------------------------
QK = {"big_t": 0, "events": {}}   # mobile mode: merged quake list


def parse_quakes(d, minmag):
    out = []
    for f in d.get("features", []):
        p = f.get("properties", {})
        mag = p.get("mag")
        if mag is None or mag < minmag:
            continue
        c = (f.get("geometry") or {}).get("coordinates") or [0, 0, 0]
        out.append({
            "id": f.get("id"), "mag": round(mag, 1), "place": p.get("place") or "Unknown",
            "time": (p.get("time") or 0) / 1000.0, "lon": c[0], "lat": c[1],
            "depth": c[2] if len(c) > 2 else None, "tsunami": bool(p.get("tsunami")),
            "alert": p.get("alert"), "url": p.get("url"), "felt": p.get("felt"),
        })
    return out


def col_quakes():
    base = "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/"
    minmag = float(CONFIG.get("quake_min_mag", 6.0))
    if not MOBILE:
        out = parse_quakes(fetch_json(base + "4.5_month.geojson"), minmag)
        days = 30
    else:
        # Phone data saver: the 7-day list every 3 h, and only the last 24 h in between
        # (a few KB instead of ~1 MB per check). Results are merged.
        t = now()
        if t - QK["big_t"] > 3 * 3600:
            QK["events"] = {e["id"]: e for e in parse_quakes(fetch_json(base + "4.5_week.geojson"), minmag)}
            QK["big_t"] = t
        else:
            for e in parse_quakes(fetch_json(base + "4.5_day.geojson"), minmag):
                QK["events"][e["id"]] = e
        QK["events"] = {k: e for k, e in QK["events"].items() if t - e["time"] < 7 * 86400}
        out = list(QK["events"].values())
        days = 7
    out.sort(key=lambda q: q["time"], reverse=True)
    return {"min_mag": minmag, "days": days, "events": out[:40]}


def col_alerts():
    if not has_location():
        return {"configured": False, "alerts": []}
    loc = CONFIG["location"]
    if loc.get("country") and regions.group(loc.get("country")) != "us":
        return regions.alerts(loc, CONFIG)
    url = "https://api.weather.gov/alerts/active?point=%.4f,%.4f" % (loc["lat"], loc["lon"])
    d = fetch_json(url)
    sev_rank = {"Extreme": 4, "Severe": 3, "Moderate": 2, "Minor": 1, "Unknown": 0}
    out = []
    for f in d.get("features", []):
        p = f.get("properties", {})
        out.append({
            "id": f.get("id") or p.get("id") or p.get("headline"),
            "event": p.get("event"), "severity": p.get("severity") or "Unknown",
            "urgency": p.get("urgency"), "certainty": p.get("certainty"),
            "headline": p.get("headline") or p.get("event"),
            "area": p.get("areaDesc"), "onset": iso_to_ts(p.get("onset") or p.get("effective")),
            "expires": iso_to_ts(p.get("ends") or p.get("expires")),
            "instruction": (p.get("instruction") or "")[:600],
            "description": (p.get("description") or "")[:900],
            "rank": sev_rank.get(p.get("severity"), 0), "local": True,
        })
    out.sort(key=lambda a: (-a["rank"], a["onset"] or 0))
    return {"configured": True, "supported": True, "alerts": out, "source": "NWS"}


WMO = {0: "CLEAR", 1: "MAINLY CLEAR", 2: "PARTLY CLOUDY", 3: "OVERCAST", 45: "FOG",
       48: "RIME FOG", 51: "LIGHT DRIZZLE", 53: "DRIZZLE", 55: "HEAVY DRIZZLE",
       56: "FREEZING DRIZZLE", 57: "FREEZING DRIZZLE", 61: "LIGHT RAIN", 63: "RAIN",
       65: "HEAVY RAIN", 66: "FREEZING RAIN", 67: "FREEZING RAIN", 71: "LIGHT SNOW",
       73: "SNOW", 75: "HEAVY SNOW", 77: "SNOW GRAINS", 80: "RAIN SHOWERS",
       81: "RAIN SHOWERS", 82: "VIOLENT SHOWERS", 85: "SNOW SHOWERS", 86: "SNOW SHOWERS",
       95: "THUNDERSTORM", 96: "T-STORM / HAIL", 99: "T-STORM / HEAVY HAIL"}


def col_weather():
    if not has_location():
        return {"configured": False}
    loc = CONFIG["location"]
    imp = CONFIG.get("units") == "imperial"
    q = {
        "latitude": loc["lat"], "longitude": loc["lon"], "timezone": "auto",
        "current": "temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,"
                   "wind_speed_10m,wind_direction_10m,wind_gusts_10m,pressure_msl,"
                   "precipitation,cloud_cover,is_day",
        "daily": "weather_code,temperature_2m_max,temperature_2m_min,"
                 "precipitation_probability_max,wind_gusts_10m_max,uv_index_max,sunrise,sunset",
        "forecast_days": 4,
    }
    if imp:
        q.update(temperature_unit="fahrenheit", wind_speed_unit="mph", precipitation_unit="inch")
    d = fetch_json("https://api.open-meteo.com/v1/forecast?" + urllib.parse.urlencode(q))
    c = d.get("current", {})
    dl = d.get("daily", {})
    days = []
    for i, t in enumerate(dl.get("time", [])):
        days.append({
            "date": t, "code": dl["weather_code"][i], "cond": WMO.get(dl["weather_code"][i], "--"),
            "hi": dl["temperature_2m_max"][i], "lo": dl["temperature_2m_min"][i],
            "pop": dl["precipitation_probability_max"][i], "gust": dl["wind_gusts_10m_max"][i],
            "uv": dl["uv_index_max"][i],
        })
    return {
        "configured": True, "location": loc.get("name"), "units": "imperial" if imp else "metric",
        "temp": c.get("temperature_2m"), "feels": c.get("apparent_temperature"),
        "rh": c.get("relative_humidity_2m"), "code": c.get("weather_code"),
        "cond": WMO.get(c.get("weather_code"), "--"), "wind": c.get("wind_speed_10m"),
        "wdir": c.get("wind_direction_10m"), "gust": c.get("wind_gusts_10m"),
        "pressure": c.get("pressure_msl"), "cloud": c.get("cloud_cover"),
        "precip": c.get("precipitation"), "is_day": c.get("is_day"),
        "sunrise": (dl.get("sunrise") or [None])[0], "sunset": (dl.get("sunset") or [None])[0],
        "days": days,
    }


def col_tsunami():
    feeds = [("NTWC", "https://www.tsunami.gov/events/xml/PAAQAtom.xml"),
             ("PTWC", "https://www.tsunami.gov/events/xml/PHEBAtom.xml")]
    out, errs = [], []
    cutoff = now() - 3 * 86400
    for center, url in feeds:
        try:
            root = ET.fromstring(fetch(url))
        except Exception as e:
            errs.append("%s: %s" % (center, e))
            continue
        for e in root:
            if localname(e.tag) != "entry":
                continue
            ts = iso_to_ts(ctext(e, "updated"))
            if ts and ts < cutoff:
                continue
            summ = child(e, "summary")
            summary = strip_tags(ET.tostring(summ, encoding="unicode")) if summ is not None else ""
            blob = (ctext(e, "title") + " " + summary).lower()
            if "warning" in blob and "no tsunami warning" not in blob:
                level = "WARNING"
            elif "advisory" in blob and "no tsunami advisory" not in blob:
                level = "ADVISORY"
            elif "watch" in blob and "no tsunami watch" not in blob:
                level = "WATCH"
            elif "threat" in blob and "no tsunami threat" not in blob and "no threat" not in blob:
                level = "THREAT"
            else:
                level = "INFO"
            out.append({"center": center, "title": ctext(e, "title"), "time": ts,
                        "level": level, "summary": summary[:300]})
    if errs and not out and len(errs) == len(feeds):
        raise RuntimeError("; ".join(errs))
    out.sort(key=lambda x: x["time"] or 0, reverse=True)
    return {"events": out[:10]}


def col_gdacs():
    root = ET.fromstring(fetch("https://www.gdacs.org/xml/rss.xml"))
    ch = child(root, "channel")
    types = {"EQ": "EARTHQUAKE", "TC": "CYCLONE", "FL": "FLOOD", "VO": "VOLCANO",
             "DR": "DROUGHT", "WF": "WILDFIRE", "TS": "TSUNAMI"}
    out = []
    for it in (ch if ch is not None else []):
        if localname(it.tag) != "item":
            continue
        lvl = ctext(it, "alertlevel")
        if lvl not in ("Orange", "Red"):
            continue
        if ctext(it, "iscurrent").lower() == "false":
            continue
        et = ctext(it, "eventtype")
        pt = child(it, "Point")
        lat = lon = None
        if pt is not None:
            try:
                lat, lon = float(ctext(pt, "lat")), float(ctext(pt, "long"))
            except ValueError:
                pass
        out.append({"type": types.get(et, et), "code": et, "level": lvl.upper(),
                    "id": et + ctext(it, "eventid"),
                    "title": ctext(it, "title"), "country": ctext(it, "country"),
                    "severity": strip_tags(ctext(it, "severity")),
                    "time": iso_to_ts(ctext(it, "pubDate")), "lat": lat, "lon": lon,
                    "link": ctext(it, "link")})
    out.sort(key=lambda x: (x["level"] != "RED", -(x["time"] or 0)))
    return {"events": out[:15]}


def col_space():
    kp = fetch_json("https://services.swpc.noaa.gov/products/noaa-planetary-k-index.json")
    rows = []
    for r in kp:
        if isinstance(r, dict):
            rows.append((r.get("time_tag"), float(r.get("Kp") or 0)))
        elif isinstance(r, list) and r and r[0] != "time_tag":   # legacy array format
            rows.append((r[0], float(r[1])))
    rows = rows[-24:]
    latest = rows[-1][1] if rows else None
    peak24 = max([k for _, k in rows[-8:]], default=None)

    def gscale(k):
        if k is None:
            return 0
        return 5 if k >= 9 else 4 if k >= 8 else 3 if k >= 7 else 2 if k >= 6 else 1 if k >= 5 else 0

    alerts = []
    try:
        al = fetch_json("https://services.swpc.noaa.gov/products/alerts.json")
        cutoff = now() - 36 * 3600
        for a in al:
            ts = iso_to_ts((a.get("issue_datetime") or "").replace(" ", "T") + "Z") \
                if "Z" not in (a.get("issue_datetime") or "") else iso_to_ts(a.get("issue_datetime"))
            if ts and ts < cutoff:
                continue
            msg = a.get("message") or ""
            head = ""
            for line in msg.splitlines():
                if line.startswith(("ALERT:", "WARNING:", "WATCH:", "SUMMARY:", "EXTENDED WARNING:")):
                    head = line.strip()
                    break
            if head:
                alerts.append({"time": ts, "head": head})
    except Exception as e:
        log("swpc alerts:", e)
    alerts.sort(key=lambda x: x["time"] or 0, reverse=True)
    return {"kp": latest, "kp_peak_24h": peak24, "g": gscale(latest), "g_peak": gscale(peak24),
            "series": [k for _, k in rows], "alerts": alerts[:6]}


def col_defcon():
    mode = CONFIG.get("defcon", {}).get("mode", "auto")
    if mode == "manual":
        return {"level": int(CONFIG["defcon"].get("manual_level", 5)), "source": "MANUAL ENTRY",
                "official": False}
    html = fetch("https://www.defconlevel.com/current-level").decode("utf-8", "ignore")
    text = strip_tags(html)
    m = re.search(r"OSINT\s+Estimate\s+DEFCON\s+([1-5])", text, re.I) or \
        re.search(r"defcon-([1-5])\.png", html) or \
        re.search(r"DEFCON\s+([1-5])", text)
    if not m:
        raise RuntimeError("level not found on page")
    word = ""
    mw = re.search(r"DEFCON\s+[1-5]\s+([A-Z][A-Z ]{3,20}?)\s+(?:LIVE|Live|·)", text)
    if mw:
        word = mw.group(1).strip()
    return {"level": int(m.group(1)), "codeword": word, "official": False,
            "source": "DEFCONLEVEL.COM OSINT ESTIMATE"}


def col_news():
    kws = [k.lower() for k in CONFIG.get("news_keywords", [])]
    out, errs = [], []
    for feed in CONFIG.get("news_feeds", []):
        try:
            root = ET.fromstring(fetch(feed["url"]))
        except Exception as e:
            errs.append("%s: %s" % (feed.get("name"), e))
            continue
        items = [e for e in root.iter() if localname(e.tag) in ("item", "entry")]
        for it in items[:30]:
            title = strip_tags(ctext(it, "title"))
            desc = strip_tags(ctext(it, "description") or ctext(it, "summary"))
            link = ctext(it, "link")
            if not link:
                l = child(it, "link")
                link = l.get("href", "") if l is not None else ""
            ts = iso_to_ts(ctext(it, "pubDate") or ctext(it, "updated") or ctext(it, "published"))
            blob = (title + " " + desc).lower()
            hit = [k for k in kws if k in blob]
            if kws and not hit:
                continue
            out.append({"src": feed.get("name", "?"), "title": title, "time": ts, "link": link})
    if errs and not out and len(errs) == len(CONFIG.get("news_feeds", [])):
        raise RuntimeError("; ".join(errs))
    out.sort(key=lambda x: x["time"] or 0, reverse=True)
    return {"items": out[:12], "errors": errs}


# Pathogens where even a regional outbreak is worth flagging on a prepper board.
HIGH_CONSEQUENCE = [r"ebola", r"marburg", r"bundibugyo", r"sudan virus", r"nipah", r"smallpox",
                    r"variola", r"\bclade i\b", r"clade ib", r"avian influenza", r"\bh5n\d", r"\bh7n9",
                    r"novel influenza", r"novel coronavirus", r"\bmers\b", r"plague", r"lassa",
                    r"crimean-congo", r"anthrax", r"pandemic", r"unknown (?:disease|etiology|cause)"]


def is_high_consequence(text):
    t = (text or "").lower()
    return any(re.search(p, t) for p in HIGH_CONSEQUENCE)


def col_outbreaks():
    out = {"who": [], "cdc": [], "errors": []}
    # WHO Disease Outbreak News (official reports)
    try:
        d = fetch_json("https://www.who.int/api/news/diseaseoutbreaknews"
                       "?$orderby=PublicationDate%20desc&$top=10&$select=Title,PublicationDate,UrlName")
        for it in d.get("value", []):
            title = strip_tags(it.get("Title"))
            out["who"].append({
                "title": title, "time": iso_to_ts(it.get("PublicationDate")),
                "link": "https://www.who.int/emergencies/disease-outbreak-news/item/" + (it.get("UrlName") or ""),
                "high": is_high_consequence(title)})
    except Exception as e:
        out["errors"].append("WHO: %s" % e)

    # CDC Travel Health Notices (Level 1-4). The RSS feed lags the web page, so read both.
    notices = {}
    try:
        root = ET.fromstring(fetch("https://wwwnc.cdc.gov/travel/rss/notices.xml"))
        for it in root.iter():
            if localname(it.tag) != "item":
                continue
            title, link = strip_tags(ctext(it, "title")), ctext(it, "link")
            m = re.search(r"/notices/level(\d)/([\w-]+)", link) or re.search(r"Level (\d)", title)
            if not m:
                continue
            key = m.group(2) if m.lastindex and m.lastindex > 1 else title
            notices[key] = {"level": int(m.group(1)), "title": re.sub(r"^Level \d\s*-\s*", "", title),
                            "link": link, "time": iso_to_ts(ctext(it, "pubDate"))}
    except Exception as e:
        out["errors"].append("CDC RSS: %s" % e)
    try:
        html = fetch("https://wwwnc.cdc.gov/travel/notices").decode("utf-8", "ignore")
        for m in re.finditer(r'href="([^"]*/travel/notices/level(\d)/([\w-]+))"[^>]*>(.*?)</a>', html, re.S):
            href, lvl, slug, text = m.group(1), int(m.group(2)), m.group(3), strip_tags(m.group(4))
            if slug in notices:
                notices[slug]["level"] = lvl
                continue
            if not text or text.lower().startswith("read more") or len(text) < 6:
                text = slug.replace("-", " ").title()
            text = re.sub(r"^Level \d\s*-\s*", "", text)
            notices[slug] = {"level": lvl, "title": text, "time": None,
                             "link": href if href.startswith("http") else "https://wwwnc.cdc.gov" + href}
    except Exception as e:
        out["errors"].append("CDC page: %s" % e)
    for n in notices.values():
        n["high"] = is_high_consequence(n["title"])
    out["cdc"] = sorted(notices.values(), key=lambda n: (-n["level"], -(n["time"] or 0)))[:20]
    if not out["who"] and not out["cdc"] and out["errors"]:
        raise RuntimeError("; ".join(out["errors"]))
    return out


# --------------------------------------------------------------------------
# wildfire + drought (US): NIFC current incidents, US Drought Monitor
# --------------------------------------------------------------------------
DROUGHT_NAMES = ["ABNORMALLY DRY", "MODERATE DROUGHT", "SEVERE DROUGHT", "EXTREME DROUGHT", "EXCEPTIONAL DROUGHT"]
FIRE_CACHE = {"fips": None, "fips_for": None, "county": "", "drought": None, "drought_t": 0}


def _haversine_km(lat1, lon1, lat2, lon2):
    r = math.radians
    a = math.sin(r(lat2 - lat1) / 2) ** 2 + math.cos(r(lat1)) * math.cos(r(lat2)) * math.sin(r(lon2 - lon1) / 2) ** 2
    return 6371 * 2 * math.asin(min(1, math.sqrt(a)))


def _bearing(lat1, lon1, lat2, lon2):
    r = math.radians
    y = math.sin(r(lon2 - lon1)) * math.cos(r(lat2))
    x = math.cos(r(lat1)) * math.sin(r(lat2)) - math.sin(r(lat1)) * math.cos(r(lat2)) * math.cos(r(lon2 - lon1))
    deg = (math.degrees(math.atan2(y, x)) + 360) % 360
    return ["N", "NE", "E", "SE", "S", "SW", "W", "NW"][int((deg + 22.5) // 45) % 8]


def _county_fips(lat, lon):
    """Census county for a point (FCC Area API). Cached per location."""
    key = "%.3f,%.3f" % (lat, lon)
    if FIRE_CACHE["fips_for"] == key and FIRE_CACHE["fips"]:
        return FIRE_CACHE["fips"]
    d = fetch_json("https://geo.fcc.gov/api/census/area?lat=%.5f&lon=%.5f&format=json" % (lat, lon))
    r = (d.get("results") or [{}])[0]
    fips = r.get("county_fips")
    if not fips:
        raise RuntimeError("county lookup returned nothing")
    if RADIO:
        RADIO.fips = fips                  # lets the NOAA radio decoder match warnings to this county
    FIRE_CACHE.update(fips=fips, fips_for=key, county="%s, %s" % (r.get("county_name") or "", r.get("state_code") or ""),
                      drought=None, drought_t=0)
    return fips


def _drought_rows(raw):
    """US Drought Monitor statistics come back as JSON or XML depending on the server; read both."""
    raw = raw.strip()
    rows = []
    if raw.startswith("[") or raw.startswith("{"):
        d = json.loads(raw)
        rows = d if isinstance(d, list) else (d.get("data") or d.get("Data") or [d])
    else:
        root = ET.fromstring(raw)
        for el in root.iter():
            kids = {localname(c.tag): (c.text or "").strip() for c in el}
            if "D0" in kids and ("MapDate" in kids or "mapDate" in kids or "ValidStart" in kids):
                rows.append(kids)
    out = []
    for r in rows:
        k = {str(a).lower(): b for a, b in r.items()}
        try:
            vals = [float(k.get("none", 0) or 0)] + [float(k.get("d%d" % i, 0) or 0) for i in range(5)]
        except (TypeError, ValueError):
            continue
        date = str(k.get("mapdate") or k.get("validstart") or "")[:10].replace("-", "")
        out.append((date, vals))
    return out


def _drought(fips):
    t = time.localtime()
    s_ = time.localtime(time.time() - 21 * 86400)
    url = ("https://usdmdataservices.unl.edu/api/CountyStatistics/GetDroughtSeverityStatisticsByAreaPercent?" +
           urllib.parse.urlencode({"aoi": fips, "startdate": "%d/%d/%d" % (s_.tm_mon, s_.tm_mday, s_.tm_year),
                                   "enddate": "%d/%d/%d" % (t.tm_mon, t.tm_mday, t.tm_year), "statisticsType": 1}))
    rows = _drought_rows(fetch(url, accept="application/json").decode("utf-8", "ignore"))
    if not rows:
        raise RuntimeError("no drought statistics returned")
    date, (none, d0, d1, d2, d3, d4) = max(rows, key=lambda r: r[0])
    cat = [d0, d1, d2, d3, d4]
    # "Traditional" statistics are cumulative: None + D0 = 100 and D0 >= D1 >= ... >= D4.
    # If instead None + D0..D4 add up to 100, they're per-category: convert to cumulative.
    cumulative = abs(none + d0 - 100) < 1.5 and d0 >= d1 >= d2 >= d3 >= d4
    if not cumulative and abs(none + sum(cat) - 100) < 1.5:
        cat = [sum(cat[i:]) for i in range(5)]
    cum = [round(min(100, max(0, v)), 1) for v in cat]
    worst = max([i for i in range(5) if cum[i] >= 1] or [-1])
    main = max([i for i in range(5) if cum[i] >= 50] or [-1])
    return {"county": FIRE_CACHE["county"], "fips": fips, "cum": cum, "worst": worst, "main": main,
            "date": "%s-%s-%s" % (date[:4], date[4:6], date[6:8]) if len(date) >= 8 else date}


def col_fire():
    if not has_location():
        return {"configured": False}
    loc = CONFIG["location"]
    if loc.get("country") and regions.group(loc.get("country")) != "us":
        return regions.fires(loc, CONFIG)
    lat, lon = loc["lat"], loc["lon"]
    list_km = float(CONFIG.get("fire_list_mi", 100)) * 1.609
    fields = ("IncidentName,IncidentSize,PercentContained,FireDiscoveryDateTime,POOState,POOCounty,"
              "UniqueFireIdentifier,ModifiedOnDateTime_dt,InitialLatitude,InitialLongitude")
    url = ("https://services3.arcgis.com/T4QMspbfLg3qTGWY/arcgis/rest/services/"
           "WFIGS_Incident_Locations_Current/FeatureServer/0/query?" +
           urllib.parse.urlencode({"where": "IncidentTypeCategory='WF'", "outFields": fields,
                                   "returnGeometry": "true", "outSR": "4326", "f": "json",
                                   "resultRecordCount": 2000}))
    d = fetch_json(url)
    if d.get("error"):
        raise RuntimeError((d["error"] or {}).get("message") or "fire service error")
    fires, total = [], 0
    for f in d.get("features", []):
        a, g = f.get("attributes") or {}, f.get("geometry") or {}
        flat = g.get("y", a.get("InitialLatitude")); flon = g.get("x", a.get("InitialLongitude"))
        if flat is None or flon is None:
            continue
        total += 1
        km = _haversine_km(lat, lon, flat, flon)
        if km > list_km:
            continue
        disc = a.get("FireDiscoveryDateTime")
        fires.append({"id": a.get("UniqueFireIdentifier") or a.get("IncidentName"),
                      "name": (a.get("IncidentName") or "UNNAMED").upper(), "km": round(km, 1),
                      "dir": _bearing(lat, lon, flat, flon), "acres": a.get("IncidentSize"),
                      "contained": a.get("PercentContained"), "lat": flat, "lon": flon,
                      "state": a.get("POOState"), "county": a.get("POOCounty"),
                      "found": disc / 1000.0 if isinstance(disc, (int, float)) else iso_to_ts(str(disc or "")),
                      "updated": (a.get("ModifiedOnDateTime_dt") or 0) / 1000.0 if isinstance(a.get("ModifiedOnDateTime_dt"), (int, float)) else None})
    fires.sort(key=lambda x: x["km"])
    out = {"configured": True, "us": True, "supported": True, "source": "NIFC", "fires": fires[:25], "nearby": len(fires), "us_total": total,
           "list_mi": CONFIG.get("fire_list_mi", 100), "alert_mi": CONFIG.get("fire_alert_mi", 15)}
    # drought changes weekly: refresh every 12 h
    try:
        fips = _county_fips(lat, lon)
        if not FIRE_CACHE["drought"] or now() - FIRE_CACHE["drought_t"] > 12 * 3600:
            FIRE_CACHE["drought"], FIRE_CACHE["drought_t"] = _drought(fips), now()
        out["drought"] = FIRE_CACHE["drought"]
    except Exception as e:
        out["drought"] = FIRE_CACHE["drought"]
        out["drought_error"] = str(e)[:160]
        log("drought:", e)
    return out


regions.bind(fetch=lambda *a, **k: fetch(*a, **k), fetch_json=lambda *a, **k: fetch_json(*a, **k),
             log=lambda *a: log(*a), iso_to_ts=lambda x: iso_to_ts(x), strip_tags=lambda x: strip_tags(x),
             localname=localname, ctext=ctext, ET=ET, now=lambda: now(), quote=urllib.parse.quote,
             us_states=US_STATES, haversine=_haversine_km, bearing=_bearing)

COLLECTORS = {
    "quakes": col_quakes, "alerts": col_alerts, "weather": col_weather,
    "tsunami": col_tsunami, "gdacs": col_gdacs, "space": col_space,
    "defcon": col_defcon, "news": col_news, "outbreaks": col_outbreaks, "fire": col_fire,
}
NEXT_RUN = {k: 0 for k in COLLECTORS}
WAKE = threading.Event()


def run_collector(name):
    try:
        put(name, COLLECTORS[name]())
        log("ok  ", name)
        try:
            detect_events(name, STATE[name]["data"])
        except Exception as e:
            log("event check failed:", name, e)
    except Exception as e:
        fail(name, e)
        log("FAIL", name, "-", e)


PENDING_LOC = {"next": 0}


def pending_location():
    """Phone setup couldn't look the place up (internet not ready yet): keep trying in the background."""
    p = os.path.join(DATA, "pending-location.json")
    if now() < PENDING_LOC["next"] or not os.path.exists(p):
        return
    PENDING_LOC["next"] = now() + 120
    try:
        want = json.load(open(p))
        loc = geocode(want["query"], want.get("country") or "AUTO")
        loc.setdefault("cc_pref", (want.get("country") or "AUTO").upper())
    except ValueError as e:
        if "not found" in str(e):
            log("pending location: not found, giving up:", e)
            os.remove(p)
        return
    except Exception as e:
        log("pending location: still can't look it up:", e)
        return
    CONFIG["location"] = loc
    save_config()
    os.remove(p)
    log("pending location set:", loc.get("name"))
    refresh_soon("alerts", "weather", "fire")


def poller():
    while True:
        t = now()
        ran = False
        try:
            pending_location()
        except Exception as e:
            log("pending location check failed:", e)
        for name in COLLECTORS:
            if t >= NEXT_RUN[name]:
                run_collector(name)
                ok = STATE.get(name, {}).get("ok")
                # retry failures sooner (60s), otherwise normal interval
                NEXT_RUN[name] = now() + (INTERVALS[name] if ok else min(60, INTERVALS[name]))
                ran = True
        if ran:
            try:
                check_condition()
            except Exception as e:
                log("condition check failed:", e)
            save_cache()
        WAKE.wait(5)
        WAKE.clear()


def refresh_soon(*names):
    for n in names:
        NEXT_RUN[n] = 0
    WAKE.set()


# --------------------------------------------------------------------------
# world map (downloaded once, converted from TopoJSON to an SVG path)
# --------------------------------------------------------------------------
def topo_to_path(topo, W=360, H=180):
    tf = topo.get("transform")
    arcs = []
    for arc in topo["arcs"]:
        pts, x, y = [], 0, 0
        for p in arc:
            if tf:
                x += p[0]; y += p[1]
                lon = x * tf["scale"][0] + tf["translate"][0]
                lat = y * tf["scale"][1] + tf["translate"][1]
            else:
                lon, lat = p[0], p[1]
            pts.append((lon, lat))
        arcs.append(pts)

    def ring(idx):
        pts = []
        for i in idx:
            a = arcs[i] if i >= 0 else list(reversed(arcs[~i]))
            pts.extend(a if not pts else a[1:])
        return pts

    obj = list(topo["objects"].values())[0]
    geoms = obj.get("geometries", [obj])
    out = []
    for g in geoms:
        polys = [g["arcs"]] if g["type"] == "Polygon" else g["arcs"] if g["type"] == "MultiPolygon" else []
        for poly in polys:
            for r in poly:
                pts = ring(r)
                if len(pts) < 3:
                    continue
                seg, last = [], None
                for lon, lat in pts:
                    px = round((lon + 180) / 360 * W, 1)
                    py = round((90 - lat) / 180 * H, 1)
                    if last and abs(px - last[0]) > W / 2:   # dateline wrap
                        seg.append("M%s %s" % (px, py))
                    elif last and abs(px - last[0]) < 0.3 and abs(py - last[1]) < 0.3:
                        continue
                    else:
                        seg.append(("L" if seg else "M") + "%s %s" % (px, py))
                    last = (px, py)
                out.append("".join(seg) + "Z")
    return "".join(out)


def ensure_map():
    if os.path.exists(MAP_PATH):
        return
    for url in ("https://cdn.jsdelivr.net/npm/world-atlas@2/land-110m.json",
                "https://unpkg.com/world-atlas@2/land-110m.json"):
        try:
            topo = json.loads(fetch(url, timeout=40))
            path = topo_to_path(topo)
            with open(MAP_PATH, "w") as f:
                f.write(path)
            log("world map ready (%d bytes)" % len(path))
            return
        except Exception as e:
            log("map download failed:", url, e)


def map_thread():
    while not os.path.exists(MAP_PATH):
        ensure_map()
        if not os.path.exists(MAP_PATH):
            time.sleep(600)


# --------------------------------------------------------------------------
# threat assessment
# --------------------------------------------------------------------------
def assess(snap):
    """Combine everything into one condition level + reasons."""
    score, reasons = 0, []
    part = {"local": [0, []], "global": [0, []]}
    scope = ["global"]                       # which half the next bump() counts toward

    def bump(n, why):
        nonlocal score
        score = max(score, n)
        reasons.append((n, why))
        h = part[scope[0]]
        h[0] = max(h[0], n)
        h[1].append((n, why))

    t = now()
    q = (snap.get("quakes") or {}).get("data") or {}
    for e in q.get("events", []):
        age = t - e["time"]
        scope[0] = quake_scope(e)
        if age < 86400:
            if e["mag"] >= 8:
                bump(3, "M%.1f QUAKE %s" % (e["mag"], e["place"]))
            elif e["mag"] >= 7:
                bump(2, "M%.1f QUAKE %s" % (e["mag"], e["place"]))
            else:
                bump(1, "M%.1f QUAKE %s" % (e["mag"], e["place"]))
    scope[0] = "global"
    ts = (snap.get("tsunami") or {}).get("data") or {}
    for e in ts.get("events", []):
        if e["time"] and t - e["time"] < 86400:
            if e["level"] == "WARNING":
                bump(3, "TSUNAMI WARNING " + e["title"])
            elif e["level"] in ("ADVISORY", "WATCH", "THREAT"):
                bump(2, "TSUNAMI %s %s" % (e["level"], e["title"]))
    scope[0] = "local"
    al = (snap.get("alerts") or {}).get("data") or {}
    for a in al.get("alerts", []):
        if not a.get("local", True):
            continue                                   # warning for another part of the country
        if a["severity"] == "Extreme":
            bump(3, "LOCAL: " + (a["event"] or "").upper())
        elif a["severity"] == "Severe":
            bump(2, "LOCAL: " + (a["event"] or "").upper())
        elif a["severity"] == "Moderate":
            bump(1, "LOCAL: " + (a["event"] or "").upper())
    scope[0] = "global"
    dc = (snap.get("defcon") or {}).get("data") or {}
    lvl = dc.get("level")
    if lvl:
        if lvl <= 1:
            bump(3, "DEFCON 1 (EST)")
        elif lvl == 2:
            bump(3, "DEFCON 2 (EST)")
        elif lvl == 3:
            bump(1, "DEFCON 3 (EST)")
    ob = (snap.get("outbreaks") or {}).get("data") or {}
    for n in ob.get("cdc", []):
        if n["level"] >= 4:
            bump(2, "CDC LEVEL 4: " + n["title"].upper())
        elif n["level"] == 3:
            bump(1, "CDC LEVEL 3: " + n["title"].upper())
    for w in ob.get("who", []):
        if w["high"] and w["time"] and t - w["time"] < 14 * 86400:
            bump(1, "WHO OUTBREAK: " + w["title"].upper())
            break
    scope[0] = "local"
    fr = (snap.get("fire") or {}).get("data") or {}
    alert_km = float(CONFIG.get("fire_alert_mi", 15)) * 1.609
    imp = CONFIG.get("units") == "imperial"
    def dist(km):
        return "%d MI" % round(km / 1.609) if imp else "%d KM" % round(km)
    for f in fr.get("fires", []):
        if f.get("level") == "EMERGENCY WARNING" and f["km"] <= alert_km * 2.7:
            bump(3, "FIRE EMERGENCY WARNING %s %s %s" % (f["name"], dist(f["km"]), f["dir"]))
        elif f.get("kind") == "hotspot":
            if f["km"] <= alert_km and (f.get("count") or 1) >= 2:
                bump(2, "SATELLITE FIRE DETECTION %s %s" % (dist(f["km"]), f["dir"]))
            elif f["km"] <= alert_km * 2.7 and (f.get("count") or 1) >= 10:
                bump(1, "LARGE FIRE (SATELLITE) %s %s" % (dist(f["km"]), f["dir"]))
        elif f["km"] <= alert_km:
            bump(2, "WILDFIRE %s %s %s" % (f["name"], dist(f["km"]), f["dir"]))
        elif f["km"] <= alert_km * 2.7 and (f.get("acres") or 0) >= 1000 and (f.get("contained") or 0) < 50:
            bump(1, "WILDFIRE %s %s %s, %s ACRES" % (f["name"], dist(f["km"]), f["dir"], format(int(f["acres"]), ",")))
    dr = fr.get("drought") or {}
    if dr.get("main", -1) >= 3:
        bump(1, "D%d %s IN %s" % (dr["main"], DROUGHT_NAMES[dr["main"]], (dr.get("county") or "YOUR COUNTY").upper()))
    scope[0] = "global"
    gd = (snap.get("gdacs") or {}).get("data") or {}
    reds = [e for e in gd.get("events", []) if e["level"] == "RED"]
    if reds:
        bump(2, "%d GDACS RED EVENT%s" % (len(reds), "S" if len(reds) > 1 else ""))
    sp = (snap.get("space") or {}).get("data") or {}
    g = sp.get("g") or 0
    if g >= 4:
        bump(2, "G%d GEOMAGNETIC STORM" % g)
    elif g >= 3:
        bump(1, "G%d GEOMAGNETIC STORM" % g)
    names = ["GREEN", "YELLOW", "ORANGE", "RED"]
    reasons.sort(key=lambda r: -r[0])

    def half(h):
        rs = sorted(h[1], key=lambda r: -r[0])
        return {"level": h[0], "name": names[h[0]], "reasons": [r[1] for r in rs[:6]]}
    return {"level": score, "name": names[score], "reasons": [r[1] for r in reasons[:6]],
            "local": half(part["local"]), "global": half(part["global"])}


LOCAL_QUAKE_KM = 500        # a quake this close to home counts as a LOCAL event


def quake_scope(e):
    loc = CONFIG.get("location") or {}
    try:
        if loc.get("lat") is not None and e.get("lat") is not None and \
                _haversine_km(float(loc["lat"]), float(loc["lon"]), float(e["lat"]), float(e["lon"])) <= LOCAL_QUAKE_KM:
            return "local"
    except Exception:
        pass
    return "global"


def sound_wanted(scope):
    """Does this board's ALERT SOUNDS FOR setting (all / local / global) include this event?"""
    pref = (CONFIG.get("screen") or {}).get("alerts") or "all"
    return pref == "all" or scope in ("any", pref)



# --------------------------------------------------------------------------
# events: "something big just happened" -> alert sound + flash banner
# --------------------------------------------------------------------------
# Each event fires once. What we've already announced is saved in data/events.json
# so a reboot or a browser refresh never replays old alarms. The first time a feed
# loads, everything already in it is marked as seen silently (no alarm storm at boot).
EV = {"seq": 0, "events": [], "seen": {}, "primed": [], "last": {}}
EV_LOCK = threading.Lock()


def load_events():
    if os.path.exists(SEEN_PATH):
        try:
            with open(SEEN_PATH) as f:
                EV.update(json.load(f))
        except Exception as e:
            log("events read failed:", e)


def save_events():
    EV["events"] = recent_events()                 # alerts older than 72 h are forgotten
    tmp = SEEN_PATH + ".tmp"
    try:
        with open(tmp, "w") as f:
            json.dump(EV, f)
        os.replace(tmp, SEEN_PATH)
    except Exception as e:
        log("events write failed:", e)


def emit(kind, sev, title, detail="", scope="any", source=None):
    EV["seq"] += 1
    ev = {"seq": EV["seq"], "time": now(), "kind": kind, "sev": sev, "title": title, "detail": detail, "scope": scope,
          "source": source}
    EV["events"] = (EV["events"] + [ev])[-30:]
    log("EVENT", kind, sev, title, "(via mesh)" if source == "mesh" else "")
    if sound_wanted(scope):
        notify_android(ev)
    if not str(title).startswith("TEST ALERT"):
        irlights.alert(sev)
    if MESH and source != "test" and is_pro():
        MESH.queue_alert(ev)


def mesh_alert(kind, sev, title, detail="", source="mesh"):
    with EV_LOCK:
        emit(kind, sev, title, detail, source=source)
        save_events()


MESH = None         # mesh.Mesh (Meshtastic radio link), created in main()


VIBRATE = {1: "300", 2: "400,200,400", 3: "800,200,800,200,800"}


def notify_android(ev):
    """On Android (Termux + Termux:API), raise a real system notification with vibration.
    Works even when the board isn't open. Silently does nothing anywhere else."""
    if APP_NOTIFY:
        try:
            APP_NOTIFY(int(ev["sev"]), str(ev["title"]), str(ev.get("detail") or ""))
        except Exception as e:
            log("app notify failed:", e)
        return
    if not shutil.which("termux-notification"):
        return
    sev = max(1, min(3, int(ev["sev"])))
    cmd = ["termux-notification", "--id", "crashboard-%d" % ev["seq"], "--group", "crashboard",
           "--title", ("\u26a0 " if sev >= 2 else "") + ev["title"],
           "--content", (ev["detail"] or "Tap to open Crash Board")[:300],
           "--priority", "max" if sev >= 2 else "high",
           "--vibrate", VIBRATE[sev], "--led-color", "ff3b2f" if sev >= 3 else "ffb22e",
           "--action", "termux-open-url http://127.0.0.1:%d/" % PORT]
    if sev >= 2:
        cmd.append("--sound")
    try:
        subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if sev >= 3 and shutil.which("termux-tts-speak"):
            subprocess.Popen(["termux-tts-speak", "Flash traffic. " + ev["title"]],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception as e:
        log("android notify failed:", e)


def detect_events(name, data):
    """Look for new, significant items in a feed's fresh data."""
    if not data:
        return
    t = now()
    found = []          # (key, kind, sev, title, detail)
    if name == "quakes":
        amin = float(CONFIG.get("alert_quake_mag", 7.0))
        for e in data.get("events", []):
            if e["mag"] >= amin and t - e["time"] < 6 * 3600:
                found.append(("q:" + str(e["id"]), "seismic", 3 if e["mag"] >= 8 else 2,
                              "M%.1f EARTHQUAKE" % e["mag"],
                              e["place"] + (" · TSUNAMI FLAG" if e.get("tsunami") else ""), quake_scope(e)))
    elif name == "tsunami":
        for e in data.get("events", []):
            if e["level"] != "INFO" and e["time"] and t - e["time"] < 6 * 3600:
                found.append(("t:%s:%s:%s" % (e["center"], e["title"], e["level"]), "klaxon",
                              3 if e["level"] == "WARNING" else 2, "TSUNAMI " + e["level"], e["title"]))
    elif name == "alerts":
        for a in data.get("alerts", []):
            if a["severity"] in ("Extreme", "Severe") and a.get("local", True):
                found.append(("a:" + str(a.get("id")), "weather", 3 if a["severity"] == "Extreme" else 2,
                              (a["event"] or "WEATHER ALERT").upper(), a.get("area") or ""))
    elif name == "gdacs":
        for e in data.get("events", []):
            if e["level"] == "RED":
                found.append(("g:" + str(e.get("id") or e["title"][:60]), "chirp", 2,
                              "GDACS RED " + e["type"], e["title"][:140]))
    elif name == "outbreaks":
        for n in data.get("cdc", []):
            if n["level"] >= 3:
                found.append(("c%d:%s" % (n["level"], n["title"]), "bio", 2 if n["level"] >= 4 else 1,
                              "CDC LEVEL %d TRAVEL NOTICE" % n["level"], n["title"]))
        for w in data.get("who", []):
            if w["high"] and w["time"] and t - w["time"] < 3 * 86400:
                found.append(("w:" + w["link"], "bio", 2, "WHO OUTBREAK REPORT", w["title"]))
    elif name == "space":
        g = data.get("g") or 0
        if g >= 4:
            found.append(("s:%d:%s" % (g, time.strftime("%Y%m%d", time.gmtime())), "space",
                          3 if g >= 5 else 2, "G%d GEOMAGNETIC STORM" % g, "Power grid, HF radio and GPS may be affected"))
    elif name == "fire":
        alert_km = float(CONFIG.get("fire_alert_mi", 15)) * 1.609
        imp = CONFIG.get("units") == "imperial"
        for f in data.get("fires", []):
            if f.get("kind") == "hotspot" and (f.get("count") or 1) < 2:
                continue                               # a single satellite pixel can be a false alarm
            if f["km"] <= alert_km or (f.get("level") == "EMERGENCY WARNING" and f["km"] <= alert_km * 2.7):
                d_txt = "%d MI" % round(f["km"] / 1.609) if imp else "%d KM" % round(f["km"])
                acres = ("%s ACRES" % format(int(f["acres"]), ",")) if f.get("acres") else "SIZE UNKNOWN"
                cont = ("%d%% CONTAINED" % f["contained"]) if f.get("contained") is not None else "CONTAINMENT UNKNOWN"
                if f.get("kind") == "hotspot":
                    found.append(("f:" + str(f["id"]), "fire", 3 if f["km"] <= alert_km / 3 else 2,
                                  "FIRE DETECTED %s %s" % (d_txt, f["dir"]), "NASA SATELLITE · " + (f.get("status") or "")))
                    continue
                if f.get("status") and f.get("contained") is None:
                    cont = f["status"]
                crit = f["km"] <= alert_km / 3 or f.get("level") == "EMERGENCY WARNING"
                found.append(("f:" + str(f["id"]), "fire", 3 if crit else 2,
                              "WILDFIRE %s %s" % (d_txt, f["dir"]), "%s · %s · %s" % (f["name"] + ("" if f["name"].endswith("FIRE") else " FIRE"), acres, cont)))
        dr = data.get("drought") or {}
        last = EV["last"].get("drought")
        if dr.get("main") is not None and last is not None and dr["main"] > last and dr["main"] >= 1:
            found.append(("dr:%d:%s" % (dr["main"], dr.get("date")), "chirp", 1,
                          "DROUGHT NOW D%d %s" % (dr["main"], DROUGHT_NAMES[dr["main"]]), dr.get("county") or ""))
        if dr.get("main") is not None:
            EV["last"]["drought"] = dr["main"]
    elif name == "defcon":
        lvl = data.get("level")
        last = EV["last"].get("defcon")
        if lvl and last and lvl < last:
            found.append(("d:%d:%d" % (lvl, int(t)), "klaxon", 3 if lvl <= 2 else 2,
                          "DEFCON ESTIMATE %d" % lvl, "Raised from %d (unofficial OSINT estimate)" % last))
        if lvl:
            EV["last"]["defcon"] = lvl

    with EV_LOCK:
        first = name not in EV["primed"]
        for item in found:
            key, kind, sev, title, detail = item[:5]
            sc = item[5] if len(item) > 5 else ("local" if name in ("alerts", "fire") else "global")
            if key in EV["seen"]:
                continue
            EV["seen"][key] = t
            if not first:
                emit(kind, sev, title, detail, scope=sc)
        if first:
            EV["primed"].append(name)
        # forget keys older than 30 days
        cutoff = t - 30 * 86400
        EV["seen"] = {k: v for k, v in EV["seen"].items() if v > cutoff}
        save_events()


RADIO = None        # radio.Radio, created in main()
BANK = None         # bank.Bank (CRASH BANK), created in main()


def with_radio_alerts(snap):
    """Add warnings decoded off NOAA Weather Radio to the alerts feed (works with no internet)."""
    ra = RADIO.active_alerts() if RADIO else []
    if ra:
        al = snap.setdefault("alerts", {})
        d = dict(al.get("data") or {})
        d["alerts"] = ra + [x for x in (d.get("alerts") or []) if x.get("source") != "radio"]
        d.setdefault("configured", True)
        d.setdefault("source", "NOAA RADIO")
        al["data"] = d
        al.setdefault("updated", now())
        al.setdefault("ok", True)
    return snap


def radio_fips():
    return FIRE_CACHE.get("fips") or ""


def on_radio_alert(a):
    """A SAME header was decoded. Local warnings raise an event (sound, lights) and recheck the colour."""
    if a["level"] >= 1 and a["local"] is not False:
        with EV_LOCK:
            emit("klaxon" if a["level"] >= 3 else "weather" if a["level"] == 2 else "chirp", a["level"],
                 "NOAA RADIO: " + a["event"].upper(), "Received off the air (no internet needed). " + a["raw"], scope="local")
            save_events()
    threading.Thread(target=check_condition, daemon=True).start()


def radio_configure():
    if RADIO:
        threading.Thread(target=lambda: RADIO.configure(CONFIG.get("radio"), radio_fips()), daemon=True).start()


def check_condition():
    with LOCK:
        snap = with_radio_alerts(json.loads(json.dumps(STATE)))
    c = assess(snap)
    with EV_LOCK:
        last = EV["last"].get("condition")
        for sc in ("local", "global"):
            h, k = c[sc], "cond_" + sc
            was = EV["last"].get(k, last)
            if was is not None and h["level"] > was and h["level"] >= 2:
                emit("klaxon" if h["level"] == 3 else "chirp", h["level"],
                     sc.upper() + " CONDITION " + h["name"], (h["reasons"] or [""])[0], scope=sc)
            EV["last"][k] = h["level"]
        if last is not None and c["level"] > last and c["level"] == 1:
            irlights.alert(1)
        irlights.condition(c["level"], last)
        EV["last"]["condition"] = c["level"]
        save_events()

LIC = None          # license.License, created in main()
UPD = None          # updater.Updater (signed self-updates), created in main()


def ban_list_loop():
    """About once a day when online, check LL3D's list of cancelled PRO keys. Offline boards keep PRO."""
    time.sleep(90)
    while True:
        try:
            if LIC and LIC.key:
                LIC.check_bans()
        except Exception as e:
            log("license: ban list check failed:", e)
        time.sleep(6 * 3600 if LIC and LIC.key and LIC.bans == {} else 24 * 3600)


def activation_loop():
    """A key entered while offline waits here until the board can reach LL3D's activation service."""
    time.sleep(30)
    while True:
        try:
            if LIC and LIC.pending:
                LIC.retry_activation()
        except Exception as e:
            log("license: activation retry failed:", e)
        time.sleep(600 if LIC and LIC.pending else 3600)


def lic_info():
    if LIC:
        return LIC.info()
    return {"tier": "free", "free_themes": ["ops", "blackout", "halloween", "nvg"], "features": {}}


def is_pro():
    return bool(LIC and LIC.pro)


_LAN = {"ip": "", "t": 0}


def lan_ip():
    """This computer's address on the home network (what a display types in)."""
    if time.time() - _LAN["t"] > 60:
        ip = ""
        try:
            u = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            u.connect(("8.8.8.8", 80))                 # no packet is sent; just picks the outgoing interface
            ip = u.getsockname()[0]
            u.close()
        except OSError:
            pass
        _LAN.update(ip=ip if ip and not ip.startswith("127.") else "", t=time.time())
    return _LAN["ip"]


def wifi_rescue():
    """SD-card image only: the setup helper opens its own Wi-Fi when no known network is reachable."""
    try:
        with open(os.environ.get("CB_SETUP_STATUS", "/run/crashboard-setup/status.json")) as f:
            st = json.load(f)
        if st.get("phase") == "hotspot" and not st.get("first") and time.time() - st.get("updated", 0) < 900:
            return {"ap": st.get("ap") or "CRASHBOARD-SETUP"}
    except (OSError, ValueError):
        pass
    return None


ALERT_MAX_AGE = 72 * 3600     # alerts older than 72 hours are dropped from every screen unless still active


def prune_stale(snap, t=None):
    """Drop alerts older than 72 h that no longer matter. Still-active things stay whatever their age:
    NWS warnings until they expire, GDACS events while GDACS lists them as current, CDC travel notices while
    posted, WHO reports about high-consequence diseases (Ebola, Marburg, plague...), and burning wildfires."""
    t = t or now()
    old = lambda x: bool(x.get("time")) and t - x["time"] > ALERT_MAX_AGE
    d = (snap.get("news") or {}).get("data")
    if isinstance(d, dict) and isinstance(d.get("items"), list):
        d["items"] = [x for x in d["items"] if not old(x)]
    d = (snap.get("outbreaks") or {}).get("data")
    if isinstance(d, dict) and isinstance(d.get("who"), list):
        d["who"] = [x for x in d["who"] if x.get("high") or not old(x)]
    d = (snap.get("alerts") or {}).get("data")
    if isinstance(d, dict) and isinstance(d.get("alerts"), list):
        d["alerts"] = [x for x in d["alerts"] if not (x.get("expires") and isinstance(x["expires"], (int, float)) and x["expires"] < t)]
    d = (snap.get("tsunami") or {}).get("data")
    if isinstance(d, dict) and isinstance(d.get("events"), list):
        d["events"] = [x for x in d["events"] if not old(x)]
    return snap


def recent_events(t=None):
    t = t or now()
    return [e for e in EV["events"] if not e.get("time") or t - e["time"] <= ALERT_MAX_AGE]


def snapshot():
    with LOCK:
        snap = prune_stale(with_radio_alerts(json.loads(json.dumps(STATE))))
    cfg = {k: CONFIG[k] for k in ("location", "units", "quake_min_mag", "alert_quake_mag", "fire_list_mi", "fire_alert_mi", "au_bom", "doomsday",
                                  "defcon", "callsign", "news_feeds", "news_keywords", "theme", "mesh", "lang",
                                  "setup_done", "profile", "screen", "auto_update")}
    if not is_pro() and cfg.get("theme") not in lic_info()["free_themes"]:
        cfg["theme"] = "ops"                         # PRO scheme saved earlier, license since removed
    return {"server_time": now(), "version": VERSION, "config": cfg, "license": lic_info(),
            "update": UPD.info() if UPD else None,
            "countries": regions.country_list(),
            "condition": assess(snap), "feeds": snap,
            "has_map": os.path.exists(MAP_PATH),
            "events": recent_events()[-15:], "event_seq": EV["seq"], "setup": wifi_rescue(),
            "address": {"ip": "" if APP else lan_ip(), "port": PORT},
            "mesh": ({"status": MESH.status, "seq": MESH.seq, "me": MESH.me} if MESH else None)}


# --------------------------------------------------------------------------
# HTTP
# --------------------------------------------------------------------------
MIME = {".html": "text/html; charset=utf-8", ".js": "application/javascript; charset=utf-8",
        ".css": "text/css; charset=utf-8", ".svg": "image/svg+xml", ".png": "image/png",
        ".ico": "image/x-icon", ".json": "application/json", ".webmanifest": "application/manifest+json"}


class Handler(BaseHTTPRequestHandler):
    server_version = "CrashBoard/" + VERSION

    def log_message(self, *a):
        pass

    def send(self, code, body, ctype="application/json", cache="no-store"):
        if isinstance(body, (dict, list)):
            body = json.dumps(body, separators=(",", ":")).encode()
        elif isinstance(body, str):
            body = body.encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        self.end_headers()
        self.wfile.write(body)

    def wifi_proxy(self, method, body=None):
        """SD-card image only: pass Wi-Fi requests to the setup helper (it runs as root on this Pi)."""
        if not os.path.exists("/etc/crashboard-image") and not os.environ.get("CB_WIFI_PROXY"):
            return self.send(404, {"error": "Wi-Fi settings are only on Crash Board SD-card setups."})
        url = os.environ.get("CB_WIFI_PROXY", "http://127.0.0.1:80") + urllib.parse.urlparse(self.path).path
        data = json.dumps(body or {}).encode() if method == "POST" else None
        try:
            req = urllib.request.Request(url, data=data, method=method, headers={"Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=60) as r:
                return self.send(r.status, json.loads(r.read()))
        except urllib.error.HTTPError as e:
            try:
                return self.send(e.code, json.loads(e.read()))
            except ValueError:
                return self.send(e.code, {"error": "Wi-Fi helper error"})
        except Exception:
            return self.send(503, {"error": "Wi-Fi helper is not running."})

    def do_GET(self):
        path = urllib.parse.urlparse(self.path).path
        if path.startswith("/api/wifi/"):
            return self.wifi_proxy("GET")
        if path == "/api/lite":
            return self.send(200, lite.build(snapshot()))
        if path == "/api/state":
            return self.send(200, snapshot())
        if path == "/api/ir":
            return self.send(200, self.ir_status())
        if path == "/api/radio":
            return self.send(200, RADIO.status() if RADIO else {"tools_ok": False, "devices": 0})
        if path == "/api/radio/audio":
            return self.radio_audio()
        if path == "/api/mesh":
            q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            since = int((q.get("since") or ["0"])[0] or 0)
            return self.send(200, MESH.snapshot(since, CONFIG.get("location")) if MESH else {"lib": False})
        if path.startswith("/api/bank/") or path.startswith("/bank/file/"):
            return self.bank_get(path)
        if path == "/api/map":
            if os.path.exists(MAP_PATH):
                with open(MAP_PATH) as f:
                    return self.send(200, f.read(), "text/plain", "max-age=86400")
            return self.send(404, "")
        if path in ("/", ""):
            path = "/index.html"
        fp = os.path.normpath(os.path.join(STATIC, path.lstrip("/")))
        if not fp.startswith(STATIC) or not os.path.isfile(fp):
            return self.send(404, {"error": "not found"})
        with open(fp, "rb") as f:
            self.send(200, f.read(), MIME.get(os.path.splitext(fp)[1], "application/octet-stream"),
                      "no-cache")

    def do_POST(self):
        path = urllib.parse.urlparse(self.path).path
        if path == "/api/bank/upload":
            return self.bank_upload()
        try:
            n = int(self.headers.get("Content-Length") or 0)
            body = json.loads(self.rfile.read(n) or b"{}")
        except Exception:
            return self.send(400, {"error": "bad json"})
        if path.startswith("/api/wifi/"):
            return self.wifi_proxy("POST", body)
        if path == "/api/settings":
            return self.settings(body)
        if path.startswith("/api/ir"):
            return self.ir_post(path, body)
        if path.startswith("/api/radio"):
            return self.radio_post(path, body)
        if path == "/api/mesh/send":
            if not is_pro():
                return self.send(402, {"error": "Sending on the mesh is part of Crash Board PRO."})
            if not MESH:
                return self.send(503, {"error": "Mesh radio isn't available on this device."})
            try:
                m = MESH.send(str(body.get("text") or ""), str(body.get("to") or "^all"), int(body.get("channel") or 0))
                return self.send(200, {"ok": True, "message": m})
            except Exception as e:
                return self.send(400, {"error": str(e)})
        if path == "/api/mesh/reconnect":
            if MESH:
                MESH.request_reconnect()
            return self.send(200, {"ok": True})
        if path.startswith("/api/bank/"):
            return self.bank_post(path, body)
        if path == "/api/test-alert":
            with EV_LOCK:
                emit(str(body.get("kind") or "chirp")[:12], int(body.get("sev") or 2),
                     "TEST ALERT", "This is a test of the Crash Board alert system", source="test")
            return self.send(200, {"ok": True})
        if path == "/api/update/check":
            if not UPD:
                return self.send(503, {"error": "updates aren't available on this device"})
            UPD.check_online()
            return self.send(200, {"ok": True, "update": UPD.info()})
        if path == "/api/update/install":
            if not UPD:
                return self.send(503, {"error": "updates aren't available on this device"})
            def go():
                try:
                    UPD.install_online()
                except Exception as e:
                    UPD.error = str(e)
                    log("update:", e)
            threading.Thread(target=go, daemon=True).start()
            return self.send(200, {"ok": True})
        if path == "/api/license":
            if not LIC:
                return self.send(500, {"error": "licensing not available"})
            try:
                LIC.activate(str(body.get("key") or ""))
                log("license: PRO activated, order", LIC.rec.get("o"))
                threading.Thread(target=LIC.check_bans, daemon=True).start()   # a fresh look at LL3D's ban list
                return self.send(200, {"ok": True, "license": lic_info()})
            except ValueError as e:
                return self.send(400, {"error": str(e)})
        if path == "/api/license/release":
            if LIC:
                try:
                    LIC.release()
                    log("license: board released")
                except ValueError as e:
                    return self.send(400, {"error": str(e)})
            return self.send(200, {"ok": True, "license": lic_info()})
        if path == "/api/license/remove":
            if LIC:
                LIC.remove()
            return self.send(200, {"ok": True, "license": lic_info()})
        if path == "/api/refresh":
            # Cooldown: don't re-fetch a feed that was checked in the last 30 s,
            # so repeated taps can't hammer the public data services.
            t = now()
            with LOCK:
                due = [n for n in COLLECTORS if t - (STATE.get(n, {}).get("attempted") or 0) > 30]
            refresh_soon(*due)
            return self.send(200, {"ok": True, "queued": due, "time": t})
        self.send(404, {"error": "not found"})

    # ---------------------------------------------------------- CRASH BANK (PRO file library)
    def bank_locked(self):
        if not BANK:
            self.send(503, {"error": "Crash Bank isn't available"})
            return True
        if not is_pro():
            self.send(402, {"error": "Crash Bank is part of Crash Board PRO.", "locked": True})
            return True
        return False

    def bank_get(self, path):
        if self.bank_locked():
            return
        q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
        arg = lambda k: (q.get(k) or [""])[0]
        try:
            if path == "/api/bank/info":
                return self.send(200, BANK.info())
            if path == "/api/bank/list":
                return self.send(200, BANK.listdir(arg("path")))
            if path == "/api/bank/search":
                return self.send(200, BANK.search(arg("q")))
            if path.startswith("/bank/file/"):
                rel = urllib.parse.unquote(path[len("/bank/file/"):])
                full, ctype, size = BANK.file(rel)
                return self.bank_send_file(full, ctype, size, arg("dl") == "1")
        except bank.BankError as e:
            return self.send(404 if str(e) == "not found" else 400, {"error": str(e)})
        return self.send(404, {"error": "not found"})

    def bank_send_file(self, full, ctype, size, download):
        start, end = 0, size - 1
        rng = self.headers.get("Range") or ""
        m = re.match(r"bytes=(\d*)-(\d*)$", rng.strip())
        if m and size:
            if m.group(1):
                start = int(m.group(1)); end = int(m.group(2)) if m.group(2) else size - 1
            elif m.group(2):
                start = max(0, size - int(m.group(2)))
            end = min(end, size - 1)
            if start > end:
                self.send_response(416); self.send_header("Content-Range", "bytes */%d" % size); self.end_headers(); return
            self.send_response(206)
            self.send_header("Content-Range", "bytes %d-%d/%d" % (start, end, size))
        else:
            self.send_response(200)
        name = os.path.basename(full)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(end - start + 1 if size else 0))
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Security-Policy", "sandbox; default-src 'none'; img-src 'self'; media-src 'self'; style-src 'unsafe-inline'")
        self.send_header("Content-Disposition", "%s; filename*=UTF-8''%s" % ("attachment" if download else "inline", urllib.parse.quote(name)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        try:
            with open(full, "rb") as f:
                f.seek(start)
                left = end - start + 1 if size else 0
                while left > 0:
                    c = f.read(min(1 << 20, left))
                    if not c:
                        break
                    self.wfile.write(c)
                    left -= len(c)
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            pass

    def bank_upload(self):
        if self.bank_locked():
            return
        q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
        arg = lambda k: (q.get(k) or [""])[0]
        try:
            BANK.check_pin(self.headers.get("X-Bank-Pin"))
            n = int(self.headers.get("Content-Length") or 0)
            res = BANK.upload(arg("path"), arg("name"), n, self.rfile.read)
            log("bank: uploaded", res["name"], res["size"], "bytes")
            return self.send(200, res)
        except PermissionError as e:
            self.close_connection = True
            return self.send(403, {"error": str(e)})
        except (bank.BankError, OSError) as e:
            self.close_connection = True
            return self.send(400, {"error": str(e)})

    def bank_post(self, path, b):
        if self.bank_locked():
            return
        bc = CONFIG.setdefault("bank", dict(bank.DEFAULT))
        try:
            BANK.check_pin(self.headers.get("X-Bank-Pin") or b.get("pin_now"))
            if path == "/api/bank/mkdir":
                return self.send(200, BANK.mkdir(str(b.get("path") or ""), b.get("name")))
            if path == "/api/bank/rename":
                return self.send(200, BANK.rename(str(b.get("path") or ""), b.get("name")))
            if path == "/api/bank/delete":
                res = BANK.delete(str(b.get("path") or ""))
                log("bank: deleted", b.get("path"))
                return self.send(200, res)
            if path == "/api/bank/settings":
                if "pin" in b:
                    pin = str(b.get("pin") or "").strip()
                    if pin and not re.match(r"^\d{4,8}$", pin):
                        raise bank.BankError("the PIN must be 4 to 8 digits")
                    bc["pin"] = pin
                if "dir" in b:
                    bc["dir"] = str(b.get("dir") or "").strip()[:300]
                save_config()
                BANK.configure(bc)
                return self.send(200, BANK.info())
        except PermissionError as e:
            return self.send(403, {"error": str(e)})
        except (bank.BankError, OSError) as e:
            return self.send(400, {"error": str(e)})
        return self.send(404, {"error": "not found"})

    # ---------------------------------------------------------- RADIO (RTL-SDR)
    def radio_audio(self):
        if not RADIO:
            return self.send(503, {"error": "radio not available"})
        q, rate = RADIO.subscribe()
        try:
            self.send_response(200)
            self.send_header("Content-Type", "application/octet-stream")
            self.send_header("X-Audio-Rate", str(rate))
            self.send_header("Cache-Control", "no-store")
            self.send_header("Connection", "close")
            self.end_headers()
            while True:
                c = q.get(timeout=20)
                if c is None:
                    break
                self.wfile.write(c)
        except (queue.Empty, BrokenPipeError, ConnectionResetError, ConnectionAbortedError, OSError):
            pass
        finally:
            RADIO.unsubscribe(q)

    def radio_post(self, path, b):
        if not RADIO:
            return self.send(503, {"error": "radio not available"})
        rc = CONFIG.setdefault("radio", dict(radio.DEFAULT))
        try:
            if path == "/api/radio":
                if "enabled" in b:
                    rc["enabled"] = bool(b["enabled"])
                if "watch" in b:
                    rc["watch"] = bool(b["watch"])
                if "noaa_freq" in b:
                    f = round(float(b["noaa_freq"]), 3)
                    if f not in radio.NOAA_CHANNELS:
                        raise ValueError("not a NOAA channel")
                    rc["noaa_freq"] = f
                if "ppm" in b:
                    rc["ppm"] = max(-200, min(200, int(b["ppm"] or 0)))
                if "gain" in b:
                    g = str(b["gain"] or "").strip()
                    rc["gain"] = "" if g.lower() in ("", "auto") else str(max(0.0, min(50.0, float(g))))
                if "presets" in b:
                    out = []
                    for x in (b["presets"] or [])[:40]:
                        band = x.get("band") if x.get("band") in radio.BANDS else "fm"
                        out.append({"name": re.sub(r"[^\w .&'/+-]", "", str(x.get("name") or ""))[:24].strip() or "STATION",
                                    "freq": round(float(x.get("freq") or 0), 3), "band": band})
                    rc["presets"] = out
                save_config()
                RADIO.configure(rc, radio_fips())
                return self.send(200, RADIO.status())
            if path == "/api/radio/listen":
                return self.send(200, RADIO.listen(b))
            if path == "/api/radio/stop":
                return self.send(200, RADIO.stop())
            if path == "/api/radio/scan":
                res = RADIO.scan_noaa()
                return self.send(200, res)
            if path in ("/api/radio/install", "/api/radio/reboot"):
                import ipaddress
                try:
                    ip = ipaddress.ip_address(self.client_address[0].split("%")[0].replace("::ffff:", ""))
                    if not (ip.is_private or ip.is_loopback or ip.is_link_local):
                        return self.send(403, {"error": "only from your own network"})
                except ValueError:
                    pass
                if path == "/api/radio/install":
                    RADIO.installer.start()
                else:
                    RADIO.installer.reboot()
                return self.send(200, RADIO.status())
            if path == "/api/radio/redetect":
                RADIO.refresh_hw()
                return self.send(200, RADIO.status())
        except (ValueError, TypeError) as e:
            return self.send(400, {"error": str(e)})
        return self.send(404, {"error": "not found"})

    # ---------------------------------------------------------- ALERT LIGHTS (IR LED strip)
    def ir_status(self):
        slot, code = irlights.take_learned()
        if slot:
            CONFIG["ir"].setdefault("codes", {})[slot] = code
            save_config()
            irlights.configure(CONFIG["ir"])
        return irlights.status()

    def ir_post(self, path, b):
        ir = CONFIG.setdefault("ir", dict(irlights.DEFAULT))
        try:
            if path == "/api/ir":
                if "enabled" in b:
                    ir["enabled"] = bool(b["enabled"])
                if "host" in b:
                    ir["host"] = re.sub(r"[^A-Za-z0-9.:\-_/]", "", str(b["host"]))[:80].strip()
                if b.get("remote") in irlights.PRESETS or b.get("remote") == "custom":
                    ir["remote"] = b["remote"]
                if "min_level" in b:
                    ir["min_level"] = max(1, min(3, int(b["min_level"])))
                if b.get("clear") in ("off", "normal", "none"):
                    ir["clear"] = b["clear"]
            elif path == "/api/ir/test":
                irlights.configure(ir)
                irlights.test(str(b.get("what") or ""))
                return self.send(200, {"ok": True})
            elif path == "/api/ir/learn":
                irlights.configure(ir)
                irlights.learn(str(b.get("slot") or ""))
                return self.send(200, {"ok": True})
            elif path == "/api/ir/forget":
                ir.setdefault("codes", {}).pop(str(b.get("slot") or ""), None)
            else:
                return self.send(404, {"error": "not found"})
        except (ValueError, TypeError) as e:
            return self.send(400, {"error": str(e)})
        save_config()
        irlights.configure(ir)
        return self.send(200, {"ok": True})

    def settings(self, b):
        changed = set()
        try:
            cc_new = str(b.get("country") or CONFIG["location"].get("cc_pref") or "AUTO").upper()
            if "location" in b and (b["location"] != CONFIG["location"].get("query") or
                                    cc_new != (CONFIG["location"].get("cc_pref") or "AUTO")):
                if str(b["location"]).strip():
                    CONFIG["location"] = geocode(b["location"], cc_new)
                    CONFIG["location"].setdefault("cc_pref", cc_new)
                else:
                    CONFIG["location"] = dict(DEFAULT_CONFIG["location"])
                changed |= {"alerts", "weather", "fire"}
            if b.get("lang") in ("en", "es", "fr", "de", "pt"):
                CONFIG["lang"] = b["lang"]
            if b.get("units") in ("imperial", "metric"):
                CONFIG["units"] = b["units"]; changed.add("weather")
            if "quake_min_mag" in b:
                CONFIG["quake_min_mag"] = max(4.5, min(9.0, float(b["quake_min_mag"])))
                QK["big_t"] = 0
                changed.add("quakes")
            for k in ("fire_list_mi", "fire_alert_mi"):
                if k in b:
                    CONFIG[k] = max(1, min(500, int(float(b[k]))))
                    changed.add("fire")
            if "au_bom" in b:
                CONFIG["au_bom"] = bool(b["au_bom"]); changed.add("alerts")
            if "alert_quake_mag" in b:
                CONFIG["alert_quake_mag"] = max(5.0, min(9.5, float(b["alert_quake_mag"])))
            if "doomsday_seconds" in b:
                CONFIG["doomsday"]["seconds"] = int(b["doomsday_seconds"])
            if "doomsday_set" in b:
                CONFIG["doomsday"]["set"] = str(b["doomsday_set"])[:20]
            if b.get("defcon_mode") in ("auto", "manual"):
                CONFIG["defcon"]["mode"] = b["defcon_mode"]; changed.add("defcon")
            if "defcon_manual" in b:
                CONFIG["defcon"]["manual_level"] = max(1, min(5, int(b["defcon_manual"])))
                changed.add("defcon")
            if b.get("theme") in THEMES:
                if not is_pro() and b["theme"] not in lic_info()["free_themes"]:
                    return self.send(402, {"error": "That color scheme is part of Crash Board PRO."})
                CONFIG["theme"] = b["theme"]
            if "callsign" in b:
                CONFIG["callsign"] = str(b["callsign"])[:24] or "CRASH BOARD"
            if "setup_done" in b:
                CONFIG["setup_done"] = bool(b["setup_done"])
            if b.get("profile") in ("home", "wall", "offgrid", "alerts", ""):
                CONFIG["profile"] = b["profile"]
            if isinstance(b.get("screen"), dict):
                sc, cur = b["screen"], CONFIG["screen"]
                cur["set"] = True
                for k in ("sound", "voice"):
                    if k in sc:
                        cur[k] = bool(sc[k])
                if sc.get("alerts") in ("all", "local", "global"):
                    cur["alerts"] = sc["alerts"]
                if "volume" in sc:
                    cur["volume"] = max(0, min(100, int(sc["volume"])))
                if sc.get("fx") in ("", "full", "low", "off"):
                    cur["fx"] = sc["fx"]
                if sc.get("touch") in ("auto", "on", "off"):
                    cur["touch"] = sc["touch"]
                if "cycle" in sc:
                    try:
                        c = int(sc["cycle"])
                        cur["cycle"] = c if c in (0, 10, 20, 30, 60) else 20
                    except (TypeError, ValueError):
                        pass
                if isinstance(sc.get("layout"), dict):
                    cur["layout"] = {str(k)[:20]: v for k, v in list(sc["layout"].items())[:20]
                                     if re.fullmatch(r"[a-z]{2,20}", str(k)) and v in ("min", "big")}
                if isinstance(sc.get("quiet"), dict):
                    q = sc["quiet"]
                    tm = lambda v, d: v if isinstance(v, str) and len(v) == 5 and v[2] == ":" and v.replace(":", "").isdigit() else d
                    cur["quiet"] = {"on": bool(q.get("on")), "start": tm(q.get("start"), "22:00"), "end": tm(q.get("end"), "07:00")}
            if "auto_update" in b:
                CONFIG["auto_update"] = bool(b["auto_update"])
            if isinstance(b.get("mesh"), dict):
                m, old = b["mesh"], dict(CONFIG["mesh"])
                if m.get("mode") in ("auto", "serial", "tcp", "ble"):
                    CONFIG["mesh"]["mode"] = m["mode"]
                if "address" in m:
                    CONFIG["mesh"]["address"] = str(m["address"]).strip()[:120]
                for k in ("enabled", "broadcast_alerts", "relay_inbound"):
                    if k in m:
                        CONFIG["mesh"][k] = bool(m[k])
                if "alert_min_sev" in m:
                    CONFIG["mesh"]["alert_min_sev"] = 3 if int(m["alert_min_sev"]) >= 3 else 2
                if "alert_channel" in m:
                    CONFIG["mesh"]["alert_channel"] = max(0, min(7, int(m["alert_channel"])))
                if any(CONFIG["mesh"].get(k) != old.get(k) for k in ("enabled", "mode", "address")) and MESH:
                    MESH.request_reconnect()
            if "news_keywords" in b:
                kw = b["news_keywords"]
                if isinstance(kw, str):
                    kw = [k.strip() for k in kw.split(",")]
                CONFIG["news_keywords"] = [k for k in kw if k][:40]; changed.add("news")
        except Exception as e:
            return self.send(400, {"error": str(e)})
        save_config()
        refresh_soon(*changed)
        self.send(200, {"ok": True, "config": CONFIG})


def port_answers(port):
    """True if something is already listening on this port locally (IPv4 or IPv6).
    Windows can let us bind 0.0.0.0 even while another app holds 127.0.0.1 on the
    same port, so a failed bind alone isn't a reliable 'busy' check."""
    for fam, addr in ((socket.AF_INET, ("127.0.0.1", port)), (socket.AF_INET6, ("::1", port, 0, 0))):
        try:
            with socket.socket(fam, socket.SOCK_STREAM) as s:
                s.settimeout(0.4)
                if s.connect_ex(addr) == 0:
                    return True
        except OSError:
            pass
    return False


class BoardServer(ThreadingHTTPServer):
    daemon_threads = True
    # On Windows, SO_REUSEADDR lets two programs share a port silently; never do that there.
    allow_reuse_address = os.name != "nt"

    def server_bind(self):
        if os.name == "nt" and hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        super().server_bind()


def main(argv=None):
    ap = argparse.ArgumentParser()
    # data/fixed-port.txt (one number) pins the port, e.g. when another program on this PC owns 8080
    want = os.environ.get("CRASHBOARD_PORT")
    if not want:
        try:
            want = open(os.path.join(DATA, "fixed-port.txt")).read().strip()
        except OSError:
            want = ""
    ap.add_argument("--port", type=int, default=int(want) if want.isdigit() else 8080)
    ap.add_argument("--host", default="0.0.0.0")
    ap.add_argument("--no-poll", action="store_true", help="serve cached data only (testing)")
    a = ap.parse_args(argv)
    load_config()
    irlights.configure(CONFIG.get("ir"))
    global RADIO, BANK
    RADIO = radio.Radio(log, on_radio_alert)
    RADIO.installer = radio.RadioInstaller(RADIO, log)
    BANK = bank.Bank(DATA)
    BANK.configure(CONFIG.get("bank"))
    radio_configure()
    load_cache()
    load_events()
    global LIC
    import license as license_mod
    LIC = license_mod.License(DATA, log)
    global UPD
    if not getattr(sys, "frozen", False):                    # the Windows exe updates by reinstalling
        try:
            import updater
            edition = "crashboard"                              # one edition now (Mesh is built in)
            UPD = updater.Updater(BASE, DATA, edition, VERSION, license_mod.PUBLIC_KEY_HEX, license_mod.verify_sig, log)
            if APP and APP_RESTART:
                UPD.restart_hook = APP_RESTART               # phone: tap INSTALL, the app reopens on the new version
            threading.Thread(target=UPD.loop, args=(lambda: CONFIG.get("auto_update", True),
                                                   lambda: assess(json.loads(json.dumps(STATE)))["level"] < 3),
                             daemon=True, name="updater").start()
        except Exception as e:
            log("updater not started:", e)
    log("license:", "PRO (order %s)" % LIC.rec.get("o") if LIC.pro else "FREE")
    threading.Thread(target=ban_list_loop, daemon=True, name="ban-list").start()
    threading.Thread(target=activation_loop, daemon=True, name="activation").start()
    global MESH
    try:                                       # Meshtastic radio (COMMS); does nothing until turned on
        import mesh as mesh_mod
        MESH = mesh_mod.Mesh(DATA, lambda: CONFIG["mesh"], mesh_alert, log)
        if not a.no_poll and not APP:
            MESH.start()
    except Exception as e:
        log("mesh not started:", e)
    if not a.no_poll:
        threading.Thread(target=poller, daemon=True).start()
        threading.Thread(target=map_thread, daemon=True).start()
    # If the port is taken (another app already uses 8080), try the next ones.
    srv, port = None, a.port
    for port in list(range(a.port, a.port + 20)) + [0]:
        if port and port_answers(port):
            log("port %d already answered by another program, trying next" % port)
            continue
        try:
            srv = BoardServer((a.host, port), Handler)
            break
        except OSError:
            log("port %d busy, trying next" % port)
    port = srv.server_address[1]
    global PORT
    PORT = port
    with open(os.path.join(DATA, "port.txt"), "w") as f:
        f.write(str(port))
    if not APP:                    # a phone is never a host for small displays
        lite.start_discovery(port, lambda: CONFIG.get("callsign") or "CRASH BOARD", VERSION,
                            "mesh" if os.path.exists(os.path.join(BASE, "mesh.py")) else "crashboard")   # small displays find us
    log("CRASH BOARD %s on http://%s:%d%s" % (VERSION, a.host, port, "  [mobile data saver]" if MOBILE else ""))
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
