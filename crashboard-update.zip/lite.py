"""Compact summary of the board for small screens (ESP32 "Crash Board Lite" displays), plus
automatic discovery so those displays find this board on the network without typing an address.

  GET /api/lite            -> a few KB of JSON (see build())
  UDP 47474 "CRASHBOARD?"  -> replies {"crashboard": 1, "port": 8080, "name": ..., "version": ...}
"""
import json
import socket
import threading
import time

DISCOVERY_PORT = 47474


def _r(v, n=1):
    return None if v is None else round(v, n)


def _i(v):
    """Whole numbers as JSON integers (71, not 71.0): small displays read these as ints."""
    return None if v is None else int(round(v))


def build(snap):
    feeds = snap.get("feeds") or {}
    cfg = snap.get("config") or {}

    def data(name):
        return (feeds.get(name) or {}).get("data") or {}

    cond = snap.get("condition") or {}
    out = {
        "v": 1, "t": int(snap.get("server_time") or time.time()),
        "tz": -time.altzone if time.localtime().tm_isdst > 0 else -time.timezone,
        "name": cfg.get("callsign") or "CRASH BOARD", "ver": snap.get("version"),
        "theme": cfg.get("theme") or "ops", "lang": cfg.get("lang") or "en", "units": cfg.get("units") or "imperial",
        "pro": (snap.get("license") or {}).get("tier") == "pro",
        "cond": {"level": cond.get("level", 0), "name": cond.get("name", "GREEN"), "reasons": (cond.get("reasons") or [])[:4],
                 # LOCAL / GLOBAL halves for the split banner (Lite 0.1.9+; older Lites ignore them)
                 **{k: {"level": (cond.get(k) or {}).get("level", 0), "name": (cond.get(k) or {}).get("name", "GREEN"),
                        "reasons": ((cond.get(k) or {}).get("reasons") or [])[:3]} for k in ("local", "global") if cond.get(k)}},
        "seq": snap.get("event_seq") or 0,
        "events": [{"seq": e.get("seq"), "sev": e.get("sev"), "title": e.get("title"), "detail": (e.get("detail") or "")[:80],
                    "scope": e.get("scope") or "any", "time": int(e.get("time") or 0)}
                   for e in (snap.get("events") or [])[-5:]],
    }
    loc = cfg.get("location") or {}
    if loc.get("lat") is not None:
        out["loc"] = {"name": loc.get("name"), "lat": _r(loc.get("lat"), 3), "lon": _r(loc.get("lon"), 3), "cc": loc.get("country")}
    dc = data("defcon")
    if dc.get("level"):
        out["defcon"] = {"level": dc["level"], "src": dc.get("source", "")}
    dd = cfg.get("doomsday") or {}
    if dd.get("seconds"):
        out["doom"] = _i(dd["seconds"])
    w = data("weather")
    if w.get("configured"):
        out["wx"] = {"temp": _r(w.get("temp"), 0), "feels": _r(w.get("feels"), 0), "rh": _r(w.get("rh"), 0),
                     "wind": _r(w.get("wind"), 0), "wdir": _i(w.get("wdir")), "gust": _r(w.get("gust"), 0),
                     "press": _r(w.get("pressure"), 0), "cloud": _r(w.get("cloud"), 0), "precip": w.get("precip"),
                     "cond": w.get("cond"), "sunrise": (w.get("sunrise") or "")[11:16], "sunset": (w.get("sunset") or "")[11:16],
                     "days": [{"d": x.get("date"), "hi": _i(x.get("hi")), "lo": _i(x.get("lo")), "cond": x.get("cond"),
                               "pop": _i(x.get("pop"))} for x in (w.get("days") or [])[:4]]}
    al = data("alerts")
    rank = {"Extreme": 3, "Severe": 2, "Moderate": 1}
    out["alerts"] = [{"ev": (a.get("event") or "").upper()[:48], "sev": rank.get(a.get("severity"), 0),
                      "area": str(a.get("area") or "").upper()[:48], "exp": int(a["expires"]) if a.get("expires") else 0,
                      "local": a.get("local") is not False}
                     for a in (al.get("alerts") or [])[:8]]
    if al.get("note"):
        out["alerts_note"] = al["note"][:80]
    q = data("quakes")
    out["quakes"] = [{"m": e.get("mag"), "p": (e.get("place") or "")[:48], "t": int(e.get("time") or 0),
                      "lat": _r(e.get("lat"), 2), "lon": _r(e.get("lon"), 2), "d": _r(e.get("depth"), 0),
                      "tsu": 1 if e.get("tsunami") else 0} for e in (q.get("events") or [])[:12]]
    sp = data("space")
    if sp:
        out["space"] = {"g": sp.get("g") or 0, "kp": _r(sp.get("kp"), 2), "peak": _r(sp.get("kp_peak_24h"), 1),
                        "series": [_r(k, 1) for k in (sp.get("series") or [])[-24:]]}
    fr = data("fire")
    if fr.get("configured"):
        fires = fr.get("fires") or []
        out["fire"] = {"near": fr.get("nearby") or 0,
                       "list": [{"n": (f.get("name") or "")[:28], "km": _r(f.get("km"), 1), "dir": f.get("dir"),
                                 "acres": _r(f.get("acres"), 0), "cont": _r(f.get("contained"), 0)} for f in fires[:5]]}
        dr = fr.get("drought") or {}
        if dr.get("worst") is not None:
            out["fire"]["drought"] = dr.get("worst")
    ob = data("outbreaks")
    if ob:
        lst = [{"t": (n.get("title") or "")[:60], "lvl": n.get("level") or 0, "src": "CDC"} for n in (ob.get("cdc") or []) if (n.get("level") or 0) >= 2]
        lst += [{"t": (w.get("title") or "")[:60], "lvl": 2 if w.get("high") else 1, "src": "WHO"} for w in (ob.get("who") or [])[:3]]
        out["outbreaks"] = lst[:6]
    out["news"] = [{"src": n.get("src"), "t": (n.get("title") or "")[:90]} for n in (data("news").get("items") or [])[:5]]
    ts = data("tsunami")
    out["tsunami"] = [{"lvl": e.get("level"), "t": (e.get("title") or "")[:60]} for e in (ts.get("events") or [])[:3]
                      if e.get("level") in ("WARNING", "ADVISORY", "WATCH", "THREAT")]
    return out


def start_discovery(port, name_fn, version, edition="crashboard"):
    """Answer 'CRASHBOARD?' broadcasts so displays can find this board."""
    def run():
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            if hasattr(socket, "SO_REUSEPORT"):        # both editions on one computer can answer
                s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
            s.bind(("0.0.0.0", DISCOVERY_PORT))
        except OSError:
            return                                    # another board on this machine already answers
        while True:
            try:
                msg, addr = s.recvfrom(256)
                if msg.strip().upper().startswith(b"CRASHBOARD?"):
                    s.sendto(json.dumps({"crashboard": 1, "port": port, "name": name_fn(), "version": version, "edition": edition}).encode(), addr)
            except OSError:
                time.sleep(1)
    threading.Thread(target=run, daemon=True, name="discovery").start()
