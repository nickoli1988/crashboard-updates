# CRASH BOARD™

A rugged, always-on threat board for a Raspberry Pi (Zero W, 3, 4 or 5) (and any phone, tablet or PC on your network).

It tracks:

| Panel | What it shows | Source | Refresh |
|---|---|---|---|
| **Condition banner** | GREEN / YELLOW / ORANGE / RED, worked out from every feed below | computed on the Pi | live |
| **Seismic** | M6.0+ quakes worldwide, last 30 days, on a world plot. Tsunami flag and PAGER level | USGS | 2 min |
| **Tsunami** | Warnings, advisories and watches from both US tsunami warning centers, last 72 h | NOAA NTWC + PTWC | 2 min |
| **Local WX** | Current conditions and a 4-day forecast for your location (works worldwide) | Open-Meteo | 10 min |
| **Local alerts** | Active NWS watches and warnings for your exact location (US only) | api.weather.gov | 2 min |
| **DEFCON** | Open-source **estimate** (see note), or a level you set yourself | defconlevel.com | 30 min |
| **Doomsday Clock** | Seconds to midnight (85 s, set 27 Jan 2026). Change it in CFG when the clock is reset | Bulletin of the Atomic Scientists | manual |
| **Nuclear intel** | Headlines filtered by keywords (nuclear, missile, reactor, …) | IAEA, Bulletin RSS | 30 min |
| **Fire & drought** | Active US wildfires within 100 mi (name, distance/direction, acres, % contained, also on the map) · Red Flag / Fire Weather alerts · your county's drought level (D0–D4) | NIFC, NWS, US Drought Monitor | 10 min (drought daily) |
| **Outbreaks** | CDC travel health notices (Level 2–4) and WHO Disease Outbreak News. Pathogens like Ebola, Marburg and H5N1 bird flu are flagged HIGH-CONSEQUENCE | CDC, WHO | 30 min |
| **Global disasters** | Orange and red alerts for cyclones, floods, volcanoes, wildfires and droughts | GDACS (UN/EU) | 10 min |
| **Space WX / grid** | Geomagnetic storm level (G0–G5) and the Kp trend. G4+ storms can affect power grids, HF radio and GPS | NOAA SWPC | 10 min |

No API keys or accounts needed. Only Python 3 is required (standard library), and there's nothing to `pip install`.

> **Read this:** Crash Board collects public data. It is **not** an official warning system. The real DEFCON level is classified and never published, so the panel shows a third-party OSINT estimate, labeled UNOFFICIAL. For life-safety alerts, keep a NOAA Weather Radio and turn on Wireless Emergency Alerts on your phone.

---


## Easiest install and updates (no typing)

- **Raspberry Pi with a desktop (Pi 3, 4 or 5):**
  1. Copy the Crash Board zip to the Pi, for example from a USB stick into your Home folder.
  2. Right-click the zip and choose **Extract Here**.
  3. Open the folder and double-click **Install Crash Board.sh**, then choose **Execute in Terminal**.

  It installs everything, including the radio drivers, and adds Crash Board to your menu and desktop.
- **Kits from LL3D** come with the SD card already set up. Just plug it in.
- **Updates install themselves.** When a board is online, it updates automatically (CFG → SOFTWARE). Offline, put the two update files from LL3D (`crashboard-update.zip` and `.json`) on a USB stick and plug it into the board. It updates within a minute and keeps your settings. Updates are signed by LL3D, so boards only accept genuine ones.

## Meshtastic COMMS (built in)

Plug in a Meshtastic radio and Crash Board can send and receive messages and alerts with no internet or cell service. The radio link is off until you set up a radio (in first-time setup or CFG → MESHTASTIC RADIO); the **COMMS** button appears once it's on. Reading the mesh and receiving alerts is free; sending is part of PRO.

### What it adds

| Feature | What it does |
|---|---|
| **COMMS drawer** | Tap **COMMS** in the header. **CHAT** shows channel and direct messages, with signal and hop count on each. **NODES** lists every radio heard: battery, SNR, hops, distance from your location, and last heard. |
| **Send from the board** | Type a message, then choose a channel or tap **DM** on any node to message it directly. A byte counter keeps each message within one mesh packet (200 bytes). |
| **Quick buttons** | **✓ SAFE** sends a check-in. **⚠ NEED HELP** sends your coordinates. **SEND CONDITION** sends the board's current threat level and its top reason. **SEND LOCATION** sends your position. |
| **Mesh on the map** | Radios that report GPS show up as cyan diamonds on the seismic map. |
| **Alert broadcast** | Big alerts (M7+ quake, tsunami, severe weather, DEFCON estimate rising, RED condition) are sent to the mesh as short `[CB] …` texts, so every radio in range hears them, even with no internet. Sends are spaced at least 30 s apart to respect shared airtime. |
| **Off-grid relay** | `[CB]` alerts heard from *other* Crash Boards pop up on yours as real alerts, with sound and the FLASH TRAFFIC banner. A board with no internet still gets warnings. Relayed alerts are never re-broadcast, and duplicates from several gateways are merged. |
| **Unread badge** | The COMMS button shows a count of new messages, plus a soft radio chirp if audio is armed. |

### Connecting a radio

Open **CFG → MESHTASTIC RADIO** and tick **RADIO LINK ON**:

- **USB (auto-detect)** is the default. Plug the radio in with a **data** USB cable, not a charge-only one.
- **USB (pick port)**: use this if several USB devices are plugged in. Enter a port such as `/dev/ttyUSB0` or `/dev/ttyACM0` (Pi) or `COM4` (Windows).
- **Wi-Fi (TCP)**: enter the radio's IP address. Turn on Wi-Fi in the radio's settings first.
- **Bluetooth**: enter the radio's name or address. This needs a recent `meshtastic` library.

You can also turn off **BROADCAST BIG ALERTS**, set it to send critical alerts only, choose which channel alerts go out on, and turn off **SHOW ALERTS FROM OTHER BOARDS**.

**Test without a radio:** `python3 tests/test_mesh.py --serve` runs the board with a simulated radio and sample chatter.

**Moving from the old Crash Board Mesh:** install this Crash Board the usual way (double-click **Install Crash Board.sh**). It copies your settings, PRO key and messages from the old `crashboard-mesh` folder and turns the old Mesh service off. The board is now at port **8080**. On Windows, your old Mesh settings are picked up automatically.

## 1. Prepare the Pi Zero W

1. Flash **Raspberry Pi OS Lite (32-bit)** with Raspberry Pi Imager. In the Imager settings, set your Wi-Fi, a username, and turn on SSH.
2. Boot the Pi, then SSH in: `ssh <user>@<pi-hostname>.local`
3. If you're using a small **SPI/GPIO screen** (for example a 3.5" 480×320), install its driver from the vendor first. HDMI screens work as-is.

## 2. Copy and install

```bash
# from your PC (or use a USB stick / git)
scp -r crashboard <user>@<pi-hostname>.local:~/

# on the Pi
cd ~/crashboard
./install.sh --kiosk      # attached screen shows the board at boot
#   or
./install.sh              # server only, view from other devices
sudo reboot
```

What the installer sets up:
- `crashboard.service`, which starts the server at boot and restarts it if it crashes.
- With `--kiosk`: console auto-login, then a minimal X session with a fullscreen browser. On the Zero W it uses **surf**, because Chromium is too heavy for that board.

## 3. Use it

- **On the Pi's screen**, the board cycles through panels every 15 s. Tap the left or right third of the screen (or press the arrow keys) to change panels. When a severe local alert is active, the board comes back to it more often.
- **On any other device**, open `http://<pi-ip>:8080`. Wide screens show every panel at once, and phones scroll. You can also add it to your phone's home screen to use it like an app.
- **REFRESH** (top right, or press **R**) fetches every feed immediately and shows progress (for example SYNCING 4/9, then UPDATED). Feeds checked in the last 30 seconds are skipped, so repeated taps don't hammer the data services.
- **CFG** (top right) sets your location (ZIP code, `City, ST`, or `lat, lon`), units, the minimum quake magnitude, the DEFCON source, the Doomsday Clock value, the callsign, and the intel keywords. It's easiest to do this from your phone, since typing on a small screen is hard.

URL options: `?kiosk=1` forces panel cycling, `?lite=1` turns off animations, and `?dwell=20` sets the seconds per panel.

## Running on Windows

1. Install Python 3 from python.org. On the first installer screen, tick **"Add python.exe to PATH"**.
2. Unzip `crashboard.zip` somewhere permanent, for example `Documents\crashboard`.
3. Double-click **`start-windows.bat`**. The board opens in its own window at `http://localhost:8080`.
   - If Windows Firewall asks, allow **Private networks**. That lets your phone open the board at `http://<pc-ip>:8080`.
4. Optional: double-click **`autostart-windows.bat`** so the server starts silently every time you log in. To undo it, run `autostart-windows.bat remove`.

In the browser, press **F11** for fullscreen. Add `?kiosk=1` to the URL for the rotating single-panel mode.

## Countries and regions

In **CFG**, pick your **COUNTRY**, then type a postcode/ZIP, a town, or `lat, lon`. **AUTO** works out the country from a city name.

| Region | Local alerts | Wildfires | Drought |
|---|---|---|---|
| **United States** | National Weather Service | NIFC incidents | US Drought Monitor (county) |
| **Canada** | Environment Canada | CWFIS (stage of control) | Canadian Drought Monitor (monthly) |
| **UK** | MeteoAlarm + Environment Agency floods (England) | NASA FIRMS satellite | n/a |
| **Europe** (~38 countries) | MeteoAlarm national feed | NASA FIRMS satellite | n/a |
| **Australia** | Bureau of Meteorology (**opt-in, personal use only**) | NSW RFS incidents + NASA FIRMS | n/a |
| **New Zealand** | MetService | NASA FIRMS satellite | n/a |
| **Everywhere else** | none (global panels still work) | NASA FIRMS satellite | n/a |

- MeteoAlarm, BoM and MetService warnings cover a whole country or state. Warnings that mention your town or region are listed first and count toward the condition level. The rest appear under **ELSEWHERE IN …** for awareness only.
- **Satellite fire detections** (NASA FIRMS, last 24 h) are grouped into clusters. A single detection never sets off an alarm, because one hot pixel can be a false alarm such as a factory flare. Two or more within your alarm distance count as a fire.
- Earthquakes, tsunami, outbreaks, space weather, global disasters, DEFCON and nuclear news are worldwide and work everywhere.

### Data terms (important if you sell Crash Board)

| Source | Terms |
|---|---|
| NWS, NIFC, USGS, NOAA, US Drought Monitor, FCC, NASA FIRMS | US government / public. Free to reuse, credit appreciated. |
| Environment Canada, CWFIS, Canadian Drought Monitor | Open Government Licence – Canada. Free to reuse with credit. |
| MeteoAlarm | Licensed on terms equivalent to CC BY 4.0. Credit "MeteoAlarm". |
| Environment Agency (England) | Open Government Licence. Requires the credit line *"this uses Environment Agency flood and river level data from the real-time data API (Beta)"*. |
| **Bureau of Meteorology (Australia)** | **Personal and non-commercial use only.** That's why it's off by default. A commercial product needs a BoM data licence. |
| MetService (NZ) | Check MetService's terms before selling in NZ. |
| Open-Meteo (weather) | Free tier is non-commercial. A commercial product needs their paid plan. |

## FREE and PRO

| FREE | PRO |
|---|---|
| Every data panel, alert, sound and FLASH banner | Everything in FREE |
| Ops and Blackout color schemes | **All** color schemes |
| Small "Supported by LL3D" promo strip | **No promo strip** |
| | **Wi-Fi displays and TV dongles** |
| | **Mesh edition sending** (chat, quick buttons, alert broadcast) |

**Safety is never locked.** The promo strip hides itself whenever the board is at ORANGE or RED, or a FLASH alert is showing. On a Wi-Fi display connected to a FREE host, the condition banner and FLASH alerts still show through the PRO lock.

**Activate PRO:** open **CFG → LICENSE**, paste your key and press **ACTIVATE**. No internet is needed. To move PRO to another board, press **REMOVE KEY FROM THIS BOARD**, then enter the key on the new one.

**Promo strip content** lives in `static/promos.json`: your store address, the short address shown on small screens, the PRO link, and the rotating messages. Edit it with Notepad. No code changes needed.

## Wi-Fi displays (screens with no computer)

One device is the **host**: a Pi 3 or a PC runs Crash Board. Any number of **displays**, for example a Pi Zero W with a 7" screen, show it over Wi-Fi in the **full PC layout**, with every panel on screen at once, zoomed to fit. A display runs no server of its own, so all of its power goes to drawing the board.

**Set up a display (on the display Pi):**
```bash
cd ~ && python3 -m zipfile -e crashboard.zip .
cd crashboard && chmod +x install.sh kiosk.sh
./install.sh --display          # it asks for the host's address, e.g. 192.168.1.40
sudo reboot
```
- To show a **Mesh edition** host, type its address with `:8090`, for example `192.168.1.40:8090`.
- **Host is off?** The display shows a *Connecting to the host…* screen and opens the board as soon as the host answers. If the host drops out later, the board shows **NO LINK** and recovers by itself.
- **Change the host later:** run `./install.sh --display <new address>`, then `sudo reboot`.
- **Turn the display back into a host:** run `./install.sh --kiosk`.
- **Text size:** `LAYOUT_WIDTH=1280` in `data/display.conf` sets how much the page is zoomed. Use a smaller number (e.g. `1100`) for bigger text, or a bigger one for more of a big-monitor look.
- The **color scheme** follows the host. **Effects** and **audio** are set per display, and a Pi Zero starts in FX LOW.
- **Windows host:** when Windows Firewall asks, allow Crash Board on **Private networks**, or displays can't reach it.

## Effects (animations)

Choose in **CFG → EFFECTS**. The setting is saved separately on each screen.

| Level | What you get | Best for |
|---|---|---|
| **FULL** | Smooth scrolling news bar, expanding quake pulses, blinking alerts | PC, phone, Pi 3 and newer |
| **LOW** | All the same animations in a lighter form: the news bar moves about 15 times a second and quake rings blink instead of expanding. Uses about 70% less processor than FULL. | **Pi Zero W** (its default) |
| **OFF** | No motion at all | Very slow devices, or if you prefer it still |

## SD-card image with phone setup

The `crashboard-image` folder builds a ready-to-flash image. Flash it, power on, and set up Wi-Fi and location from your phone, with no SSH. Its README has the steps.

To turn a Pi you already set up into the same appliance style (phone setup and automatic Wi-Fi rescue), run `sudo ~/crashboard/setup/image-setup.sh` and restart. Use `sudo ~/crashboard/setup/reset.sh` to send a board back to phone setup.

## Ready-to-boot SD card (no SSH needed)

This makes a card that installs Crash Board by itself the first time the Pi starts.

1. In **Raspberry Pi Imager**, choose your Pi, then **Raspberry Pi OS (other) → Raspberry Pi OS Lite (32-bit)**, then your SD card.
2. When Imager offers settings (EDIT SETTINGS / Customisation), fill in a **username, password and your Wi-Fi**. The Pi Zero W only works on 2.4 GHz Wi-Fi. Then write the card.
3. Take the card out and put it back in. Windows shows a drive called **bootfs**.
4. Double-click **make-sd-card.bat** in this folder and answer the questions (screen or no screen, ZIP code, units, language).
5. Eject the card, put it in the Pi, connect the screen, and plug in power.

The first start takes 20 to 40 minutes on a Pi Zero W. The screen shows progress, then the Pi restarts into Crash Board. Every start after that takes about a minute.

- You can change the answers before the first start by editing `crashboard-setup\settings.txt` on the card.
- If setup fails, it tries again each time the Pi starts. Put the card in your PC and open `crashboard-setup\install.log` to see why.
- **Making several cards (for example, to sell):** set up one card this way, then use Win32 Disk Imager's **Read** button to save it as a master `.img`. Write that image to more cards with Raspberry Pi Imager (**Use custom**). Every copy has the same Wi-Fi and password, so only do this for cards that go on the same network, or give buyers a blank card and this tool instead.

## Languages

CFG → LANGUAGE switches the interface to English, Español, Français, Deutsch or Português. It applies to every screen showing this board, including Wi-Fi displays, and the voice callout speaks in that language too.

- Official warnings, news headlines, quake places and fire names stay exactly as the agency published them. Nothing safety-critical is machine-translated.
- DEFCON codenames (COCKED PISTOL and so on) stay in English because they are proper names.
- One screen can use a different language by adding `?lang=es` (or fr, de, pt) to its address.
- Promo lines in `static/promos.json` can carry `"text_es"`, `"text_fr"`… next to `"text"`; screens fall back to English.
- To fix or add a phrase, edit `i18n_build.py` from the seller tools and rebuild `static/i18n.js`.

## Color schemes

Pick one in **CFG → COLOR SCHEME**. The menu previews each scheme live, and saving applies it to every screen, the Pi included.

| Scheme | Look |
|---|---|
| **Ops** | Olive drab and khaki (the original) |
| **Blackout** | Black with orange accents, matching the logo |
| **Hazard** | Orange with black accents and hazard-stripe header |
| **Coyote** | Coyote brown and tan |
| **Vault** | Retro vault-suit blue and yellow, with Oswald + Share Tech Mono fonts |
| **CVA** | 1970s retro-bureau: amber monochrome CRT glow on warm brown, with VT323 + Bebas Neue fonts |

The condition banner, alert strip and map keep the same alert colors in every scheme, so RED and ORANGE always read clearly. Vault and CVA load their fonts from Google Fonts when online and falls back to the standard fonts offline. To try a scheme on one screen only, add `?theme=coyote` (etc.) to the address.

## Alert sounds

When something big happens, the board plays a sound once, shows a **FLASH TRAFFIC** banner, and reads the alert aloud:

| Event | Sound |
|---|---|
| New quake at or above the alert magnitude (M7.0 by default) | rumble + sonar pings |
| Tsunami warning, advisory or watch · DEFCON estimate goes up · condition turns RED | klaxon |
| Extreme or Severe local weather alert | two-tone warble |
| CDC Level 3–4 notice · WHO high-consequence outbreak report | Geiger clicks + low tone |
| G4+ geomagnetic storm | radio static + beeps |
| GDACS red event · condition turns ORANGE | comms chirp |

Critical events (M8+, tsunami WARNING, Extreme alert, DEFCON est. 1–2, RED) play twice and keep the banner up until you press **ACK**.

- **Each event alerts once.** Events already announced are saved in `data/events.json`, so reboots and page refreshes never replay them. The first load after install is silent.
- **Turn sound on per device.** Tap **AUDIO** in the header. Browsers require one tap before a page can make sound. The Pi kiosk is set up to arm itself.
- In **CFG**, you can set the volume, turn the voice callout on or off, set quiet hours (only critical alerts sound during them), change the alert quake magnitude, and play test buttons for every sound.
- **Pi audio** comes out of HDMI or the 3.5 mm jack. To pick one, run `sudo raspi-config` → System → Audio. On a Pi Zero W with surf, sound may not work, but the banner always does.

**Wildfire distances** are set in **CFG**: *List wildfires within* (default 100 mi) and *Alarm for new fires within* (default 15 mi). A new fire inside the alarm distance plays the wildfire sound (crackle and horn), and one within a third of that distance counts as critical. Wildfire and drought data cover the US. Elsewhere, big fires and droughts still show under Global Disasters.

## Offline behavior

The last good data is saved to `data/cache.json`. If the internet drops, the board keeps showing that data, and each panel header shows its age (marked **ERR** or **NO LINK** in red) so you know it's old.

The world outline downloads once on first boot. Until then the map shows only the grid.

## Files

```
server.py          collector + web server (stdlib only)
static/            board UI (HTML/CSS/JS, no external assets)
install.sh         service + kiosk setup
kiosk.sh           fullscreen browser launcher
data/              config.json, cache.json, map (created at runtime)
tests/test_offline.py   parser tests with sample feed data
```

Useful commands:
```bash
sudo systemctl status crashboard     # is it running
journalctl -u crashboard -f          # live feed log (ok / FAIL per source)
sudo systemctl restart crashboard
python3 tests/test_offline.py        # self-test parsers
```

## Condition logic

| Level | Triggers (any one) |
|---|---|
| RED | M8+ quake in the last 24 h · tsunami WARNING · Extreme local alert · DEFCON est. 1–2 |
| ORANGE | M7+ quake in the last 24 h · wildfire within 15 mi · CDC Level 4 travel notice · tsunami advisory/watch/threat · Severe local alert · GDACS red event · G4+ storm |
| YELLOW | M6+ quake in the last 24 h · large (1,000+ acre), under-50%-contained wildfire within ~40 mi · D3+ drought over half your county · CDC Level 3 notice · WHO high-consequence outbreak report in the last 14 days · Moderate local alert · DEFCON est. 3 · G3 storm |
| GREEN | none of the above |

Thresholds live in `assess()` in `server.py` if you want to tune them.
