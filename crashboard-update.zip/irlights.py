"""ALERT LIGHTS: flash an IR-remote LED strip when Crash Board raises an alert.

Talks over your home Wi-Fi to a small IR blaster running Tasmota (an ESP8266/ESP32 with an IR LED,
for example a D1 mini + IR shield). Crash Board sends the same codes as the strip's own remote:

    http://<blaster>/cm?cmnd=IRsend {"Protocol":"NEC","Bits":32,"Data":"0xF720DF"}

Codes come from a built-in table for the common 24-key remote, or are LEARNED: press LEARN in CFG,
point the strip's remote at the blaster and press the button. Learning uses a Tasmota rule that
copies the last received code into Var1..Var3, which Crash Board then reads back.

Everything runs on a background thread, so a missing or slow blaster never holds up the board.
"""
import json
import queue
import threading
import time
import urllib.parse
import urllib.request

SLOTS = ("on", "off", "red", "orange", "yellow", "normal")
SLOT_NAMES = {"on": "ON", "off": "OFF", "red": "RED", "orange": "ORANGE", "yellow": "YELLOW",
              "normal": "ALL CLEAR"}

# The common 24-key RGB remote (NEC, 32 bits). Layout, top to bottom:
#   BRIGHT+ BRIGHT- OFF ON / R G B W / 4 rows of colours under R G B, with FLASH STROBE FADE SMOOTH
PRESETS = {
    "24key": {
        "on": "0xF7C03F", "off": "0xF740BF",
        "red": "0xF720DF",        # R
        "orange": "0xF710EF",     # first colour under R
        "yellow": "0xF728D7",     # bottom colour under R
        "normal": "0xF7E01F",     # W (white)
    },
}

DEFAULT = {
    "enabled": False,
    "host": "",                 # IP (or name) of the Tasmota IR blaster, e.g. 192.168.4.60
    "remote": "24key",          # 24key = built-in codes; anything learned overrides a slot
    "codes": {},                # learned: slot -> {"p": "NEC", "b": 32, "d": "0x..."}
    "min_level": 1,             # 1 = YELLOW and up, 2 = ORANGE and up, 3 = RED only
    "clear": "off",             # when the board goes back to GREEN: off | normal | none
}

LEVEL_SLOT = {1: "yellow", 2: "orange", 3: "red"}
BLINKS = {1: (1, 0.9), 2: (2, 0.6), 3: (4, 0.35)}    # how many off/on blinks, and how fast

_q = queue.Queue(maxsize=20)
_cfg = dict(DEFAULT)
_last = {"level": 0, "flashed": {}, "error": "", "ok_at": 0}
_learn = {"state": "idle", "slot": "", "code": None, "msg": ""}
_started = False
_lock = threading.Lock()


def log(*a):
    print(time.strftime("%H:%M:%S"), "lights:", *a, flush=True)


# ------------------------------------------------------------------ Tasmota HTTP
def _cmd(command, timeout=4):
    host = (_cfg.get("host") or "").strip()
    if not host:
        raise RuntimeError("no IR blaster address set")
    if "://" not in host:
        host = "http://" + host
    url = host.rstrip("/") + "/cm?cmnd=" + urllib.parse.quote(command, safe="")
    with urllib.request.urlopen(url, timeout=timeout) as r:
        txt = r.read().decode("utf-8", "ignore")
    try:
        return json.loads(txt)
    except ValueError:
        return {"raw": txt}


def code_for(slot):
    c = (_cfg.get("codes") or {}).get(slot)
    if c and c.get("d"):
        return {"p": c.get("p") or "NEC", "b": int(c.get("b") or 32), "d": c["d"]}
    d = PRESETS.get(_cfg.get("remote") or "", {}).get(slot)
    return {"p": "NEC", "b": 32, "d": d} if d else None


def send(slot):
    c = code_for(slot)
    if not c:
        raise RuntimeError("no code for %s: press LEARN next to it" % SLOT_NAMES.get(slot, slot))
    r = _cmd('IRsend {"Protocol":"%s","Bits":%d,"Data":"%s"}' % (c["p"], c["b"], c["d"]))
    res = str(r.get("IRSend") or r.get("IrSend") or r)
    if "done" not in res.lower():
        raise RuntimeError("blaster said: " + res[:80])
    _last["ok_at"] = time.time()
    _last["error"] = ""


# ------------------------------------------------------------------ light shows
def _flash(level):
    slot = LEVEL_SLOT[level]
    n, gap = BLINKS[level]
    send("on"); time.sleep(0.25)
    send(slot); time.sleep(gap)
    for _ in range(n):
        send("off"); time.sleep(gap)
        send("on"); time.sleep(0.15)
        send(slot); time.sleep(gap)
    # leaves the strip lit in the alert colour


def _set_level(level):
    if level <= 0:
        how = _cfg.get("clear") or "off"
        if how == "off":
            send("off")
        elif how == "normal":
            send("on"); time.sleep(0.25); send("normal")
    else:
        send("on"); time.sleep(0.25); send(LEVEL_SLOT[level])


def _worker():
    while True:
        job, arg = _q.get()
        try:
            if job == "flash":
                _flash(arg)
            elif job == "level":
                _set_level(arg)
            elif job == "send":
                send(arg)
            elif job == "learn":
                _do_learn(arg)
        except Exception as e:
            _last["error"] = str(e)[:160]
            log(job, arg, "failed:", e)
            if job == "learn":
                _learn.update(state="failed", msg=str(e)[:160])


def _queue(job, arg):
    try:
        _q.put_nowait((job, arg))
    except queue.Full:
        pass


# ------------------------------------------------------------------ public hooks (called by server.py)
def configure(cfg):
    """Called at start-up and whenever settings change."""
    global _started
    _cfg.clear()
    _cfg.update(DEFAULT)
    _cfg.update(cfg or {})
    if not _started:
        threading.Thread(target=_worker, daemon=True, name="irlights").start()
        _started = True


def active():
    return bool(_cfg.get("enabled") and (_cfg.get("host") or "").strip())


def alert(level):
    """A new alert or event at this level (1 YELLOW .. 3 RED): flash, then stay that colour."""
    level = max(1, min(3, int(level)))
    if not active() or level < int(_cfg.get("min_level") or 1):
        return
    with _lock:
        t = time.time()
        if t - _last["flashed"].get(level, 0) < 45:        # don't strobe the house for every event
            return
        _last["flashed"][level] = t
        _last["level"] = max(_last["level"], level)
    _queue("flash", level)


def condition(level, previous):
    """The board's condition changed. Going up is handled by alert(); going down sets the colour."""
    if not active() or previous is None or level >= previous:
        return
    with _lock:
        _last["level"] = level
    shown = level if level >= int(_cfg.get("min_level") or 1) else 0
    _queue("level", shown)


def test(what):
    """CFG test buttons: 'red' | 'orange' | 'yellow' (a full alert flash), or any slot (one press)."""
    if what in ("red", "orange", "yellow") and (_cfg.get("host") or "").strip():
        _queue("flash", {"yellow": 1, "orange": 2, "red": 3}[what])
    elif what == "clear":
        _queue("level", 0)
    elif what in SLOTS:
        _queue("send", what)


def status():
    out = {k: _cfg.get(k) for k in DEFAULT}
    out["slots"] = [{"slot": s, "name": SLOT_NAMES[s], "learned": s in (_cfg.get("codes") or {}),
                     "has_code": code_for(s) is not None} for s in SLOTS]
    out["presets"] = sorted(PRESETS)
    out["error"] = _last["error"]
    out["learn"] = dict(_learn)
    out["online"], out["device"] = False, ""
    if (_cfg.get("host") or "").strip():
        try:
            r = _cmd("Status", timeout=2.5)
            st = r.get("Status") or {}
            fn = st.get("FriendlyName")
            out["device"] = (fn[0] if isinstance(fn, list) and fn else st.get("DeviceName") or "TASMOTA")
            out["online"] = True
        except Exception as e:
            out["error"] = out["error"] or ("can't reach the blaster: %s" % e)[:160]
    return out


# ------------------------------------------------------------------ learning a remote button
def learn(slot):
    if slot not in SLOTS:
        raise ValueError("unknown button")
    if not (_cfg.get("host") or "").strip():
        raise ValueError("Enter the IR blaster's address first")
    _learn.update(state="waiting", slot=slot, code=None, msg="Point the strip's remote at the blaster and press %s" % SLOT_NAMES[slot])
    _queue("learn", slot)


def _do_learn(slot, seconds=25):
    _cmd("Backlog Var1 none; Var2 none; Var3 none; "
         "Rule1 ON IrReceived#Protocol DO Var2 %value% ENDON "
         "ON IrReceived#Bits DO Var3 %value% ENDON "
         "ON IrReceived#Data DO Var1 %value% ENDON; Rule1 1")
    t0 = time.time()
    while time.time() - t0 < seconds:
        time.sleep(0.6)
        v = _cmd("Var")
        d, p, b = str(v.get("Var1", "none")), str(v.get("Var2", "none")), str(v.get("Var3", "none"))
        if d not in ("none", "") and d.upper() not in ("0XFFFFFFFF", "0XFFFFFFFFFFFFFFFF"):
            code = {"p": p if p not in ("none", "") else "NEC", "b": int(b) if b.isdigit() else 32, "d": d}
            _learn.update(state="done", code=code, msg="Learned %s: %s %s" % (SLOT_NAMES[slot], code["p"], d))
            return
    _learn.update(state="timeout", msg="Didn't see a button press. Hold the remote close to the blaster and try again.")


def take_learned():
    """server.py saves a successfully learned code into the config, then clears it here."""
    if _learn["state"] == "done" and _learn["code"]:
        slot, code = _learn["slot"], _learn["code"]
        _learn.update(state="saved")
        return slot, code
    return None, None
