#!/data/data/com.termux/files/usr/bin/bash
# Starts the Crash Board server in the background (if it isn't already) and opens the board.
#   bash start-android.sh          start + open
#   bash start-android.sh test     also fire a test alert notification
APP_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$APP_DIR"
mkdir -p data
export CRASHBOARD_MOBILE="${CRASHBOARD_MOBILE:-1}"     # data saver on by default; CRASHBOARD_MOBILE=0 to turn off

alive() {
  [ -f data/port.txt ] && python - "$(cat data/port.txt)" <<'PY' 2>/dev/null
import sys, urllib.request
urllib.request.urlopen("http://127.0.0.1:%s/api/state" % sys.argv[1], timeout=2)
PY
}

if alive; then
  echo "Crash Board already running."
else
  echo "Starting Crash Board server..."
  rm -f data/port.txt
  termux-wake-lock 2>/dev/null || true             # keep Android from pausing it
  nohup python server.py > data/server.log 2>&1 &
  for i in $(seq 1 30); do alive && break; sleep 1; done
fi

if ! alive; then
  echo "Server did not start. Last lines of data/server.log:"; tail -n 20 data/server.log; exit 1
fi
PORT="$(cat data/port.txt)"
echo "Running at http://127.0.0.1:$PORT"

if [ "$1" = "test" ]; then
  python - "$PORT" <<'PY'
import sys, json, urllib.request
req = urllib.request.Request("http://127.0.0.1:%s/api/test-alert" % sys.argv[1],
                             data=json.dumps({"kind": "seismic", "sev": 2}).encode(), method="POST")
urllib.request.urlopen(req, timeout=5)
print("Test alert sent - you should get a notification with vibration.")
PY
fi
termux-open-url "http://127.0.0.1:$PORT/" 2>/dev/null || echo "Open http://127.0.0.1:$PORT in Chrome."
