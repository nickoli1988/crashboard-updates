"""
CRASH BOARD MESH: Meshtastic radio link.

Connects to a Meshtastic radio over USB (serial), Wi-Fi (TCP) or Bluetooth using the
official `meshtastic` Python library, then:
  * keeps a live list of nodes (name, battery, signal, hops, GPS position)
  * keeps a chat log (channel messages + direct messages), saved to data/mesh_messages.json
  * sends text from the board UI (channel or direct)
  * broadcasts big Crash Board alerts to the mesh (rate-limited, short)
  * turns "[CB]" alerts heard from other boards into local alerts (off-grid relay)

If the meshtastic library isn't installed, everything else in Crash Board still works and
the COMMS drawer explains how to install it.
"""
import json
import math
import os
import queue
import threading
import time

ALERT_PREFIX = "[CB]"
MAX_TEXT_BYTES = 200          # Meshtastic payload limit is ~228 bytes; leave headroom
ALERT_SPACING_S = 30          # minimum gap between automatic alert broadcasts (airtime etiquette)

try:  # optional dependency
    import meshtastic                       # noqa: F401
    import meshtastic.serial_interface
    import meshtastic.tcp_interface
    from pubsub import pub
    HAVE_LIB = True
except Exception:                           # ImportError, or a broken install
    HAVE_LIB = False

try:
    import meshtastic.ble_interface         # newer library versions only
    HAVE_BLE = True
except Exception:
    HAVE_BLE = False


def _now():
    return time.time()


class Mesh:
    def __init__(self, data_dir, get_config, on_alert, log=print):
        self.data_dir = data_dir
        self.get_config = get_config        # -> dict (CONFIG["mesh"])
        self.on_alert = on_alert            # callback(kind, sev, title, detail, source="mesh")
        self.log = log
        self.lock = threading.RLock()
        self.iface = None
        self.status = "disabled" if HAVE_LIB else "no_library"
        self.error = ""
        self.since = _now()
        self.me = {}
        self.channels = []
        self.messages = []                  # [{seq,time,from,from_name,to,channel,text,dir,snr,rssi,hops}]
        self.seq = 0
        self.heard = {}                     # recent inbound alert texts -> time (dedupe across gateways)
        self.alert_q = queue.Queue()
        self.last_alert_tx = 0
        self.stop_flag = threading.Event()
        self.reconnect = threading.Event()
        self.msg_path = os.path.join(data_dir, "mesh_messages.json")
        self.lock_path = os.path.join(data_dir, "mesh-radio.lock")
        self._lockf = None
        self.fails = 0                      # back-off: each failed/lost connection waits longer
        self.lost_at = 0
        self._load()
        if HAVE_LIB:
            pub.subscribe(self._on_receive, "meshtastic.receive")
            pub.subscribe(self._on_connected, "meshtastic.connection.established")
            pub.subscribe(self._on_lost, "meshtastic.connection.lost")

    # ------------------------------------------------------------------ storage
    def _load(self):
        try:
            with open(self.msg_path) as f:
                d = json.load(f)
            self.messages = d.get("messages", [])[-300:]
            self.seq = d.get("seq", len(self.messages))
        except Exception:
            pass

    def _save(self):
        tmp = self.msg_path + ".tmp"
        try:
            with open(tmp, "w") as f:
                json.dump({"seq": self.seq, "messages": self.messages[-300:]}, f)
            os.replace(tmp, self.msg_path)
        except Exception as e:
            self.log("mesh: save failed:", e)

    def _add_msg(self, **m):
        with self.lock:
            self.seq += 1
            m["seq"] = self.seq
            m.setdefault("time", _now())
            self.messages.append(m)
            self.messages = self.messages[-300:]
            self._save()
            return m

    # ------------------------------------------------------------- connection
    def start(self):
        threading.Thread(target=self._conn_loop, daemon=True, name="mesh-conn").start()
        threading.Thread(target=self._alert_loop, daemon=True, name="mesh-alerts").start()

    def request_reconnect(self):
        self.reconnect.set()

    def _open(self, cfg):
        mode = (cfg.get("mode") or "auto").lower()
        addr = (cfg.get("address") or "").strip()
        if mode == "tcp":
            if not addr:
                raise RuntimeError("Wi-Fi mode needs the radio's IP address or hostname")
            return meshtastic.tcp_interface.TCPInterface(hostname=addr)
        if mode == "ble":
            if not HAVE_BLE:
                raise RuntimeError("Bluetooth needs a newer meshtastic library (pip install -U meshtastic)")
            return meshtastic.ble_interface.BLEInterface(addr or None)
        # serial / auto: devPath None lets the library find the radio on USB
        return meshtastic.serial_interface.SerialInterface(devPath=addr or None)

    def _take_radio_lock(self):
        """Only ONE Crash Board may talk to the radio. Two copies fighting over the USB port make a
        Heltec V3 restart over and over (every time the port is opened the board resets)."""
        if self._lockf:
            return True
        try:
            f = open(self.lock_path, "a+")
            if os.name == "nt":
                import msvcrt
                f.seek(0)
                msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            self._lockf = f
            return True
        except (OSError, IOError):
            try:
                f.close()
            except Exception:
                pass
            return False

    def _conn_loop(self):
        while not self.stop_flag.is_set():
            cfg = self.get_config()
            if not HAVE_LIB:
                self.status = "no_library"
                self.reconnect.wait(30); self.reconnect.clear()
                continue
            if not cfg.get("enabled", True):
                self._close("disabled")
                self.reconnect.wait(30); self.reconnect.clear()
                continue
            if self.iface is None and not self._take_radio_lock():
                self.status = "error"
                self.error = ("Another Crash Board is already using the radio. Close the other Crash Board "
                              "window (check the taskbar), then press RECONNECT.")
                self.log("mesh:", self.error)
                self.reconnect.wait(30); self.reconnect.clear()
                continue
            if self.iface is None:
                self.status, self.error = "connecting", ""
                try:
                    iface = self._open(cfg)
                    with self.lock:
                        self.iface = iface
                    self._on_connected(interface=iface)
                    self.fails = 0
                except BaseException as e:   # the library can raise SystemExit when no radio is found
                    if isinstance(e, KeyboardInterrupt):
                        raise
                    self.iface = None
                    self.status = "error"
                    self.error = self._friendly(e)
                    self.fails += 1
                    self.log("mesh: connect failed:", self.error)
            if self.iface is None:
                # give the radio time to finish booting before trying again: 20 s, 40 s, 80 s ... up to 5 min
                wait = min(300, 20 * (2 ** max(0, min(self.fails - 1, 4))))
                if self.reconnect.wait(wait):
                    self.reconnect.clear()
                continue
            if self.reconnect.wait(60):
                self.reconnect.clear()
                if self.lost_at and time.time() - self.lost_at < 5:
                    # connection dropped: let the radio finish restarting before reopening the port
                    wait = min(300, 20 * (2 ** max(0, min(self.fails - 1, 4))))
                    self.log("mesh: waiting %d s before reconnecting" % wait)
                    if self.reconnect.wait(wait):
                        self.reconnect.clear()
                    continue
                self._close("connecting")           # settings changed: reopen with the new ones

    def _friendly(self, e):
        s = str(e) or e.__class__.__name__
        if isinstance(e, SystemExit) or "No Serial Meshtastic device" in s or "no devices" in s.lower():
            return "No radio found on USB. Plug it in (data cable, not charge-only) or pick Wi-Fi/Bluetooth."
        if "Permission denied" in s:
            return "No permission for the USB port. On a Pi run: sudo usermod -aG dialout $USER, then reboot."
        if "Multiple" in s:
            return "More than one USB serial device found. Enter the port (e.g. /dev/ttyUSB0 or COM4) in CFG."
        return s[:200]

    def _close(self, status):
        with self.lock:
            iface, self.iface = self.iface, None
        if iface:
            try:
                iface.close()
            except Exception:
                pass
        self.status = status

    def _on_connected(self, interface=None):
        iface = interface or self.iface
        if not iface:
            return
        me, chans = {}, []
        try:
            info = iface.getMyNodeInfo() or {}
            u = info.get("user", {})
            me = {"id": u.get("id"), "long": u.get("longName"), "short": u.get("shortName"),
                  "hw": u.get("hwModel"), "num": info.get("num")}
        except Exception:
            pass
        try:
            for ch in getattr(iface.localNode, "channels", None) or []:
                role = int(getattr(ch, "role", 0))
                if role == 0:                               # DISABLED
                    continue
                name = getattr(getattr(ch, "settings", None), "name", "") or ("PRIMARY" if role == 1 else "CH%d" % ch.index)
                chans.append({"index": int(ch.index), "name": name.upper(), "primary": role == 1})
        except Exception:
            pass
        with self.lock:
            self.me, self.channels = me, chans or [{"index": 0, "name": "PRIMARY", "primary": True}]
            self.status, self.error, self.since = "connected", "", _now()
        self.log("mesh: connected as", me.get("long") or me.get("id"))

    def _on_lost(self, interface=None):
        self.log("mesh: connection lost")
        self.fails = 1 if _now() - (self.since or 0) > 300 else self.fails + 1   # long, healthy link: start the back-off over
        self.lost_at = time.time()
        self._close("connecting")
        self.reconnect.set()                # wakes the loop, which now waits (back-off) before reopening

    # ---------------------------------------------------------------- receive
    def _node_name(self, node_id, short=True):
        try:
            n = (self.iface.nodes or {}).get(node_id) or {}
            u = n.get("user", {})
            return (u.get("shortName") if short else u.get("longName")) or u.get("longName") or node_id
        except Exception:
            return node_id

    def _on_receive(self, packet, interface=None):
        try:
            dec = packet.get("decoded") or {}
            if dec.get("portnum") != "TEXT_MESSAGE_APP":
                return
            text = dec.get("text")
            if text is None and dec.get("payload") is not None:
                text = bytes(dec["payload"]).decode("utf-8", "replace")
            if not text:
                return
            frm = packet.get("fromId") or ("!%08x" % packet.get("from", 0))
            to = packet.get("toId") or "^all"
            m = self._add_msg(
                dir="in", text=text[:400], **{"from": frm}, from_name=self._node_name(frm),
                from_long=self._node_name(frm, short=False), to=to,
                dm=(to != "^all"), channel=int(packet.get("channel", 0) or 0),
                snr=packet.get("rxSnr"), rssi=packet.get("rxRssi"),
                hops=(packet.get("hopStart", 0) or 0) - (packet.get("hopLimit", 0) or 0) if packet.get("hopStart") else None,
                time=packet.get("rxTime") or _now())
            self._maybe_relay(m)
        except Exception as e:
            self.log("mesh: bad packet:", e)

    def _maybe_relay(self, m):
        """Off-grid relay: '[CB] ...' alerts from other boards become local alerts."""
        cfg = self.get_config()
        if not cfg.get("relay_inbound", True) or not m["text"].startswith(ALERT_PREFIX):
            return
        body = m["text"][len(ALERT_PREFIX):].strip()
        t = _now()
        self.heard = {k: v for k, v in self.heard.items() if t - v < 3600}
        if body in self.heard:
            return                                           # same alert relayed by several boards
        self.heard[body] = t
        title, _, detail = body.partition(":")
        up = body.upper()
        sev = 3 if any(k in up for k in ("WARNING", "CONDITION RED", "DEFCON ESTIMATE 1", "DEFCON ESTIMATE 2", "EXTREME")) else 2
        kind = ("fire" if "WILDFIRE" in up else "seismic" if "EARTHQUAKE" in up else "klaxon" if ("TSUNAMI" in up or "DEFCON" in up or "RED" in up)
                else "weather" if "WEATHER" in up or "WARNING" in up else "bio" if ("CDC" in up or "WHO" in up)
                else "space" if "GEOMAGNETIC" in up else "chirp")
        self.on_alert(kind, sev, title.strip()[:80], (detail.strip() + " · via mesh from " + m["from_name"]).strip(" ·"),
                      source="mesh")

    # ------------------------------------------------------------------- send
    def send(self, text, to="^all", channel=0):
        text = (text or "").strip()
        if not text:
            raise ValueError("empty message")
        raw = text.encode("utf-8")
        if len(raw) > MAX_TEXT_BYTES:
            text = raw[:MAX_TEXT_BYTES].decode("utf-8", "ignore")
        with self.lock:
            iface = self.iface
        if not iface or self.status != "connected":
            raise RuntimeError("radio not connected")
        to = to or "^all"
        iface.sendText(text, destinationId=to, wantAck=(to != "^all"), channelIndex=int(channel or 0))
        return self._add_msg(dir="out", text=text, **{"from": self.me.get("id") or "me"},
                             from_name=self.me.get("short") or "ME", to=to, dm=(to != "^all"),
                             channel=int(channel or 0))

    def queue_alert(self, ev):
        """Called for every Crash Board event; broadcasts the big ones to the mesh."""
        cfg = self.get_config()
        if ev.get("source") == "mesh" or not cfg.get("broadcast_alerts", True):
            return                                           # never echo relayed alerts back out
        if int(ev.get("sev", 0)) < int(cfg.get("alert_min_sev", 2)):
            return
        self.alert_q.put(ev)

    def _alert_loop(self):
        while not self.stop_flag.is_set():
            ev = self.alert_q.get()
            wait = ALERT_SPACING_S - (_now() - self.last_alert_tx)
            if wait > 0:
                time.sleep(wait)
            text = "%s %s" % (ALERT_PREFIX, ev["title"])
            if ev.get("detail"):
                text += ": " + ev["detail"]
            try:
                self.send(text, "^all", int(self.get_config().get("alert_channel", 0)))
                self.last_alert_tx = _now()
                self.log("mesh: alert broadcast:", text)
            except Exception as e:
                self.log("mesh: alert not sent:", e)

    # --------------------------------------------------------------- snapshot
    def snapshot(self, since=0, home=None):
        nodes = []
        t = _now()
        try:
            raw = dict(self.iface.nodes or {}) if self.iface else {}
        except Exception:
            raw = {}
        for nid, n in raw.items():
            u = n.get("user", {}) or {}
            pos = n.get("position", {}) or {}
            dm = n.get("deviceMetrics", {}) or {}
            lat, lon = pos.get("latitude"), pos.get("longitude")
            if lat is None and pos.get("latitudeI") is not None:
                lat, lon = pos["latitudeI"] / 1e7, (pos.get("longitudeI") or 0) / 1e7
            item = {"id": u.get("id") or nid, "long": u.get("longName") or nid, "short": u.get("shortName") or "?",
                    "hw": u.get("hwModel"), "last": n.get("lastHeard"), "snr": n.get("snr"),
                    "hops": n.get("hopsAway"), "battery": dm.get("batteryLevel"), "voltage": dm.get("voltage"),
                    "lat": lat, "lon": lon, "me": (u.get("id") == self.me.get("id"))}
            if home and lat is not None and home.get("lat") is not None:
                item["km"] = round(_haversine(home["lat"], home["lon"], lat, lon), 1)
            nodes.append(item)
        nodes.sort(key=lambda x: (not x["me"], -(x["last"] or 0)))
        with self.lock:
            msgs = [m for m in self.messages if m["seq"] > since][-150:]
        return {"lib": HAVE_LIB, "ble": HAVE_BLE, "status": self.status, "error": self.error,
                "since": self.since, "me": self.me, "channels": self.channels, "nodes": nodes[:200],
                "messages": msgs, "seq": self.seq, "max_bytes": MAX_TEXT_BYTES, "time": t}


def _haversine(lat1, lon1, lat2, lon2):
    r = math.radians
    a = math.sin(r(lat2 - lat1) / 2) ** 2 + math.cos(r(lat1)) * math.cos(r(lat2)) * math.sin(r(lon2 - lon1) / 2) ** 2
    return 6371 * 2 * math.asin(min(1, math.sqrt(a)))
