/* CRASH BANK page: browse, search, upload, download, rename, delete. */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var cur = "", info = null, searching = false;

  function pin() { try { return sessionStorage.getItem("cb.bankpin") || ""; } catch (e) { return ""; } }
  function setPin(p) { try { sessionStorage.setItem("cb.bankpin", p); } catch (e) {} paintPin(); }
  function paintPin() { $("btn-pin").textContent = pin() ? "🔓 PIN ENTERED" : "🔒 PIN"; }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  function size(n) { if (n < 1024) return n + " B"; var u = ["KB", "MB", "GB", "TB"], i = -1; do { n /= 1024; i++; } while (n >= 1024 && i < 3); return n.toFixed(n < 10 ? 1 : 0) + " " + u[i]; }
  function when(t) { return new Date(t * 1000).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" }); }
  function msg(t, cls) { $("msg").textContent = t || ""; $("msg").className = "msg" + (cls ? " " + cls : ""); }
  function fileUrl(p, dl) { return "bank/file/" + p.split("/").map(encodeURIComponent).join("/") + (dl ? "?dl=1" : ""); }
  function join(a, b) { return a ? a + "/" + b : b; }

  function api(path, body) {
    var opt = body === undefined ? { cache: "no-store" } :
      { method: "POST", headers: { "Content-Type": "application/json", "X-Bank-Pin": pin() }, body: JSON.stringify(body) };
    return fetch(path, opt).then(function (r) {
      return r.json().then(function (j) {
        if (r.status === 402) { showLocked(); throw new Error(j.error); }
        if (r.status === 403) { askPin(true); throw new Error(j.error); }
        if (!r.ok) throw new Error(j.error || ("error " + r.status));
        return j;
      });
    });
  }
  function showLocked() { $("locked").hidden = false; $("main").hidden = true; $("settings").hidden = true; $("chip-store").textContent = "PRO"; }

  function kind(n) {
    var e = (n.split(".").pop() || "").toLowerCase();
    if (e === "pdf") return ["PDF", "pdf"];
    if (/^(jpe?g|png|gif|webp|heic)$/.test(e)) return ["IMG", "img"];
    if (/^(mp3|m4a|wav|ogg|mp4|webm|mov)$/.test(e)) return [e === "mp3" || e === "m4a" || e === "wav" || e === "ogg" ? "AUD" : "VID", "av"];
    if (/^(txt|md|csv)$/.test(e)) return ["TXT", ""];
    if (/^(gpx|kml|kmz)$/.test(e)) return ["MAP", "img"];
    if (/^(zip|7z|rar)$/.test(e)) return ["ZIP", ""];
    return [(e || "FILE").slice(0, 4).toUpperCase(), ""];
  }

  function row(it, path) {
    var li = document.createElement("li"), k = it.dir ? ["DIR", "dir"] : kind(it.name);
    var meta = it.dir ? (it.items + " item" + (it.items === 1 ? "" : "s")) : size(it.size) + " · " + when(it.mtime);
    if (searching) meta = esc(path) + " · " + meta;
    li.innerHTML = '<span class="ico ' + k[1] + '">' + k[0] + '</span><div class="nm"><a data-open="1">' + esc(it.name) + "</a><small>" + meta + "</small></div>" +
      '<div class="acts">' + (it.dir ? "" : '<a class="btn" title="Download" href="' + fileUrl(path, true) + '">⬇</a>') +
      '<button type="button" class="btn" data-ren="1" title="Rename">✎</button><button type="button" class="btn" data-del="1" title="Delete">✕</button></div>';
    li.querySelector("[data-open]").addEventListener("click", function () {
      if (it.dir) { searching = false; $("q").value = ""; go(path); } else window.open(fileUrl(path, false), "_blank");
    });
    li.querySelector("[data-ren]").addEventListener("click", function () {
      var nn = window.prompt("New name for " + it.name, it.name);
      if (nn && nn !== it.name) api("api/bank/rename", { path: path, name: nn }).then(refresh).catch(function (e) { msg("✗ " + e.message, "bad"); });
    });
    li.querySelector("[data-del]").addEventListener("click", function () {
      if (!window.confirm("Delete " + it.name + (it.dir ? " and everything in it" : "") + "?")) return;
      api("api/bank/delete", { path: path }).then(function () { msg("Deleted " + it.name, "good"); refresh(); }).catch(function (e) { msg("✗ " + e.message, "bad"); });
    });
    return li;
  }

  function crumbs() {
    var parts = cur ? cur.split("/") : [], h = '<a data-p="">CRASH BANK</a>', acc = "";
    parts.forEach(function (p) { acc = join(acc, p); h += " / <a data-p=\"" + esc(acc) + "\">" + esc(p) + "</a>"; });
    $("crumbs").innerHTML = searching ? 'SEARCH RESULTS · <a data-p="' + esc(cur) + '">BACK</a>' : h;
    Array.prototype.forEach.call($("crumbs").querySelectorAll("a"), function (a) {
      a.addEventListener("click", function () { searching = false; $("q").value = ""; go(a.dataset.p); });
    });
  }

  function paint(items, isSearch) {
    var ul = $("list");
    ul.innerHTML = "";
    if (!items.length) ul.innerHTML = '<li class="empty">' + (isSearch ? "NOTHING MATCHES" : "THIS FOLDER IS EMPTY · UPLOAD SOMETHING") + "</li>";
    items.forEach(function (it) { ul.appendChild(row(it, isSearch ? it.path : join(cur, it.name))); });
    crumbs();
  }

  function go(p) {
    cur = p || "";
    try { history.replaceState(null, "", cur ? "#" + encodeURIComponent(cur) : location.pathname); } catch (e) {}
    return api("api/bank/list?path=" + encodeURIComponent(cur)).then(function (d) { paint(d.items, false); }).catch(function (e) { if (e.message !== "not found") msg("✗ " + e.message, "bad"); else go(""); });
  }
  function refresh() { loadInfo(); return searching ? doSearch() : go(cur); }

  var st = null;
  $("q").addEventListener("input", function () { clearTimeout(st); st = setTimeout(doSearch, 300); });
  function doSearch() {
    var q = $("q").value.trim();
    if (q.length < 2) { if (searching) { searching = false; go(cur); } return; }
    searching = true;
    return api("api/bank/search?q=" + encodeURIComponent(q)).then(function (d) { paint(d.items, true); }).catch(function (e) { msg("✗ " + e.message, "bad"); });
  }

  // ------------------------------------------------------------------ uploads
  function upload(files) {
    var list = Array.prototype.slice.call(files || []);
    if (!list.length) return;
    var maxB = ((info && info.max_upload_mb) || 4096) * 1048576, done = 0, failed = 0;
    function next() {
      if (!list.length) { msg(failed ? ("✗ " + failed + " upload(s) failed") : ("✓ Uploaded " + done + " file" + (done === 1 ? "" : "s")), failed ? "bad" : "good"); refresh(); return; }
      var f = list.shift();
      if (f.size > maxB) { failed++; msg("✗ " + f.name + " is too big", "bad"); return next(); }
      var line = document.createElement("div"); line.innerHTML = esc(f.name) + " · " + size(f.size) + "<i></i>";
      $("prog").appendChild(line);
      var x = new XMLHttpRequest();
      x.open("POST", "api/bank/upload?path=" + encodeURIComponent(cur) + "&name=" + encodeURIComponent(f.name));
      x.setRequestHeader("X-Bank-Pin", pin());
      x.upload.onprogress = function (e) { if (e.lengthComputable) line.querySelector("i").style.width = Math.round(100 * e.loaded / e.total) + "%"; };
      x.onload = function () {
        line.remove();
        if (x.status === 200) done++;
        else {
          failed++;
          var err = ""; try { err = JSON.parse(x.responseText).error; } catch (e) {}
          if (x.status === 403) { list = []; askPin(true); }
          if (x.status === 402) showLocked();
          msg("✗ " + f.name + ": " + (err || "upload failed"), "bad");
        }
        next();
      };
      x.onerror = function () { line.remove(); failed++; next(); };
      x.send(f);
    }
    next();
  }
  $("files").addEventListener("change", function () { upload(this.files); this.value = ""; });
  var drop = $("drop");
  ["dragenter", "dragover"].forEach(function (ev) { document.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.add("on"); }); });
  ["dragleave", "drop"].forEach(function (ev) { document.addEventListener(ev, function (e) { e.preventDefault(); if (ev === "drop" || !e.relatedTarget) drop.classList.remove("on"); }); });
  document.addEventListener("drop", function (e) { if (e.dataTransfer && e.dataTransfer.files.length) upload(e.dataTransfer.files); });

  $("btn-mkdir").addEventListener("click", function () {
    var n = window.prompt("Name for the new folder");
    if (n) api("api/bank/mkdir", { path: cur, name: n }).then(refresh).catch(function (e) { msg("✗ " + e.message, "bad"); });
  });

  // ------------------------------------------------------------------ PIN
  function askPin(wrong) {
    var p = window.prompt((wrong ? "That needs the upload PIN. " : "") + "Enter the Crash Bank upload PIN:", "");
    if (p !== null) setPin(p.trim());
  }
  $("btn-pin").addEventListener("click", function () { if (pin()) { setPin(""); msg("PIN forgotten on this device"); } else askPin(false); });
  $("btn-savepin").addEventListener("click", function () {
    var np = $("s-pin").value.trim();
    api("api/bank/settings", { pin: np }).then(function () { setPin(np); $("s-pin").value = ""; msg(np ? "✓ Upload PIN set" : "✓ PIN removed: anyone on the network can upload", "good"); loadInfo(); })
      .catch(function (e) { msg("✗ " + e.message, "bad"); });
  });

  function loadInfo() {
    return api("api/bank/info").then(function (d) {
      info = d;
      $("locked").hidden = true; $("main").hidden = false; $("settings").hidden = false;
      $("chip-store").textContent = ({ usb: "USB STICK", board: "ON BOARD", custom: "CUSTOM FOLDER" }[d.where] || "") + " · " + size(d.free) + " FREE";
      $("store-info").textContent = "Stored " + ({ usb: "on the USB stick (folder CrashBank)", board: "on the board itself (data/bank)", custom: "in a custom folder" }[d.where]) +
        ". " + size(d.free) + " free of " + size(d.total) + ". " + (d.pin_set ? "An upload PIN is set." : "No upload PIN: anyone on your Wi-Fi can upload.");
    });
  }

  fetch("api/state", { cache: "no-store" }).then(function (r) { return r.json(); }).then(function (s) {
    var t = s && s.config && s.config.theme;
    if (t && t !== "ops") document.documentElement.setAttribute("data-theme", t); else document.documentElement.removeAttribute("data-theme");
  }).catch(function () {});
  paintPin();
  loadInfo().then(function () { go(decodeURIComponent((location.hash || "").slice(1))); }).catch(function () {});
})();
