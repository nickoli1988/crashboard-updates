/* CRASH BOARD RADIO page: station presets, live audio (Web Audio), NOAA alert watch. */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var S = null, editing = false, player = null;

  function api(path, body) {
    var opt = body === undefined ? { cache: "no-store" } :
      { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) };
    return fetch(path, opt).then(function (r) {
      return r.json().then(function (j) { if (!r.ok) throw new Error(j.error || ("error " + r.status)); return j; });
    });
  }
  function fmtFreq(st) {
    if (!st) return "---.-";
    return st.band === "am" ? String(Math.round(st.freq * 1000)) : Number(st.freq).toFixed(st.band === "noaa" ? 3 : 1);
  }
  function unit(b) { return b === "am" ? "kHz" : "MHz"; }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }

  // ------------------------------------------------------------------ audio player (raw 16-bit PCM over HTTP)
  function newCtx() { var c = new (window.AudioContext || window.webkitAudioContext)(); if (c.resume) c.resume(); return c; }
  function Player(ctx) {
    var self = this;
    this.ctx = ctx || newCtx();
    this.gain = this.ctx.createGain();
    this.gain.gain.value = $("vol").value / 100;
    this.gain.connect(this.ctx.destination);
    this.next = 0;
    this.abort = new AbortController();
    this.stopped = false;
    fetch("api/radio/audio", { signal: this.abort.signal, cache: "no-store" }).then(function (r) {
      if (!r.ok || !r.body) throw new Error("no audio");
      var rate = parseInt(r.headers.get("X-Audio-Rate") || "32000", 10);
      var reader = r.body.getReader(), left = null, pend = [], pendLen = 0, chunk = Math.round(rate * 0.2);
      function pump() {
        return reader.read().then(function (res) {
          if (res.done || self.stopped) { self.ended(); return; }
          var b = res.value;
          if (left) { var m = new Uint8Array(left.length + b.length); m.set(left); m.set(b, left.length); b = m; left = null; }
          var even = b.length & ~1;
          if (even < b.length) left = b.slice(even);
          var dv = new DataView(b.buffer, b.byteOffset, even), n = even >> 1, f = new Float32Array(n), peak = 0;
          for (var i = 0; i < n; i++) { var v = dv.getInt16(i * 2, true) / 32768; f[i] = v; var a = v < 0 ? -v : v; if (a > peak) peak = a; }
          $("meter").style.width = Math.min(100, Math.round(peak * 140)) + "%";
          pend.push(f); pendLen += n;
          if (pendLen >= chunk) { self.play(pend, pendLen, rate); pend = []; pendLen = 0; }
          return pump();
        });
      }
      return pump();
    }).catch(function (e) { if (!self.stopped) { self.ended(); } });
  }
  Player.prototype.play = function (parts, len, rate) {
    var buf = this.ctx.createBuffer(1, len, rate), d = buf.getChannelData(0), o = 0;
    parts.forEach(function (p) { d.set(p, o); o += p.length; });
    var src = this.ctx.createBufferSource();
    src.buffer = buf;
    src.connect(this.gain);
    var now = this.ctx.currentTime;
    if (this.next < now + 0.05 || this.next > now + 2.5) this.next = now + 0.35;   // (re)start with a small cushion
    src.start(this.next);
    this.next += buf.duration;
  };
  Player.prototype.stop = function () {
    this.stopped = true;
    try { this.abort.abort(); } catch (e) {}
    try { this.ctx.close(); } catch (e) {}
    $("meter").style.width = "0";
  };
  Player.prototype.ended = function () {
    if (player === this) { this.stop(); player = null; setTimeout(load, 300); }
  };

  function startAudio(ctx) { if (player) player.stop(); player = new Player(ctx); }
  function stopAudio() { if (player) { var p = player; player = null; p.stop(); } }

  // ------------------------------------------------------------------ actions
  function listen(st) {
    $("play-err").textContent = "";
    // create the AudioContext inside the tap (phones only allow sound that starts from a tap)
    var ctx = null;
    try { ctx = newCtx(); } catch (e) { $("play-err").textContent = "✗ This browser can't play audio."; return; }
    stopAudio();
    api("api/radio/listen", st).then(function (s) { startAudio(ctx); render(s); })
      .catch(function (e) { try { ctx.close(); } catch (x) {} $("play-err").textContent = "✗ " + e.message; });
  }
  function stopListen() {
    stopAudio();
    api("api/radio/stop", {}).then(render).catch(function () {});
  }
  function savePresets(list) { return api("api/radio", { presets: list }).then(render); }

  $("btn-play").addEventListener("click", function () {
    if (player) return stopListen();
    var st = (S && S.station) || (S && S.presets && S.presets[0]);
    if (!st) { $("play-err").textContent = "Add a station first."; return; }
    listen(st);
  });
  $("vol").addEventListener("input", function () { if (player) player.gain.gain.value = this.value / 100; });
  $("btn-edit").addEventListener("click", function () { editing = !editing; this.textContent = editing ? "DONE" : "EDIT"; $("presets").classList.toggle("editing", editing); });

  function tuned() {
    var band = $("t-band").value, raw = parseFloat($("t-freq").value);
    if (!raw) { $("play-err").textContent = "Type a frequency."; return null; }
    var freq = band === "am" ? (raw > 100 ? raw / 1000 : raw) : raw;
    return { band: band, freq: freq, name: $("t-name").value.trim().toUpperCase() };
  }
  $("btn-tune").addEventListener("click", function () { var t = tuned(); if (t) listen(t); });
  $("btn-save").addEventListener("click", function () {
    var t = tuned(); if (!t) return;
    var list = (S.presets || []).slice();
    list.push({ name: t.name || (fmtFreq(t) + " " + t.band.toUpperCase()), freq: t.freq, band: t.band });
    savePresets(list).then(function () { $("t-freq").value = ""; $("t-name").value = ""; });
  });
  $("t-band").addEventListener("change", function () { $("t-freq").placeholder = { fm: "e.g. 101.1", am: "e.g. 1010", noaa: "e.g. 162.550" }[this.value]; });

  $("presets").addEventListener("click", function (e) {
    var b = e.target.closest(".pre"); if (!b) return;
    var i = parseInt(b.dataset.i, 10), list = (S.presets || []).slice();
    if (e.target.classList.contains("x")) { list.splice(i, 1); savePresets(list); return; }
    if (!editing) listen(list[i]);
  });

  $("w-on").addEventListener("change", function () { api("api/radio", { watch: this.checked }).then(render); });
  $("w-freq").addEventListener("change", function () { api("api/radio", { noaa_freq: parseFloat(this.value) }).then(render); });
  $("btn-scan").addEventListener("click", function () {
    var b = this; b.disabled = true; b.textContent = "SCANNING…"; stopAudio();
    api("api/radio/scan", {}).then(function (r) {
      $("scanres").innerHTML = r.channels.map(function (c) {
        return '<span class="' + (c.freq === r.best ? "best" : "") + '">' + c.freq.toFixed(3) + " · +" + c.above_noise + " dB</span>";
      }).join("");
      return api("api/radio", { noaa_freq: r.best });
    }).then(render).catch(function (e) { $("scanres").innerHTML = '<span>✗ ' + esc(e.message) + "</span>"; })
      .then(function () { b.disabled = false; b.textContent = "FIND STRONGEST"; });
  });
  $("r-on").addEventListener("change", function () { api("api/radio", { enabled: this.checked }).then(render).catch(function (e) { $("r-err").textContent = e.message; }); });
  $("btn-apply").addEventListener("click", function () {
    api("api/radio", { gain: $("r-gain").value, ppm: $("r-ppm").value || 0 }).then(render).catch(function (e) { $("r-err").textContent = "✗ " + e.message; });
  });
  $("btn-detect").addEventListener("click", function () { api("api/radio/redetect", {}).then(render); });

  // ------------------------------------------------------------------ render
  function installBox(s) {
    var ins = s.install || { mode: s.windows ? "windows" : "pi-setup" };
    if (ins.busy) {
      return '<p class="note"><b>Installing radio support…</b> leave this page open. ' + (ins.step ? esc(ins.step) : "") + "</p>" +
        '<div class="inst-bar"><i style="animation-delay:-' + ((Date.now() / 1000) % 1.4).toFixed(2) + 's"></i></div>' +
        (ins.log && ins.log.length ? '<pre class="inst-log">' + esc(ins.log.slice(-4).join("\n")) + "</pre>" : "");
    }
    var out = "";
    if (ins.done && !ins.ok) out += '<p class="note err">✗ ' + esc(ins.error || "Install failed") + "</p>";
    if (ins.done && ins.ok && ins.step) out += '<p class="note ok">✓ ' + esc(ins.step) + "</p>";
    if (ins.mode === "pi") {
      if (ins.need_reboot || (s.tools_ok && !s.devices && ins.done))
        return out + '<p class="note">The drivers are in. Restart the Pi so it lets go of the stick (takes about a minute; the board comes back by itself).</p>' +
          '<button type="button" class="btn primary" data-act="reboot">RESTART THE PI</button>';
      return out + '<p class="note">Plug the SDR stick in, then press the button. The board downloads and installs everything it needs (internet required, 1–5 minutes).</p>' +
        '<button type="button" class="btn primary" data-act="install">' + (s.tools_ok ? "REINSTALL RADIO SUPPORT" : "INSTALL RADIO SUPPORT") + "</button>";
    }
    if (ins.mode === "windows") {
      return out + '<p class="note">Plug the SDR stick in, then press the button. The board downloads the radio tools and opens <b>Zadig</b> (click <b>Yes</b> when Windows asks). In Zadig: <b>Options → List All Devices</b> → pick <b>Bulk-In, Interface (Interface 0)</b> → <b>WinUSB</b> → <b>Replace Driver</b>. Then press <b>RE-DETECT</b>.</p>' +
        '<button type="button" class="btn primary" data-act="install">' + (s.tools_ok ? "DOWNLOAD RADIO TOOLS AGAIN" : "INSTALL RADIO TOOLS") + "</button>";
    }
    if (ins.mode === "pi-setup") {
      return out + '<p class="note"><b>One-time step to turn on this button:</b> this board was installed before the radio button existed. ' +
        "On the Pi, open the <b>Crash Board</b> folder, double-click <b>Install Crash Board.sh</b> and choose <b>Execute in Terminal</b>. " +
        "When it says DONE, come back here and press <b>INSTALL RADIO SUPPORT</b>.</p>";
    }
    return out + '<p class="note">Radio support can\'t be installed on this device.</p>';
  }

  function setupText(s) {
    var ins = s.install || {};
    if (!s.tools_ok || ins.busy || (ins.done && (!ins.ok || ins.need_reboot)))
      return (s.tools_ok ? "" : '<p class="note"><b>Radio support isn\'t installed yet.</b></p>') + installBox(s);
    if (!s.devices) {
      var fix = (ins.mode === "pi" || ins.mode === "windows") ? '<p class="note">Still not found after RE-DETECT?</p>' + installBox(s) : "";
      return '<p class="note"><b>No SDR stick found.</b> Plug it in (straight into the computer, not a weak hub), then press <b>RE-DETECT</b>.' +
        (s.windows ? " On Windows, make sure Zadig set it to WinUSB." : "") + "</p>" + fix;
    }
    if (!s.enabled) return (ins.done && ins.ok ? '<p class="note ok">✓ ' + esc(ins.step || "Radio ready") + "</p>" : "") +
      '<p class="note"><b>SDR found (' + s.devices + ' stick' + (s.devices > 1 ? "s" : "") + ').</b> Tick <b>USE THE SDR STICK ON THIS BOARD</b> to turn the radio on.</p>';
    return "";
  }

  $("setup-body").addEventListener("click", function (e) {
    var b = e.target.closest("button[data-act]");
    if (!b) return;
    var act = b.dataset.act;
    if (act === "reboot" && !confirm("Restart the Pi now? The board will be back in about a minute.")) return;
    b.disabled = true; b.textContent = act === "reboot" ? "RESTARTING…" : "STARTING…";
    api("api/radio/" + act, {}).then(function (r) { render(r); fastPoll(); })
      .catch(function (err) { b.disabled = false; b.textContent = "TRY AGAIN"; $("setup-body").insertAdjacentHTML("afterbegin", '<p class="note err">✗ ' + esc(err.message) + "</p>"); });
  });
  var fastT = null;
  function fastPoll() {
    clearInterval(fastT);
    fastT = setInterval(function () {
      load();
      if (S && !(S.install && S.install.busy)) { clearInterval(fastT); fastT = null; }
    }, 1500);
  }

  function render(s) {
    S = s;
    var setup = setupText(s);
    $("setup").hidden = !setup; if ($("setup-body").innerHTML !== setup) $("setup-body").innerHTML = setup;
    var sdr = $("chip-sdr");
    if (!s.tools_ok) { sdr.className = "chip bad"; sdr.textContent = "SDR: NO TOOLS"; }
    else if (!s.devices) { sdr.className = "chip bad"; sdr.textContent = "SDR: NOT FOUND"; }
    else { sdr.className = "chip " + (s.enabled ? "ok" : "warn"); sdr.textContent = "SDR: " + s.devices + " STICK" + (s.devices > 1 ? "S" : "") + (s.enabled ? "" : " (OFF)"); }
    var w = $("chip-watch"), ws = s.watch_state;
    w.className = "chip " + (ws === "watching" ? "ok" : ws === "paused" ? "warn" : "");
    w.textContent = "NOAA WATCH: " + ({ watching: "ON " + Number(s.noaa_freq).toFixed(3), paused: "PAUSED", scanning: "SCANNING", off: "OFF" }[ws] || ws.toUpperCase());

    var st = s.station;
    $("now-freq").innerHTML = esc(fmtFreq(st)) + "<small>" + (st ? unit(st.band) + " " + st.band.toUpperCase() : "MHz") + "</small>";
    $("now-name").textContent = st ? (st.name || "TUNED") : "NOTHING PLAYING";
    var b = $("btn-play");
    b.textContent = player ? "■ STOP" : "▶ LISTEN";
    b.classList.toggle("on", !!player);
    $("share-note").innerHTML = s.two_sticks ? "Two sticks: NOAA watch keeps running while you listen." :
      (st && st.band !== "noaa" ? "<b>One stick:</b> NOAA alert watch is paused while you listen. Internet alerts still work, and watch resumes when you stop." :
        "Sound plays on this device. Tip: a second SDR stick lets NOAA watch run while you listen to other stations.");

    $("presets").innerHTML = (s.presets || []).map(function (p, i) {
      var cur = st && Math.abs(st.freq - p.freq) < 0.0005 && st.band === p.band;
      return '<button type="button" class="pre' + (cur ? " cur" : "") + '" data-i="' + i + '"><span class="x" title="Remove">✕</span><b>' +
        esc(fmtFreq(p)) + '</b><span>' + esc(p.band.toUpperCase() + " · " + p.name) + "</span></button>";
    }).join("") || '<p class="note">No stations yet: tune one below and press + SAVE.</p>';

    $("w-on").checked = !!s.watch;
    var sel = $("w-freq");
    if (!sel.options.length) (s.channels || []).forEach(function (c, i) { var o = document.createElement("option"); o.value = c; o.textContent = "WX" + (i + 1) + " · " + c.toFixed(3) + " MHz"; sel.appendChild(o); });
    sel.value = String(s.noaa_freq);
    $("watch-note").innerHTML = (s.county_fips ? "Matching warnings to county code <b>" + esc(s.county_fips) + "</b> (from your location)." :
      "County not known yet, so every warning on this channel counts as local. Set your location in CFG.") +
      " Not sure which channel? Press FIND STRONGEST, or look up your transmitter at weather.gov/nwr.";
    var al = s.messages || [];
    if (al.length) $("alerts").innerHTML = al.map(function (m) {
      var t = new Date(m.time * 1000);
      return '<li class="l' + m.level + '"><b>' + esc(m.event.toUpperCase()) + (m.local === false ? " · OTHER COUNTY" : "") + "</b><small>" +
        t.toLocaleString() + " · " + esc(m.raw) + "</small></li>";
    }).join("");
    $("r-on").checked = !!s.enabled;
    if (document.activeElement !== $("r-gain")) $("r-gain").value = s.gain || "";
    if (document.activeElement !== $("r-ppm")) $("r-ppm").value = s.ppm || "";
    $("r-err").textContent = s.error ? "✗ " + s.error : "";
    return s;
  }

  function load() { return api("api/radio").then(render).catch(function (e) { $("r-err").textContent = "✗ " + e.message; }); }
  fetch("api/state", { cache: "no-store" }).then(function (r) { return r.json(); }).then(function (st) {
    var t = st && st.config && st.config.theme;
    if (t && t !== "ops") document.documentElement.setAttribute("data-theme", t); else document.documentElement.removeAttribute("data-theme");
  }).catch(function () {});
  load();
  setInterval(load, 5000);
})();
