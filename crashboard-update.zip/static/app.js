/* CRASH BOARD client — vanilla JS, no dependencies, no optional chaining (old WebKit safe). */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var Q = new URLSearchParams(location.search);
  var POLL_MS = 30000;
  var STALE_S = { quakes: 900, alerts: 900, tsunami: 900, weather: 2400, gdacs: 2400, space: 2400, defcon: 7200, news: 7200, outbreaks: 7200, fire: 2400 };
  var state = null, lastLevel = null, skew = 0, mapLoaded = false;

  // ---------- prefs (per device) ----------
  function pref(k, d) { try { var v = localStorage.getItem("cb." + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } }
  function setPref(k, v) { try { localStorage.setItem("cb." + k, JSON.stringify(v)); } catch (e) {} }
  // Effects level: "full" (PC), "low" (lighter animations for a Pi Zero), "off" (no motion).
  // Saved per screen; the Pi Zero kiosk passes ?fx=low as its starting point.
  var fx = pref("fx", null) || Q.get("fx") || ((Q.has("lite") ? Q.get("lite") !== "0" : pref("lite", false)) ? "off" : "full");
  if (["full", "low", "off"].indexOf(fx) < 0) fx = "full";
  var lite = fx === "off";
  document.body.classList.toggle("fx-low", fx === "low");
  // Display mode: a Wi-Fi screen showing a Crash Board hosted elsewhere (bigger small-print)
  if (Q.get("display") === "1") document.body.classList.add("display");
  var sound = pref("sound", false);
  // Inside the Crash Board Android app: radio, Crash Bank and display hosting live on a PC or Pi
  if (Q.get("app") === "1") document.body.classList.add("in-app");
  document.body.classList.toggle("lite", !!lite);

  // ---------- utils ----------
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function pad(n) { return (n < 10 ? "0" : "") + n; }
  function nowS() { return Date.now() / 1000 + skew; }
  function ago(ts) {
    if (!ts) return "--";
    var s = Math.max(0, nowS() - ts);
    if (s < 60) return Math.floor(s) + "S";
    if (s < 3600) return Math.floor(s / 60) + "M";
    if (s < 86400) return Math.floor(s / 3600) + "H " + Math.floor((s % 3600) / 60) + "M";
    return Math.floor(s / 86400) + "D " + Math.floor((s % 86400) / 3600) + "H";
  }
  function zulu(ts) {
    if (!ts) return "--";
    var d = new Date(ts * 1000);
    return pad(d.getUTCDate()) + " " + pad(d.getUTCHours()) + pad(d.getUTCMinutes()) + "Z";
  }
  function feed(name) { return (state && state.feeds && state.feeds[name]) || {}; }
  function data(name) { return feed(name).data || null; }
  function li(cls, inner) { return '<li class="' + (cls || "") + '">' + inner + "</li>"; }
  function setList(id, html, emptyText) { $(id).innerHTML = html || li("empty", emptyText); }
  function compass(deg) { if (deg == null) return "--"; return CBL.dir(["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"][Math.round(deg / 22.5) % 16]); }
  function r0(v) { return v == null ? "--" : Math.round(v); }

  // ---------- clocks ----------
  var MON = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
  function tickClock() {
    var d = new Date(Date.now() + skew * 1000);
    $("clk-local").textContent = pad(d.getHours()) + ":" + pad(d.getMinutes()) + ":" + pad(d.getSeconds());
    $("clk-zulu").textContent = pad(d.getUTCHours()) + ":" + pad(d.getUTCMinutes()) + ":" + pad(d.getUTCSeconds()) + "Z";
    $("clk-date").textContent = pad(d.getDate()) + " " + CBL.mon(d.getMonth()) + " " + d.getFullYear();
  }
  setInterval(tickClock, 1000); tickClock();

  // ---------- map ----------
  function proj(lat, lon) { return [(lon + 180), (90 - lat)]; }
  function buildGrid() {
    var g = "";
    for (var x = 0; x <= 360; x += 30) g += '<line x1="' + x + '" y1="0" x2="' + x + '" y2="180"/>';
    for (var y = 0; y <= 180; y += 30) g += '<line x1="0" y1="' + y + '" x2="360" y2="' + y + '"' + (y === 90 ? ' class="eq"' : "") + "/>";
    $("map-grid").innerHTML = g;
  }
  function loadMap() {
    if (mapLoaded || !state || !state.has_map) return;
    fetch("api/map").then(function (r) { return r.ok ? r.text() : ""; }).then(function (d) {
      if (d) { $("map-land").setAttribute("d", d); mapLoaded = true; }
    }).catch(function () {});
  }
  buildGrid();

  // ---------- doomsday dial ticks ----------
  (function () {
    var g = "";
    for (var i = 0; i < 60; i++) {
      var a = i * 6 * Math.PI / 180, major = i % 5 === 0, r1 = major ? 44 : 48;
      g += '<line class="tick' + (major ? " major" : "") + '" x1="' + (60 + Math.sin(a) * r1).toFixed(1) + '" y1="' + (60 - Math.cos(a) * r1).toFixed(1) +
        '" x2="' + (60 + Math.sin(a) * 52).toFixed(1) + '" y2="' + (60 - Math.cos(a) * 52).toFixed(1) + '"/>';
    }
    $("doom-ticks").innerHTML = g;
  })();

  // ---------- render ----------
  function renderAges() {
    var nodes = document.querySelectorAll("[data-age]");
    for (var i = 0; i < nodes.length; i++) {
      var k = nodes[i].getAttribute("data-age"), f = feed(k);
      var stale = !f.updated || (nowS() - f.updated) > (STALE_S[k] || 1800);
      nodes[i].textContent = f.updated ? ("UPD " + ago(f.updated) + (f.ok ? "" : " · ERR")) : (f.error ? "NO LINK" : "…");
      nodes[i].title = f.error || "";
      nodes[i].classList.toggle("stale", stale || (!f.ok && !!f.error));
      var p = nodes[i].closest(".panel");
      if (p) p.classList.toggle("stale", stale && !!f.error);
    }
  }

  function renderCondition() {
    var c = state.condition;
    ["local", "global"].forEach(function (k) {
      var h = c[k] || (k === "global" ? c : { level: 0, name: "GREEN", reasons: [] });
      var rs = (h.reasons || []).map(function (r) { return r.replace(/^LOCAL: /, ""); });
      $("cond-" + k).setAttribute("data-level", h.level);
      $("cond-" + k + "-name").textContent = h.name;
      $("cond-" + k + "-reasons").textContent = rs.length ? rs.join("  //  ") :
        (k === "local" && !(state.config.location && state.config.location.name) ? "SET LOCATION IN CFG" : "NO SIGNIFICANT THREATS DETECTED");
    });
    lastLevel = c.level;
  }

  function renderDefcon() {
    var d = data("defcon");
    var lvl = d ? d.level : null;
    $("defcon-num").textContent = lvl || "-";
    var bars = $("defcon-bars").children;
    for (var i = 0; i < bars.length; i++) bars[i].classList.toggle("on", String(lvl) === bars[i].getAttribute("data-l"));
    $("defcon-src").textContent = d ? ("SRC: " + d.source + ". Actual DEFCON is classified and not published.") :
      "Actual DEFCON is classified. Waiting on open-source estimate…";
  }

  function renderDoom() {
    var dd = state.config.doomsday || {};
    var s = dd.seconds;
    $("doom-sec").textContent = s == null ? "--" : s;
    // minute hand: seconds-before-midnight mapped onto the dial (exaggerated so it's visible)
    var deg = s == null ? 0 : -Math.min(90, Math.max(3, s / 10));
    $("doom-hand").setAttribute("transform", "rotate(" + deg + " 60 60)");
    $("doom-set").textContent = "SET " + (dd.set || "--") + " · " + (dd.source || "");
  }

  function renderNews() {
    var d = data("news");
    var html = "";
    if (d) d.items.forEach(function (n) {
      html += li("", '<a href="' + esc(n.link) + '" target="_blank" rel="noopener"><div class="t">' + '<span class="raw">' + esc(n.title) + '</span>' +
        '</div><div class="m">' + '<span class="raw">' + esc(n.src) + '</span>' + " · " + zulu(n.time) + " · " + ago(n.time) + " AGO</div></a>");
    });
    setList("news-list", html, feed("news").error ? "FEED UNREACHABLE" : "NO MATCHING TRAFFIC");
  }

  function renderQuakes() {
    var d = data("quakes");
    $("quake-min").textContent = "M" + Number(state.config.quake_min_mag).toFixed(1) + "+";
    var ev = (d && d.events) || [], t = nowS();
    var c24 = 0, c7 = 0, max = 0, tsu = 0, html = "", dots = "";
    ev.forEach(function (e) {
      var age = t - e.time;
      if (age < 86400) c24++;
      if (age < 7 * 86400) c7++;
      if (age < 7 * 86400 && e.mag > max) max = e.mag;
      if (e.tsunami && age < 7 * 86400) tsu++;
    });
    $("quake-stats").innerHTML =
      '<div class="stat' + (c24 ? " hot" : "") + '"><span class="lbl">24H</span><b>' + c24 + "</b></div>" +
      '<div class="stat"><span class="lbl">7D</span><b>' + c7 + "</b></div>" +
      '<div class="stat' + (max >= 7 ? " hot" : "") + '"><span class="lbl">MAX 7D</span><b>' + (max ? max.toFixed(1) : "--") + "</b></div>" +
      '<div class="stat' + (tsu ? " hot" : "") + '"><span class="lbl">TSU FLAG</span><b>' + tsu + "</b></div>";
    // plot oldest first so newest draw on top
    ev.slice().reverse().forEach(function (e) {
      var p = proj(e.lat, e.lon), age = t - e.time;
      var cls = age < 86400 ? "d24" : age < 7 * 86400 ? "d7" : "d30";
      var r = Math.max(1.4, (e.mag - 5.5) * 1.6).toFixed(1);
      dots += '<circle class="q ' + cls + '" cx="' + p[0].toFixed(1) + '" cy="' + p[1].toFixed(1) + '" r="' + r + '"><title>M' + e.mag + " " + esc(e.place) + "</title></circle>";
      if (age < 86400) dots += '<circle class="qpulse" cx="' + p[0].toFixed(1) + '" cy="' + p[1].toFixed(1) + '" r="' + r + '"/>';
    });
    $("map-quakes").innerHTML = dots;
    ev.slice(0, 20).forEach(function (e) {
      var age = t - e.time;
      var cls = (e.mag >= 7 ? "big7 l3" : e.mag >= 6.5 ? "l2" : "l1") + (age < 86400 ? " fresh" : "");
      var flags = (e.tsunami ? ' <span class="tag hot">TSUNAMI FLAG</span>' : "") +
        (e.alert && e.alert !== "green" ? ' <span class="tag warn">PAGER ' + esc(e.alert.toUpperCase()) + "</span>" : "");
      html += li(cls, '<a href="' + esc(e.url) + '" target="_blank" rel="noopener"><div class="t"><span class="mag">' + e.mag.toFixed(1) +
        "</span>" + '<span class="raw">' + esc(e.place) + '</span>' + flags + '</div><div class="m">' + zulu(e.time) + " · " + ago(e.time) + " AGO · DEPTH " + r0(e.depth) + " KM</div></a>");
    });
    setList("quake-list", html, d ? "NO M" + Number(state.config.quake_min_mag).toFixed(1) + "+ EVENTS IN " + (d.days || 30) + " DAYS" : "AWAITING USGS");
  }

  function renderHome() {
    var loc = state.config.location || {};
    if (loc.lat == null) { $("map-home").innerHTML = ""; return; }
    var p = proj(loc.lat, loc.lon);
    $("map-home").innerHTML = '<g class="home"><circle cx="' + p[0] + '" cy="' + p[1] + '" r="3"/><line x1="' + (p[0] - 6) + '" y1="' + p[1] + '" x2="' + (p[0] + 6) + '" y2="' + p[1] +
      '"/><line x1="' + p[0] + '" y1="' + (p[1] - 6) + '" x2="' + p[0] + '" y2="' + (p[1] + 6) + '"/><title>HOME: ' + esc(loc.name) + "</title></g>";
  }

  function renderWeather() {
    var w = data("weather");
    var loc = state.config.location || {};
    $("wx-loc").textContent = loc.name ? loc.name.toUpperCase() : "NO LOC";
    if (!w || !w.configured) { $("wx-body").innerHTML = '<div class="empty">SET LOCATION IN CFG</div>'; return; }
    var imp = w.units === "imperial", tu = imp ? "°F" : "°C", su = imp ? "MPH" : "KM/H", pu = imp ? "IN" : "MM";
    var days = "", DOW = ["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"];
    (w.days || []).forEach(function (d, i) {
      var dt = new Date(d.date + "T12:00:00");
      days += '<div class="day"><div class="d">' + (i === 0 ? "TODAY" : CBL.dow(dt.getDay())) + '</div><div class="hl">' + r0(d.hi) + "° / " + r0(d.lo) + '°</div><div class="c">' + esc(d.cond) +
        '</div><div class="m lbl">POP ' + r0(d.pop) + "%</div></div>";
    });
    function cell(lbl, v) { return '<div class="stat"><span class="lbl">' + lbl + "</span><b>" + v + "</b></div>"; }
    var sr = w.sunrise ? w.sunrise.slice(11, 16) : "--", ss = w.sunset ? w.sunset.slice(11, 16) : "--";
    $("wx-body").innerHTML =
      '<div class="wx-now"><div class="wx-temp">' + r0(w.temp) + "<sup>" + tu + '</sup></div><div><div class="wx-cond">' + esc(w.cond) +
      '</div><div class="lbl">FEELS ' + r0(w.feels) + "° · RH " + r0(w.rh) + "%</div></div></div>" +
      '<div class="wx-grid">' +
      cell("WIND " + su, r0(w.wind) + " " + compass(w.wdir)) + cell("GUST " + su, r0(w.gust)) + cell("PRESS HPA", r0(w.pressure)) +
      cell("CLOUD", r0(w.cloud) + "%") + cell("PRECIP " + pu, w.precip == null ? "--" : w.precip) + cell("SUN ↑↓", sr + "/" + ss) +
      "</div>" + '<div class="wx-days">' + days + "</div>";
  }

  function renderAlerts() {
    var d = data("alerts");
    var html = "", n = 0, sepDone = false;
    function item(a) {
      var lv = a.severity === "Extreme" ? "l3" : a.severity === "Severe" ? "l2" : a.severity === "Moderate" ? "l1" : "";
      return li(lv + (a.local === false ? " far" : ""), "<details><summary><div class=\"t\">" + '<span class="raw">' + esc((a.event || "").toUpperCase()) + '</span>' + "</div><div class=\"m\">" + esc(a.severity).toUpperCase() +
        (a.area ? " · " + '<span class="raw">' + esc(String(a.area).toUpperCase().slice(0, 60)) + '</span>' : "") + (a.expires ? " · EXP " + zulu(a.expires) : "") + "</div></summary>" +
        '<div class="ins">' + esc(a.headline) + "\n\n" + esc(a.description) + (a.instruction ? "\n\n>> " + esc(a.instruction) : "") + "</div></details>");
    }
    if (d && d.alerts) d.alerts.forEach(function (a) {
      if (a.local === false && !sepDone) { html += '<li class="alert-sep">ELSEWHERE IN ' + esc(countryName(state.config.location.country)) + "</li>"; sepDone = true; }
      if (a.local !== false) n++;
      html += item(a);
    });
    var badge = $("alert-count");
    badge.textContent = n;
    badge.className = "tag" + (n ? " hot" : "");
    var empty = !d || !d.configured ? "SET LOCATION IN CFG" : (d.note || (d.supported === false ? "NO LOCAL WARNING FEED FOR THIS COUNTRY" : "NO ACTIVE ALERTS"));
    setList("alert-list", html, empty);
    if (d && d.source) $("alert-list").insertAdjacentHTML("beforeend", '<li class="alert-sep">SOURCE: ' + '<span class="raw">' + esc(d.source) + '</span>' + "</li>");
  }
  function countryName(cc) {
    var l = (state && state.countries) || [];
    for (var i = 0; i < l.length; i++) if (l[i][0] === cc) return l[i][1].toUpperCase();
    return cc || "COUNTRY";
  }

  function renderTsunami() {
    var d = data("tsunami");
    var html = "";
    if (d) d.events.forEach(function (e) {
      var lv = e.level === "WARNING" ? "l3" : (e.level === "ADVISORY" || e.level === "WATCH" || e.level === "THREAT") ? "l2" : "";
      html += li(lv, '<div class="t">' + (lv ? '<span class="tag hot">' + e.level + "</span> " : '<span class="tag">INFO</span> ') + '<span class="raw">' + esc(e.title) + '</span>' +
        '</div><div class="m">' + e.center + " · " + zulu(e.time) + " · " + ago(e.time) + " AGO</div>");
    });
    setList("tsu-list", html, d ? "NO BULLETINS 72H" : "AWAITING NOAA");
  }

  function renderSpace() {
    var d = data("space");
    if (!d) { $("space-body").innerHTML = '<div class="empty">AWAITING NOAA SWPC</div>'; return; }
    var bars = "";
    (d.series || []).forEach(function (k) {
      var c = k >= 7 ? "k7" : k >= 6 ? "k6" : k >= 5 ? "k5" : "";
      bars += '<i class="' + c + '" style="height:' + Math.max(3, k / 9 * 100) + '%" title="Kp ' + k + '"></i>';
    });
    var al = "";
    (d.alerts || []).slice(0, 3).forEach(function (a) { al += li("", '<div class="t">' + esc(a.head) + '</div><div class="m">' + zulu(a.time) + "</div>"); });
    var desc = ["QUIET", "MINOR STORM", "MODERATE STORM", "STRONG STORM", "SEVERE STORM", "EXTREME STORM"][d.g || 0];
    $("space-body").innerHTML =
      '<div class="kp-row"><div class="gbadge g' + (d.g || 0) + '">G' + (d.g || 0) + '</div><div><div class="wx-cond">' + desc +
      '</div><div class="lbl">KP ' + (d.kp == null ? "--" : d.kp.toFixed(2)) + " · 24H PEAK " + (d.kp_peak_24h == null ? "--" : d.kp_peak_24h.toFixed(1)) +
      '</div></div></div><div class="kp-bars">' + bars + '</div><div class="lbl" style="margin-top:2px">PLANETARY KP · 3H BINS · G4+ CAN DISRUPT POWER GRID / HF / GPS</div>' +
      (al ? '<ul class="feed">' + al + "</ul>" : "");
  }

  function renderGdacs() {
    var d = data("gdacs");
    var html = "", marks = "";
    if (d) d.events.forEach(function (e) {
      html += li(e.level === "RED" ? "l3" : "l2", '<div class="t"><span class="tag ' + (e.level === "RED" ? "hot" : "warn") + '">' + e.level + " " + esc(e.type) + "</span> " + '<span class="raw">' + esc(e.title) + '</span>' +
        '</div><div class="m"><span class="raw">' + esc(e.country || "") + '</span> · ' + zulu(e.time) + "</div>");
      if (e.lat != null) {
        var p = proj(e.lat, e.lon);
        marks += '<path class="gd' + (e.level === "RED" ? " red" : "") + '" d="M' + p[0].toFixed(1) + " " + (p[1] - 3.5).toFixed(1) + "l3.2 5.6h-6.4z\"><title>" + esc(e.title) + "</title></path>";
      }
    });
    $("map-gdacs").innerHTML = marks;
    setList("gdacs-list", html, d ? "NO ORANGE/RED EVENTS" : "AWAITING GDACS");
  }

  function renderOutbreaks() {
    var d = data("outbreaks");
    var cdc = "", who = "", t = nowS(), top = 0;
    if (d) {
      (d.cdc || []).forEach(function (n) {
        if (n.level > top) top = n.level;
        if (n.level < 2) return;
        var cls = n.level >= 4 ? "l3" : n.level === 3 ? "l2" : n.high ? "l1" : "";
        cdc += li(cls, '<a href="' + esc(n.link) + '" target="_blank" rel="noopener"><div class="t"><span class="lvl v' + n.level + '">L' + n.level + "</span>" +
          '<span class="raw">' + esc(n.title) + '</span></div>' + (n.time ? '<div class="m">' + zulu(n.time) + " · " + ago(n.time) + " AGO</div>" : "") + "</a>");
      });
      (d.who || []).slice(0, 6).forEach(function (w) {
        var fresh = w.time && t - w.time < 14 * 86400;
        var cls = w.high && fresh ? "l2" : w.high ? "l1" : "";
        who += li(cls, '<a href="' + esc(w.link) + '" target="_blank" rel="noopener"><div class="t">' + (w.high ? '<span class="tag warn">HIGH-CONSEQUENCE</span> ' : "") +
          '<span class="raw">' + esc(w.title) + '</span></div><div class="m">' + zulu(w.time) + " · " + ago(w.time) + " AGO</div></a>");
      });
    }
    var tag = $("bio-top");
    tag.textContent = top ? "CDC MAX L" + top : "--";
    tag.className = "tag" + (top >= 3 ? " hot" : top === 2 ? " warn" : "");
    setList("cdc-list", cdc, d ? "NO LEVEL 2+ NOTICES" : "AWAITING CDC");
    setList("who-list", who, d ? "NO RECENT REPORTS" : "AWAITING WHO");
  }

  var DNAMES = ["ABNORMALLY DRY", "MODERATE", "SEVERE", "EXTREME", "EXCEPTIONAL"];
  function renderFire() {
    var d = data("fire"), cfg = state.config, imp = cfg.units === "imperial";
    function dist(km) { return imp ? Math.round(km / 1.609) + " MI" : Math.round(km) + " KM"; }
    var tag = $("fire-count");
    if (!d || !d.configured) {
      setList("fire-list", "", d ? "SET LOCATION IN CFG" : "AWAITING NIFC"); tag.textContent = "--"; tag.className = "tag";
    } else if (d.supported === false) {
      setList("fire-list", "", "NO LOCAL WILDFIRE DATA HERE · SEE GLOBAL DISASTERS");
      tag.textContent = "--"; tag.className = "tag";
    } else {
      var alertKm = (cfg.fire_alert_mi || 15) * 1.609, html = "", dots = "";
      $("fire-sub").textContent = "WILDFIRES WITHIN " + (imp ? (d.list_mi || 100) + " MI" : Math.round((d.list_mi || 100) * 1.609 / 10) * 10 + " KM");
      (d.fires || []).forEach(function (f) {
        var near = f.km <= alertKm, big = (f.acres || 0) >= 1000 && (f.contained || 0) < 50;
        var cls = near ? "l3" : big ? "l2" : (f.acres || 0) >= 100 ? "l1" : "";
        var cont = f.status ? esc(f.status) : f.contained == null ? "" : '<span class="cbar"><i style="width:' + Math.max(0, Math.min(100, f.contained)) + '%"></i></span>' + Math.round(f.contained) + "% CONT";
        var sz = f.acres == null ? null : imp ? f.acres : f.acres / 2.471;
        var acres = f.kind === "hotspot" ? "SATELLITE" : sz == null ? "SIZE ?" : (sz >= 10 ? Math.round(sz).toLocaleString("en-US") : Math.round(sz * 10) / 10) + (imp ? " AC" : " HA");
        if (f.level && f.level !== "NOT APPLICABLE") cls = /EMERGENCY/.test(f.level) ? "l3" : /WATCH/.test(f.level) ? "l2" : cls;
        html += li(cls, '<div class="t"><span class="dist">' + dist(f.km) + " " + esc(f.dir) + "</span><b class=\"raw\">" + esc(f.name) + "</b></div>" +
          '<div class="m">' + acres + " · " + cont + (f.found ? " · FOUND " + ago(f.found) + " AGO" : "") + (f.county ? " · " + esc(String(f.county).toUpperCase()) + " CO" : "") + "</div>");
        var p = proj(f.lat, f.lon);
        dots += '<rect class="fdot' + (near ? " near" : "") + '" x="' + (p[0] - 0.9).toFixed(2) + '" y="' + (p[1] - 0.9).toFixed(2) + '" width="1.8" height="1.8"><title>' + esc(f.name) + "</title></rect>";
      });
      $("map-fire").innerHTML = dots;
      setList("fire-list", html, "NO ACTIVE WILDFIRES NEARBY");
      if (d.source) $("fire-list").insertAdjacentHTML("beforeend", '<li class="alert-sep">SOURCE: ' + '<span class="raw">' + esc(d.source) + '</span>' + "</li>");
      var nearN = (d.fires || []).filter(function (f) { return f.km <= alertKm; }).length;
      tag.textContent = (d.nearby || 0) + " NEAR" + (nearN ? " · " + nearN + " CLOSE" : "");
      tag.className = "tag" + (nearN ? " hot" : d.nearby ? " warn" : "");
    }
    // fire weather from local NWS alerts
    var al = data("alerts"), fw = "";
    if (al && al.alerts) al.alerts.forEach(function (a) {
      if (a.local !== false && /fire|red flag|smoke|evacuat|bushfire/i.test(a.event || "")) fw += li(a.rank >= 3 ? "l3" : a.rank >= 2 ? "l2" : "l1",
        '<div class="t">' + '<span class="raw">' + esc((a.event || "").toUpperCase()) + '</span>' + '</div><div class="m">' + (a.expires ? "UNTIL " + zulu(a.expires) : esc(a.severity || "")) + "</div>");
    });
    setList("fwx-list", fw, al && al.supported === false ? "NO LOCAL FEED" : "NONE ACTIVE");
    // drought
    var dr = d && d.drought, box = $("drought");
    $("dr-county").textContent = dr && dr.county ? "· " + dr.county.toUpperCase() : "";
    if (d && d.drought_note && !dr) { box.innerHTML = '<div class="empty">' + esc(d.drought_note.toUpperCase()) + "</div>"; }
    else if (dr && dr.point) {
      box.innerHTML = (dr.worst < 0 ? '<div class="dhead none">NO DROUGHT AT YOUR LOCATION</div>'
        : '<div class="dhead">D' + dr.worst + " " + DNAMES[dr.worst] + (dr.worst >= 1 ? " DROUGHT" : "") + " AT YOUR LOCATION</div>") +
        '<div class="fine">' + esc(dr.source || "") + "</div>";
    }
    else if (!dr) { box.innerHTML = '<div class="empty">' + (d && d.drought_error ? "DROUGHT MONITOR UNREACHABLE" : "AWAITING DROUGHT MONITOR") + "</div>"; }
    else {
      var head = dr.worst < 0 ? '<div class="dhead none">NO DROUGHT</div>'
        : '<div class="dhead">D' + dr.worst + " " + DNAMES[dr.worst] + (dr.worst >= 1 ? " DROUGHT" : "") + " · " + Math.round(dr.cum[dr.worst]) + "% OF COUNTY</div>";
      var bars = dr.cum.map(function (v, i) { return '<div class="d' + i + (v >= 1 ? " hit" : "") + '">D' + i + "<b>" + Math.round(v) + "%</b></div>"; }).join("");
      box.innerHTML = head + '<div class="dbars">' + bars + '</div><div class="fine">US DROUGHT MONITOR · WEEK OF ' + esc(dr.date || "?") + " · % OF COUNTY AT THIS LEVEL OR WORSE</div>";
    }
  }

  function renderTicker() {
    var bits = [];
    if (state.setup) bits.push("◆ NO WI-FI: JOIN " + state.setup.ap + " ON YOUR PHONE TO PICK A NETWORK");
    state.condition.reasons.forEach(function (r) { bits.push("◆ " + r); });
    var q = data("quakes");
    if (q && q.events[0]) bits.push("◆ LATEST M" + q.events[0].mag.toFixed(1) + " " + q.events[0].place.toUpperCase() + " " + ago(q.events[0].time) + " AGO");
    var n = data("news");
    if (n) n.items.slice(0, 4).forEach(function (i) { bits.push("◆ " + i.src + ": " + i.title.toUpperCase()); });
    var fd = data("fire");
    if (fd && fd.fires && fd.fires[0]) bits.push("◆ NEAREST WILDFIRE: " + fd.fires[0].name + " " + (state.config.units === "imperial" ? Math.round(fd.fires[0].km / 1.609) + " MI " : Math.round(fd.fires[0].km) + " KM ") + fd.fires[0].dir);
    var ob = data("outbreaks");
    if (ob && ob.who && ob.who[0]) bits.push("◆ WHO: " + ob.who[0].title.toUpperCase());
    var s = data("space");
    if (s) bits.push("◆ SPACE WX G" + s.g + " KP " + (s.kp == null ? "--" : s.kp.toFixed(1)));
    var dc = data("defcon");
    if (dc) bits.push("◆ DEFCON " + dc.level + " (EST)");
    bits.push("◆ DOOMSDAY CLOCK " + state.config.doomsday.seconds + " SEC TO MIDNIGHT");
    var txt = bits.join("     ");
    var el = $("ticker");
    if (el.textContent !== txt) {
      el.textContent = txt;
      var dur = Math.max(40, txt.length / 7);
      el.style.animationDuration = dur + "s";
      // FX LOW: move the ticker in ~15 small jumps per second instead of every frame
      el.style.animationTimingFunction = fx === "low" ? "steps(" + Math.round(dur * 15) + ", end)" : "";
    }
  }

  // ---------- color schemes ----------
  var THEME_BG = { ops: "#0a0c08", blackout: "#050505", hazard: "#c9500a", coyote: "#17130d", vault: "#0a1730", cva: "#170d06", halloween: "#0b0610", nvg: "#000000", lab: "#08080a" };
  // retro fonts for some schemes, loaded from Google Fonts when online (standard fonts are used offline)
  var THEME_FONTS = {
    vault: "family=Oswald:wght@500;700&family=Share+Tech+Mono",
    cva: "family=Bebas+Neue&family=VT323",
    halloween: "family=Creepster",
    lab: "family=Rajdhani:wght@600;700&family=Share+Tech+Mono"
  };
  var curTheme = null;
  function applyTheme(t) {
    t = Q.get("theme") || t || "ops";
    if (!THEME_BG[t]) t = "ops";
    if (t === curTheme) return;
    curTheme = t;
    document.documentElement.setAttribute("data-theme", t);
    var m = document.querySelector('meta[name="theme-color"]'); if (m) m.setAttribute("content", THEME_BG[t]);
    setPref("theme", t);
    if (THEME_FONTS[t] && !document.getElementById("fonts-" + t)) {
      var l = document.createElement("link");
      l.id = "fonts-" + t; l.rel = "stylesheet";
      l.href = "https://fonts.googleapis.com/css2?" + THEME_FONTS[t] + "&display=swap";
      document.head.appendChild(l);
      l.onload = function () {   // size tweaks only once the retro font really arrived
        var fam = { cva: "VT323", vault: "Share Tech Mono", halloween: "Creepster" }[t] || "VT323";
        if (document.fonts && document.fonts.load) document.fonts.load('16px "' + fam + '"').then(function () {
          if (document.fonts.check('16px "' + fam + '"')) document.documentElement.classList.add("tf-loaded");
        });
      };
    }
  }

  function render() {
    if (!state) return;
    applyTheme(state.config.theme);
    CBL.set(Q.get("lang") || state.config.lang || "en");
    // logo sits between the first word and the rest: CRASH [logo] BOARD
    var cs = (state.config.callsign || "CRASH BOARD").trim(), sp = cs.indexOf(" ");
    $("callsign").querySelector(".cs-a").textContent = sp > 0 ? cs.slice(0, sp) : "";
    $("callsign").querySelector(".cs-b").textContent = sp > 0 ? cs.slice(sp + 1) : cs;
    var isBrand = cs.toUpperCase() === "CRASH BOARD";           // a board renamed to its owner's callsign gets no ™
    if ($("cs-tm")) $("cs-tm").hidden = !isBrand;
    if ($("cs-v")) $("cs-v").hidden = !isBrand;
    renderLicense();
    document.title = state.condition.name + " · " + (isBrand ? "Crash Board™" : cs);
    var parts = [renderCondition, renderDefcon, renderDoom, renderNews, renderQuakes, renderHome, renderWeather,
      renderAlerts, renderTsunami, renderSpace, renderGdacs, renderOutbreaks, renderFire, renderTicker, renderAges];
    parts.forEach(function (fn) { try { fn(); } catch (e) { console.error(fn.name, e); } });
    loadMap();
  }

  // ---------- board-wide screen defaults (first-time setup) ----------
  // A screen's own choice (saved in this browser) wins; otherwise the board's defaults apply.
  // The Pi's attached screen forgets its own choices at every restart, so it saves them to the board.
  var IS_KIOSK = Q.get("sound") === "1" && !Q.has("desktop") && /^(127\.0\.0\.1|localhost)$/.test(location.hostname);
  var screenApplied = false;
  function hasPref(k) { try { return localStorage.getItem("cb." + k) !== null; } catch (e) { return false; } }
  function applyScreenDefaults(sc) {
    if (screenApplied || !sc || !sc.set) return;
    screenApplied = true;
    if (!hasPref("sound") && typeof sc.sound === "boolean") sound = sc.sound;
    if (!hasPref("voice") && typeof sc.voice === "boolean") voice = sc.voice;
    if (!hasPref("volume") && typeof sc.volume === "number") volume = sc.volume;
    if (!hasPref("quiet") && sc.quiet) quiet = sc.quiet;
    if (!hasPref("scope") && ["all", "local", "global"].indexOf(sc.alerts) >= 0) scope = sc.alerts;
    if (!hasPref("fx") && ["full", "low", "off"].indexOf(sc.fx) >= 0) {
      fx = sc.fx; lite = fx === "off";
      document.body.classList.toggle("lite", lite); document.body.classList.toggle("fx-low", fx === "low");
    }
    if (IS_KIOSK) {      // touch mode, cycle speed and panel layout belong to the attached screen only
      if (!hasPref("touch") && ["auto", "on", "off"].indexOf(sc.touch) >= 0) touchPref = sc.touch;
      if (!hasPref("cycle") && [0, 10, 20, 30, 60].indexOf(sc.cycle) >= 0) cycleSec = sc.cycle;
      if (!hasPref("layout") && sc.layout && typeof sc.layout === "object") layoutPref = sc.layout;
    }
    applyLayout(); layout();
    if (sound) ensureAudio();
    renderAudioBtn();
  }
  function screenNow() { return { sound: !!sound, volume: volume, voice: !!voice, quiet: quiet, fx: fx, alerts: scope, touch: touchPref || "auto", cycle: cycleNow(), layout: layoutPref }; }

  // ---------- polling ----------
  var bootVersion = null;
  function renderUpdate() {
    var u = state && state.update;
    if (!u) { $("upd-status").textContent = "Updates aren't available on this device - download the latest version from LL3D."; $("btn-upd-check").hidden = true; return; }
    $("upd-ver").textContent = "v" + u.version;
    $("upd-status").innerHTML = u.busy || (u.msg && /ing|restart/i.test(u.msg)) ? "⏳ " + esc(u.msg)
      : u.available ? '<span class="pro">NEW VERSION v' + esc(u.available) + " AVAILABLE</span>" + (u.notes ? "<br>" + esc(u.notes) : "")
      : u.error ? '<span class="err">' + esc(u.error) + "</span>"
      : !u.configured ? "Online updates aren't set up yet - USB updates still work."
      : u.msg ? esc(u.msg) : "✓ Up to date" + (u.checked ? " (checked " + new Date(u.checked * 1000).toLocaleTimeString() + ")" : "");
    $("btn-upd-install").hidden = !u.available || u.busy;
    if (u.available) $("btn-upd-install").textContent = "INSTALL v" + u.available;
    // phones (and boards with automatic updates off): a chip on the board so nobody has to dig through CFG
    var chip = $("upd-chip"), want = u.available && !u.busy && (u.phone || (state.config && state.config.auto_update === false));
    if (want && !chip) {
      chip = document.createElement("button");
      chip.type = "button"; chip.id = "upd-chip"; chip.className = "btn upd-chip";
      chip.addEventListener("click", function () {
        chip.disabled = true; chip.textContent = "⏳ INSTALLING… THE APP REOPENS BY ITSELF";
        fetch("api/update/install", { method: "POST", body: "{}" }).catch(function () {});
      });
      document.body.appendChild(chip);
    }
    if (chip) {
      chip.hidden = !want && !chip.disabled;
      if (want && !chip.disabled) chip.textContent = "⬆ UPDATE v" + u.available + " READY · TAP TO INSTALL";
    }
  }
  $("btn-upd-check").addEventListener("click", function () {
    $("upd-status").textContent = "CHECKING…";
    fetch("api/update/check", { method: "POST", body: "{}" }).then(function (r) { return r.json(); }).then(function (j) {
      if (j.update) { state.update = j.update; } renderUpdate();
    }).catch(function () { $("upd-status").textContent = "✗ NO LINK TO BOARD"; });
  });
  $("btn-upd-install").addEventListener("click", function () {
    $("upd-status").textContent = "⏳ Downloading and installing… the board restarts by itself.";
    $("btn-upd-install").hidden = true;
    fetch("api/update/install", { method: "POST", body: "{}" });
  });
  $("f-autoupd").addEventListener("change", function () {
    fetch("api/config", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ auto_update: this.checked }) });
  });

  function poll() {
    return fetch("api/state", { cache: "no-store" }).then(function (r) { return r.json(); }).then(function (s) {
      state = s;
      if (bootVersion === null) bootVersion = s.version;
      else if (s.version !== bootVersion) { location.reload(); return; }     // the board updated itself: load the new screen
      try { renderUpdate(); $("f-autoupd").checked = s.config.auto_update !== false; } catch (e) {}
      skew = s.server_time - Date.now() / 1000;
      if (Math.abs(skew) < 5) skew = 0;
      $("link-status").className = s.setup ? "link down" : "link";
      $("link-status").textContent = s.setup ? "● NO WI-FI" : "● LINK";
      render();
      try { if (meshOn() && !mesh.snap) pollMesh(); else if (mesh.snap) renderMesh(); else { $("btn-comms").hidden = !mesh.open; $("legend-mesh").hidden = true; } } catch (e) {}
      applyScreenDefaults(s.config && s.config.screen);
      try { renderDots(); } catch (e) {}
      handleEvents(s);
    }).catch(function () {
      $("link-status").className = "link down";
      $("link-status").textContent = "● NO LINK";
    });
  }
  poll();
  setInterval(poll, POLL_MS);

  // ---------- manual refresh ----------
  var syncing = false;
  function setSync(cls, label) {
    var b = $("btn-sync");
    b.className = "btn btn-sync" + (cls ? " " + cls : "");
    b.querySelector(".sync-lbl").textContent = label;
  }
  function refreshNow() {
    if (syncing) return;
    syncing = true;
    setSync("busy", "SYNCING");
    var t0 = 0, tries = 0, queued = [];
    fetch("api/refresh", { method: "POST", body: "{}" }).then(function (r) { return r.json(); }).then(function (j) {
      t0 = j.time || 0; queued = j.queued || [];
      if (!queued.length) return finish(true);          // everything was checked in the last 30 s
      check();
    }).catch(function () { finish(false, "NO LINK"); });
    function check() {
      tries++;
      poll().then(function () {
        var pending = queued.filter(function (n) { return ((state.feeds[n] || {}).attempted || 0) < t0; });
        if (!pending.length) {
          var bad = queued.filter(function (n) { return !(state.feeds[n] || {}).ok; }).length;
          return finish(!bad, bad ? bad + " ERR" : null);
        }
        if (tries >= 30) return finish(false, "SLOW");   // ~60 s max wait
        setSync("busy", "SYNCING " + (queued.length - pending.length) + "/" + queued.length);
        setTimeout(check, 2000);
      });
    }
    function finish(ok, msg) {
      syncing = false;
      setSync(ok ? "done" : "warn", msg || "UPDATED");
      setTimeout(function () { if (!syncing) setSync("", "REFRESH"); }, 4000);
    }
  }
  $("btn-sync").addEventListener("click", refreshNow);
  document.addEventListener("keydown", function (e) {
    if ((e.key === "r" || e.key === "R") && !e.ctrlKey && !e.metaKey && $("modal").hidden && document.activeElement.tagName !== "INPUT") refreshNow();
  });
  setInterval(renderAges, 10000);

  // ---------- alerts: sounds + flash banner ----------
  // Sounds are synthesized (no audio files), so they work offline. Browsers only allow
  // audio after a tap/click, so the AUDIO button "arms" it. The Pi kiosk launches
  // Chromium with autoplay allowed, so it arms itself.
  var actx = null, master = null, queue = [], playing = false;
  var volume = pref("volume", 70), voice = pref("voice", true), scope = pref("scope", "all");
  var quiet = pref("quiet", { on: true, start: "22:00", end: "07:00" });
  var lastSeq = pref("lastSeq", null), flash = [];
  if (Q.get("sound") === "1") sound = true;

  function ensureAudio() {
    if (!actx) {
      var C = window.AudioContext || window.webkitAudioContext;
      if (!C) return null;
      actx = new C();
      master = actx.createGain(); master.connect(actx.destination);
    }
    master.gain.value = Math.pow(volume / 100, 2) * 0.9;
    if (actx.state === "suspended") actx.resume();
    return actx;
  }
  function audioReady() { return actx && actx.state === "running"; }

  function tone(type, f0, f1, t0, dur, vol) {
    var o = actx.createOscillator(), g = actx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(f0, t0);
    if (f1 && f1 !== f0) o.frequency.linearRampToValueAtTime(f1, t0 + dur);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(vol || 0.3, t0 + 0.015);
    g.gain.setValueAtTime(vol || 0.3, t0 + Math.max(0.02, dur - 0.04));
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g); g.connect(master);
    o.start(t0); o.stop(t0 + dur + 0.02);
  }
  function ping(f, t0, decay, vol) {          // sonar-style ping with long tail
    var o = actx.createOscillator(), g = actx.createGain();
    o.type = "sine"; o.frequency.setValueAtTime(f, t0);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(vol || 0.35, t0 + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + decay);
    o.connect(g); g.connect(master); o.start(t0); o.stop(t0 + decay + 0.05);
  }
  function noise(t0, dur, freq, q, vol) {     // filtered static / rumble
    var n = Math.floor(actx.sampleRate * dur), buf = actx.createBuffer(1, n, actx.sampleRate), d = buf.getChannelData(0);
    for (var i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
    var src = actx.createBufferSource(), f = actx.createBiquadFilter(), g = actx.createGain();
    src.buffer = buf; f.type = "bandpass"; f.frequency.value = freq; f.Q.value = q || 1;
    g.gain.setValueAtTime(vol || 0.3, t0); g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    src.connect(f); f.connect(g); g.connect(master); src.start(t0); src.stop(t0 + dur);
  }

  // Each returns its length in seconds.
  // Soft "bell": gentle attack, smooth fade, a quiet octave on top. No harsh square/sawtooth waves.
  function bell(f, t0, dur, vol) {
    [[f, 1], [f * 2, 0.18]].forEach(function (p) {
      var o = actx.createOscillator(), g = actx.createGain();
      o.type = "sine"; o.frequency.setValueAtTime(p[0], t0);
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.exponentialRampToValueAtTime((vol || 0.2) * p[1], t0 + 0.04);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
      o.connect(g); g.connect(master); o.start(t0); o.stop(t0 + dur + 0.05);
    });
  }
  function swell(f, t0, dur, vol) {             // soft low swell (replaces the old rumble / horn)
    var o = actx.createOscillator(), g = actx.createGain();
    o.type = "triangle"; o.frequency.setValueAtTime(f, t0);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(vol || 0.12, t0 + dur * 0.4);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g); g.connect(master); o.start(t0); o.stop(t0 + dur + 0.05);
  }

  // Each returns its length in seconds. Same soft bell sounds as Crash Watch (made by code, no recordings).
  var SOUNDS = {
    klaxon: function (t) {                    // major alert / RED: two calm rising three-note calls
      for (var i = 0; i < 2; i++) { bell(523, t + i * 1.1, 0.7, 0.2); bell(659, t + i * 1.1 + 0.2, 0.7, 0.2); bell(784, t + i * 1.1 + 0.4, 0.9, 0.2); }
      swell(131, t, 2.2, 0.08);
      return 2.3;
    },
    seismic: function (t) { swell(98, t, 1.4, 0.12); bell(660, t + 0.9, 1.1, 0.18); bell(660, t + 1.5, 1.3, 0.15); return 2.8; },
    weather: function (t) { bell(659, t, 0.9, 0.17); bell(880, t + 0.22, 1.1, 0.17); return 1.3; },          // local warning (Crash Watch orange chime)
    fire: function (t) { bell(988, t, 0.8, 0.18); bell(784, t + 0.2, 0.8, 0.18); bell(659, t + 0.4, 1.2, 0.18); swell(165, t, 1.4, 0.07); return 1.6; },   // fire near you (red chime)
    bio: function (t) { bell(440, t, 0.8, 0.16); bell(330, t + 0.35, 1.2, 0.16); return 1.6; },
    space: function (t) { bell(784, t, 0.6, 0.15); bell(988, t + 0.18, 0.6, 0.15); bell(1175, t + 0.36, 0.9, 0.15); return 1.3; },
    chirp: function (t) { bell(1046, t, 0.35, 0.13); bell(1046, t + 0.2, 0.45, 0.13); return 0.7; }
  };

  function inQuiet() {
    if (!quiet.on) return false;
    var d = new Date(), m = d.getHours() * 60 + d.getMinutes();
    function mins(s) { var p = String(s || "0:0").split(":"); return (+p[0]) * 60 + (+p[1] || 0); }
    var a = mins(quiet.start), b = mins(quiet.end);
    return a <= b ? (m >= a && m < b) : (m >= a || m < b);
  }

  function say(text) {
    if (!voice || !window.speechSynthesis) return;
    try {
      var u = new SpeechSynthesisUtterance(text); u.lang = CBL.voice();
      u.rate = 0.95; u.pitch = 0.8; u.volume = Math.min(1, volume / 100);
      speechSynthesis.speak(u);
    } catch (e) {}
  }

  function playQueue() {
    if (playing || !queue.length) return;
    if (!ensureAudio() || !audioReady()) { queue = []; return; }
    playing = true;
    var ev = queue.shift(), fn = SOUNDS[ev.kind] || SOUNDS.chirp;
    var t = actx.currentTime + 0.05, len = fn(t);
    if (ev.sev >= 3) len += fn(t + len + 0.4) + 0.4;      // critical: play it twice
    setTimeout(function () {
      say(CBL.flash() + " " + CBL.t(ev.title).replace(/\bM(\d)\.(\d)/, CBL.mag()));
      setTimeout(function () { playing = false; playQueue(); }, 3500);
    }, len * 1000 + 200);
  }

  function scopeOK(ev) {           // ALERT SOUNDS FOR: all / local / global (events with no scope always sound)
    return scope === "all" || !ev.scope || ev.scope === "any" || ev.scope === scope;
  }
  function alertFor(ev, withSound) {
    flash.push(ev);
    if (flash.length > 5) flash.shift();
    renderFlash();
    if (withSound && sound && scopeOK(ev) && (ev.sev >= 3 || !inQuiet())) { queue.push(ev); playQueue(); }
  }

  function handleEvents(s) {
    var seq = s.event_seq || 0;
    if (lastSeq === null || seq < lastSeq) {         // first visit, or the server was reset: don't replay history
      lastSeq = seq; setPref("lastSeq", seq); return;
    }
    (s.events || []).forEach(function (ev) {
      if (ev.seq > lastSeq) alertFor(ev, nowS() - ev.time < 15 * 60);   // stale (board was offline): banner only
    });
    if (seq !== lastSeq) { lastSeq = seq; setPref("lastSeq", seq); }
  }

  function renderFlash() {
    var box = $("flash");
    if (!flash.length) { box.hidden = true; return; }
    var top = flash.reduce(function (m, e) { return e.sev > m ? e.sev : m; }, 0);
    box.setAttribute("data-sev", top);
    var html = "";
    flash.slice().reverse().forEach(function (e) {
      html += '<div class="fl-item"><b>' + esc(e.title) + "</b> " + '<span class="raw">' + esc(e.detail) + '</span>' + ' <span class="m">' + zulu(e.time) + "</span></div>";
    });
    $("flash-items").innerHTML = html;
    box.hidden = false;
    try { renderPromo(); } catch (e) {}
    clearTimeout(renderFlash.timer);
    if (top < 3) renderFlash.timer = setTimeout(function () { flash = []; renderFlash(); }, 5 * 60000);
  }
  $("flash-ack").addEventListener("click", function () {
    flash = []; renderFlash(); queue = [];
    try { speechSynthesis.cancel(); } catch (e) {}
  });

  function renderAudioBtn() {
    var b = $("btn-audio");
    if (!sound) { b.textContent = "AUDIO OFF"; b.className = "btn"; return; }
    if (audioReady()) { b.textContent = "AUDIO ON"; b.className = "btn armed"; }
    else { b.textContent = "TAP: ARM AUDIO"; b.className = "btn arm-me"; }
  }
  $("btn-audio").addEventListener("click", function () {
    if (sound && audioReady()) { sound = false; }
    else { sound = true; ensureAudio(); setTimeout(function () { if (audioReady()) SOUNDS.chirp(actx.currentTime + 0.05); renderAudioBtn(); }, 120); }
    setPref("sound", sound); renderAudioBtn();
  });
  // try to arm on any first tap anywhere (needed after a page reload)
  document.addEventListener("click", function once() {
    if (sound) { ensureAudio(); setTimeout(renderAudioBtn, 150); }
    document.removeEventListener("click", once, true);
  }, true);
  if (sound) { ensureAudio(); setTimeout(renderAudioBtn, 300); }   // works where autoplay is allowed (kiosk)
  renderAudioBtn();

  function testSound(kind) {
    ensureAudio();
    setTimeout(function () {
      if (!audioReady()) { $("cfg-msg").textContent = "AUDIO BLOCKED: TAP THE PAGE FIRST"; return; }
      queue.push({ kind: kind, sev: 2, title: "Test alert" }); playQueue(); renderAudioBtn();
    }, 120);
  }

  // ---------- panels: modular layout (minimize / expand), carousel and TOUCH MODE ----------
  // Every screen keeps its own layout: minimized panels go to the dock (and are skipped when cycling),
  // expanded panels take a double-size slot (and stay up twice as long when cycling).
  var panels = Array.prototype.slice.call(document.querySelectorAll(".panel"));
  var order = ["quakes", "weather", "alerts", "fire", "outbreaks", "defcon", "doomsday", "tsunami", "gdacs", "space", "news"];
  panels.sort(function (a, b) { return order.indexOf(a.dataset.key) - order.indexOf(b.dataset.key); });
  panels.forEach(function (p, i) {
    var h = p.querySelector("h2"), c = h ? h.cloneNode(true) : null;
    if (c) Array.prototype.slice.call(c.querySelectorAll("span")).forEach(function (x) { x.parentNode.removeChild(x); });
    p.dataset.label = (c && c.textContent.replace(/\s+/g, " ").trim()) || p.dataset.key.toUpperCase();
    p.style.order = i;
    if (h) h.insertAdjacentHTML("beforeend", '<span class="pctl"><button type="button" data-pact="min" title="Minimize">–</button>' +
      '<button type="button" data-pact="big" title="Make bigger">⤢</button></span>');
  });
  var layoutPref = pref("layout", {});
  if (!layoutPref || typeof layoutPref !== "object") layoutPref = {};
  // RED DOT: what each minimized panel showed when it was minimized; a different signature = something changed
  var seenSig = pref("layoutSeen", {});
  if (!seenSig || typeof seenSig !== "object") seenSig = {};
  function panelSig(key) {
    if (!state) return null;
    var d = data(key) || {}, L = function (a, f) { return (a || []).map(f).join("|"); };
    switch (key) {
      case "quakes": return L(d.events, function (e) { return e.id; });
      case "alerts": return L(d.alerts, function (a) { return a.id || a.event; });
      case "weather": return String(d.cond || "");
      case "tsunami": return L(d.events, function (e) { return e.level + e.title; });
      case "gdacs": return L(d.events, function (e) { return e.id + e.level; });
      case "space": return (d.g || 0) + "#" + L(d.alerts, function (a) { return a.head; });
      case "defcon": return String(d.level || "");
      case "news": return L(d.items, function (n) { return n.title; });
      case "outbreaks": return L(d.who, function (n) { return n.title; }) + "#" + L(d.cdc, function (n) { return n.level + n.title; });
      case "fire": return L(d.fires, function (f) { return f.id; }) + "#" + (d.nearby || 0);
      case "doomsday": return String(((state.config || {}).doomsday || {}).seconds || "");
    }
    return null;
  }
  function changedWhileHidden(key) {
    if (layoutPref[key] !== "min") return false;
    var now = panelSig(key);
    if (now === null) return false;
    if (seenSig[key] === undefined) { seenSig[key] = now; setPref("layoutSeen", seenSig); return false; }
    return seenSig[key] !== now;
  }
  function renderDots() {
    var any = false;
    panels.forEach(function (p) {
      var k = p.dataset.key, ch = changedWhileHidden(k);
      if (ch) any = true;
      var chip = document.querySelector('.dock-chip[data-k="' + k + '"]');
      if (chip) chip.classList.toggle("has-new", ch);
      var it = document.querySelector('.ppick-item[data-k="' + k + '"]');
      if (it) it.classList.toggle("has-new", ch);
    });
    $("tn-panels").classList.toggle("has-new", any);
  }
  var cycleSec = pref("cycle", null), touchPref = pref("touch", null);
  if ([0, 10, 20, 30, 60].indexOf(cycleSec) < 0) cycleSec = null;
  if (["auto", "on", "off"].indexOf(touchPref) < 0) touchPref = null;
  function cycleNow() {
    if (cycleSec !== null) return cycleSec;
    var d = Number(Q.get("dwell")) || 20;                                    // ?dwell=15 etc. snaps to the nearest choice
    return [10, 20, 30, 60].reduce(function (b, c) { return Math.abs(c - d) < Math.abs(b - d) ? c : b; }, 20);
  }
  function touchWanted() {
    var t = touchPref || "auto";
    if (Q.has("touch")) t = Q.get("touch") === "0" ? "off" : "on";
    if (t === "on") return true;
    if (t === "off") return false;
    return IS_KIOSK && !Q.has("app") && (navigator.maxTouchPoints > 0 || (window.matchMedia && matchMedia("(pointer: coarse)").matches));
  }
  function visiblePanels() {
    var v = panels.filter(function (p) { return layoutPref[p.dataset.key] !== "min"; });
    return v.length ? v : panels;
  }
  function saveLayout() {
    setPref("layout", layoutPref);
    if (IS_KIOSK) fetch("api/settings", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ screen: screenNow() }) }).catch(function () {});
  }
  function setPanel(key, mode) {
    if (mode === "min") seenSig[key] = panelSig(key) === null ? undefined : panelSig(key);
    else delete seenSig[key];
    setPref("layoutSeen", seenSig);
    if (mode) layoutPref[key] = mode; else delete layoutPref[key];
    saveLayout(); applyLayout();
  }
  function applyLayout() {
    var custom = false;
    panels.forEach(function (p) {
      var m = layoutPref[p.dataset.key];
      p.classList.toggle("p-min", m === "min");
      p.classList.toggle("p-big", m === "big");
      if (m) custom = true;
      var b = p.querySelector('[data-pact="big"]');
      if (b) { b.textContent = m === "big" ? "⤡" : "⤢"; b.title = m === "big" ? "Normal size" : "Make bigger"; }
    });
    document.body.classList.toggle("modular", custom);
    var mins = panels.filter(function (p) { return layoutPref[p.dataset.key] === "min"; });
    $("dock").hidden = !mins.length;
    $("dock-items").innerHTML = mins.map(function (p) {
      return '<button type="button" class="dock-chip" data-k="' + p.dataset.key + '" title="Show this panel again">＋ ' + esc(p.dataset.label) + '<i class="new-dot" title="Something changed"></i></button>';
    }).join("");
    if (document.body.classList.contains("carousel")) { buildPager(); show(Math.min(idx, visiblePanels().length - 1)); }
    renderPicker();
    renderDots();
  }
  $("grid").addEventListener("click", function (e) {
    var b = e.target.closest("[data-pact]");
    if (!b) return;
    e.stopPropagation();
    var key = b.closest(".panel").dataset.key, cur = layoutPref[key];
    setPanel(key, b.dataset.pact === "min" ? "min" : cur === "big" ? null : "big");
  }, true);
  $("dock").addEventListener("click", function (e) { var c = e.target.closest("[data-k]"); if (c) setPanel(c.dataset.k, null); });

  // carousel: one panel at a time (small screens, TV slideshow, touch mode)
  var idx = 0, carTimer = null, pausedUntil = 0, pausedHard = false, lastSwitch = Date.now();
  function wantCarousel() {
    if (touchWanted()) return true;
    if (Q.has("kiosk")) return Q.get("kiosk") !== "0";
    return window.innerHeight <= 520 && window.innerWidth > window.innerHeight;
  }
  function buildPager() {
    var pg = "";
    visiblePanels().forEach(function (p, j) { pg += '<i data-i="' + j + '"></i>'; });
    $("pager").innerHTML = pg;
  }
  function show(i) {
    var vis = visiblePanels();
    idx = (i + vis.length) % vis.length;
    panels.forEach(function (p) { p.classList.toggle("active", p === vis[idx]); });
    var dots = $("pager").children;
    for (var k = 0; k < dots.length; k++) dots[k].classList.toggle("on", k === idx);
    lastSwitch = Date.now();
    renderTouchNav();
  }
  function priorityPanel() {
    // jump to whatever is hot: severe local alerts
    if (!state) return -1;
    var a = data("alerts");
    if (a && a.alerts && a.alerts.some(function (x) { return x.rank >= 3; }))
      return visiblePanels().findIndex(function (p) { return p.dataset.key === "alerts"; });
    return -1;
  }
  function tick() {
    if (!document.body.classList.contains("carousel")) return;
    var sec = cycleNow(), vis = visiblePanels(), cur = vis[idx];
    renderTouchNav();
    if (!sec || pausedHard || Date.now() < pausedUntil || !$("modal").hidden || !$("ppick").hidden) return;
    var dwell = sec * 1000 * (cur && layoutPref[cur.dataset.key] === "big" ? 2 : 1);   // expanded panels stay up longer
    if (Date.now() - lastSwitch < dwell) return;
    var hot = priorityPanel();
    // when a severe local alert exists, show it every other slot
    if (hot >= 0 && idx !== hot && Math.random() < 0.5) show(hot); else show(idx + 1);
  }
  function startCarousel() {
    document.body.classList.add("carousel");
    buildPager();
    show(0);
    clearInterval(carTimer);
    carTimer = setInterval(tick, 1000);
  }
  function stopCarousel() {
    document.body.classList.remove("carousel");
    clearInterval(carTimer);
    panels.forEach(function (p) { p.classList.remove("active"); });
  }
  // TOUCH MODE: big buttons; on a big touchscreen the one-panel layout is zoomed to fill it
  function applyTouch() {
    var on = touchWanted();
    document.body.classList.toggle("touch", on);
    $("tnav").hidden = !on;
    var z = 1;
    if (on && window.innerHeight > 600) z = Math.min(2.4, Math.round(window.innerHeight / 540 * 20) / 20);
    document.documentElement.style.zoom = z === 1 ? "" : String(z);
    $("app").style.height = z === 1 ? "" : (window.innerHeight / z) + "px";     // 100vh would overflow once zoomed
  }
  function renderTouchNav() {
    if (!document.body.classList.contains("touch")) return;
    var vis = visiblePanels(), cur = vis[idx], sec = cycleNow();
    $("tn-title").textContent = cur ? cur.dataset.label : "----";
    var st = !sec ? "TAP ◀ ▶ TO CHANGE" : pausedHard ? "PAUSED" : Date.now() < pausedUntil ? "PAUSED " + Math.ceil((pausedUntil - Date.now()) / 1000) + "s" : "NEXT IN " + Math.max(0, Math.ceil((sec * 1000 * (cur && layoutPref[cur.dataset.key] === "big" ? 2 : 1) - (Date.now() - lastSwitch)) / 1000)) + "s";
    $("tn-sub").textContent = (idx + 1) + " / " + vis.length + " · " + st;
    $("tn-pause").textContent = pausedHard ? "▶ PLAY" : "❚❚ PAUSE";
    $("tn-pause").hidden = !sec;
  }
  function touched() { if (document.body.classList.contains("touch")) pausedUntil = Date.now() + 60000; }   // reading: hold this panel for a minute
  $("tn-prev").addEventListener("click", function () { touched(); show(idx - 1); });
  $("tn-next").addEventListener("click", function () { touched(); show(idx + 1); });
  $("tn-name").addEventListener("click", function () { $("ppick").hidden = false; });
  $("tn-panels").addEventListener("click", function () { $("ppick").hidden = false; });
  $("tn-pause").addEventListener("click", function () { pausedHard = !pausedHard; pausedUntil = 0; renderTouchNav(); });
  // panel picker (big show/hide buttons)
  function renderPicker() {
    $("ppick-grid").innerHTML = panels.map(function (p) {
      var m = layoutPref[p.dataset.key];
      return '<button type="button" class="ppick-item' + (m === "min" ? " off" : "") + '" data-k="' + p.dataset.key + '"><b>' + esc(p.dataset.label) +
        "</b><small>" + (m === "min" ? "HIDDEN" : m === "big" ? "SHOWN · BIG" : "SHOWN") + '</small><i class="new-dot"></i></button>';
    }).join("");
  }
  $("ppick-grid").addEventListener("click", function (e) {
    var b = e.target.closest("[data-k]");
    if (!b) return;
    var k = b.dataset.k;
    if (layoutPref[k] !== "min" && visiblePanels().length <= 1) return;          // keep at least one panel
    setPanel(k, layoutPref[k] === "min" ? null : "min");
  });
  $("ppick-all").addEventListener("click", function () { layoutPref = {}; seenSig = {}; setPref("layoutSeen", seenSig); saveLayout(); applyLayout(); });
  $("ppick-done").addEventListener("click", function () { $("ppick").hidden = true; touched(); });
  $("btn-layout-reset").addEventListener("click", function () { layoutPref = {}; seenSig = {}; setPref("layoutSeen", seenSig); saveLayout(); applyLayout(); this.textContent = "✓ ALL PANELS SHOWN"; });

  function layout() {
    applyTouch();
    if (wantCarousel()) { if (!document.body.classList.contains("carousel")) startCarousel(); } else stopCarousel();
    renderTouchNav();
  }
  $("pager").addEventListener("click", function (e) { var i = e.target.getAttribute("data-i"); if (i != null) { touched(); show(+i); } });
  document.addEventListener("keydown", function (e) {
    if (!document.body.classList.contains("carousel") || !$("modal").hidden || mesh.open) return;
    if (e.key === "ArrowRight" || e.key === " ") show(idx + 1);
    if (e.key === "ArrowLeft") show(idx - 1);
  });
  // tap left/right edge of panel area to page (touchscreens)
  $("grid").addEventListener("click", function (e) {
    if (!document.body.classList.contains("carousel") || e.target.closest("a,summary,details,button,input,select")) return;
    var r = this.getBoundingClientRect();
    touched();
    show(e.clientX < r.left + r.width / 3 ? idx - 1 : idx + 1);
  });
  window.addEventListener("resize", layout);
  applyLayout();
  layout();

  // ---------- settings ----------
  function openCfg() {
    var c = (state && state.config) || {};
    $("f-location").value = (c.location && c.location.query) || "";
    var cs = $("f-country"), list = (state && state.countries) || [];
    if (cs.options.length < 2) list.forEach(function (x) { var o = document.createElement("option"); o.value = x[0]; o.textContent = x[1].toUpperCase(); cs.appendChild(o); });
    cs.value = (c.location && (c.location.cc_pref || (c.location.country && c.location.query ? "AUTO" : ""))) || "AUTO";
    if (!cs.value) cs.value = "AUTO";
    $("f-bom").checked = !!c.au_bom;
    $("f-bom-row").hidden = !(c.location && c.location.country === "AU") && cs.value !== "AU";
    $("f-units").value = c.units || "imperial";
    $("f-mag").value = c.quake_min_mag || 6;
    $("f-dcmode").value = (c.defcon && c.defcon.mode) || "auto";
    $("f-dcman").value = (c.defcon && c.defcon.manual_level) || 5;
    $("f-doom").value = (c.doomsday && c.doomsday.seconds) || 85;
    $("f-doomset").value = (c.doomsday && c.doomsday.set) || "";
    $("f-call").value = c.callsign || "";
    $("f-theme").value = c.theme || "ops";
    var fl = $("f-lang");
    if (fl.options.length < 2) CBL.langs().forEach(function (l) { var o = document.createElement("option"); o.value = l; o.textContent = CBL.name(l); fl.appendChild(o); });
    fl.value = c.lang || "en";
    renderLicenseCfg(); $("lic-msg").textContent = "";
    var ad = (state && state.address) || {};
    $("addr-url").textContent = ad.ip ? ad.ip + ":" + ad.port : (location.hostname && location.hostname !== "localhost" && location.hostname !== "127.0.0.1" ? location.host : "NOT ON A NETWORK");
    $("f-kw").value = (c.news_keywords || []).join(", ");
    $("f-sound").checked = !!sound;
    $("f-voice").checked = !!voice;
    $("f-scope").value = scope;
    $("cfg-mesh").hidden = Q.has("app");                    // the phone app has no radio link
    var mc = c.mesh || {};
    $("f-mmode").value = mc.mode || "auto"; $("f-maddr").value = mc.address || "";
    $("f-menabled").checked = mc.enabled !== false; $("f-mbcast").checked = mc.broadcast_alerts !== false;
    $("f-mrelay").checked = mc.relay_inbound !== false; $("f-msev").value = String(mc.alert_min_sev || 2);
    var chs = (mesh.snap && mesh.snap.channels && mesh.snap.channels.length) ? mesh.snap.channels : [{ index: 0, name: "PRIMARY" }];
    $("f-mch").innerHTML = chs.map(function (ch) { return '<option value="' + ch.index + '">' + esc(ch.name) + " (" + ch.index + ")</option>"; }).join("");
    $("f-mch").value = String(mc.alert_channel || 0);
    $("f-touch").value = touchPref || "auto";
    $("f-cycle").value = String(cycleNow());
    $("btn-layout-reset").textContent = "SHOW ALL PANELS (RESET LAYOUT)";
    $("f-vol").value = volume;
    $("f-quiet").checked = !!quiet.on;
    $("f-qs").value = quiet.start; $("f-qe").value = quiet.end;
    $("f-amag").value = c.alert_quake_mag || 7;
    $("f-flist").value = c.fire_list_mi || 100; $("f-falert").value = c.fire_alert_mi || 15;
    $("f-fx").value = fx;
    $("cfg-msg").textContent = c.location && c.location.name ? "CURRENT FIX: " + c.location.name + " (" + Number(c.location.lat).toFixed(3) + ", " + Number(c.location.lon).toFixed(3) + ")" : "";
    $("modal").hidden = false;
  }
  $("btn-settings").addEventListener("click", openCfg);

  // ---------- Wi-Fi (SD-card image only: the Pi's setup helper does the switching)
  var wifiNets = [], wifiTimer = null;
  function wifiJSON(url, opts) {
    return fetch(url, opts || { cache: "no-store" }).then(function (r) { return r.json().then(function (j) { return { ok: r.ok, j: j }; }); });
  }
  function wifiRefresh() {
    $("wifi-box").hidden = true;
    wifiJSON("api/wifi/status").then(function (res) {
      if (!res.ok || !res.j.crashboard_setup) return;
      $("wifi-box").hidden = false;
      var c = res.j.current || {};
      $("wifi-cur").textContent = c.ssid ? "CONNECTED: " + c.ssid : "NOT CONNECTED";
    }).catch(function () {});
  }
  $("wifi-scan").addEventListener("click", function () {
    $("wifi-msg").textContent = "SCANNING…";
    wifiJSON("api/wifi/scan").then(function (res) {
      if (!res.ok) { $("wifi-msg").textContent = "✗ " + (res.j.error || "scan failed"); return; }
      wifiNets = res.j.networks || [];
      var sel = $("f-wifi"), cur = (res.j.current || {}).ssid;
      sel.innerHTML = "";
      wifiNets.forEach(function (n, i) {
        var o = document.createElement("option");
        o.value = String(i); o.className = "raw";
        o.textContent = n.ssid + "  ·  " + n.signal + "%" + (n.secure ? " 🔒" : "") + (n.ssid === cur ? "  ✓" : "");
        sel.appendChild(o);
      });
      var other = document.createElement("option"); other.value = "other"; other.textContent = "OTHER / HIDDEN NETWORK…"; sel.appendChild(other);
      $("wifi-other-row").hidden = sel.value !== "other";
      $("wifi-msg").textContent = wifiNets.length ? "" : "NO NETWORKS FOUND";
    }).catch(function () { $("wifi-msg").textContent = "✗ NO LINK TO BOARD"; });
  });
  $("f-wifi").addEventListener("change", function () { $("wifi-other-row").hidden = this.value !== "other"; });
  $("wifi-go").addEventListener("click", function () {
    var v = $("f-wifi").value, other = v === "other";
    var ssid = other ? $("f-wifi-ssid").value.trim() : (wifiNets[+v] || {}).ssid;
    if (!ssid) { $("wifi-msg").textContent = "Pick your Wi-Fi network."; return; }
    $("wifi-msg").textContent = "CONNECTING TO " + ssid.toUpperCase() + "… THIS DEVICE MAY LOSE CONTACT WITH THE BOARD FOR A MINUTE.";
    wifiJSON("api/wifi/connect", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ssid: ssid, password: $("f-wifi-pass").value, hidden: other }) })
      .then(function (res) {
        if (!res.ok) { $("wifi-msg").textContent = "✗ " + (res.j.error || "failed"); return; }
        var tries = 0;
        clearInterval(wifiTimer);
        wifiTimer = setInterval(function () {
          if (++tries > 40) { clearInterval(wifiTimer); return; }
          wifiJSON("api/wifi/status").then(function (s) {
            if (s.j.state === "ok") { clearInterval(wifiTimer); $("wifi-msg").textContent = "✓ CONNECTED TO " + ssid.toUpperCase(); $("f-wifi-pass").value = ""; wifiRefresh(); $("wifi-box").hidden = false; }
            else if (s.j.state === "failed") { clearInterval(wifiTimer); $("wifi-msg").textContent = "✗ " + s.j.error; }
          }).catch(function () {});
        }, 3000);
      }).catch(function () { $("wifi-msg").textContent = "✗ NO LINK TO BOARD"; });
  });
  $("btn-settings").addEventListener("click", wifiRefresh);
  $("f-country").addEventListener("change", function () {
    $("f-bom-row").hidden = this.value !== "AU";
    var ph = { US: "80202 · Denver, CO", CA: "M5V · Toronto", GB: "SW1A 1AA · Brighton", AU: "2000 · Sydney", NZ: "6011 · Wellington" };
    $("f-location").placeholder = "e.g. " + (ph[this.value] || "a city or town · lat, lon");
  });
  $("f-theme").addEventListener("change", function () { applyTheme(this.value); });
  $("btn-cancel").addEventListener("click", function () { if (state) applyTheme(state.config.theme); });
  var tb = document.querySelectorAll("[data-test]");
  for (var ti = 0; ti < tb.length; ti++) tb[ti].addEventListener("click", function () { testSound(this.getAttribute("data-test")); });
  $("btn-cancel").addEventListener("click", function () { $("modal").hidden = true; });
  $("btn-refresh").addEventListener("click", function () { $("modal").hidden = true; refreshNow(); });
  if (false) $("btn-refresh").addEventListener("click", function () {
    fetch("api/refresh", { method: "POST", body: "{}" }).then(function () { $("cfg-msg").textContent = "REFRESH QUEUED"; setTimeout(poll, 4000); });
  });
  $("cfg-form").addEventListener("submit", function (e) {
    e.preventDefault();
    sound = $("f-sound").checked; setPref("sound", sound);
    voice = $("f-voice").checked; setPref("voice", voice);
    scope = $("f-scope").value || "all"; setPref("scope", scope);
    touchPref = $("f-touch").value; setPref("touch", touchPref);
    cycleSec = parseInt($("f-cycle").value, 10) || 0; setPref("cycle", cycleSec);
    layout();
    volume = +$("f-vol").value; setPref("volume", volume); if (actx) ensureAudio();
    quiet = { on: $("f-quiet").checked, start: $("f-qs").value || "22:00", end: $("f-qe").value || "07:00" }; setPref("quiet", quiet);
    if (sound) ensureAudio();
    renderAudioBtn();
    fx = $("f-fx").value; setPref("fx", fx); lite = fx === "off";
    document.body.classList.toggle("lite", lite); document.body.classList.toggle("fx-low", fx === "low");
    $("ticker").textContent = ""; try { renderTicker(); } catch (e) {}
    var body = {
      location: $("f-location").value.trim(), country: $("f-country").value, au_bom: $("f-bom").checked, units: $("f-units").value, quake_min_mag: parseFloat($("f-mag").value),
      defcon_mode: $("f-dcmode").value, defcon_manual: parseInt($("f-dcman").value, 10),
      doomsday_seconds: parseInt($("f-doom").value, 10), doomsday_set: $("f-doomset").value.trim(),
      callsign: $("f-call").value.trim(), news_keywords: $("f-kw").value,
      alert_quake_mag: parseFloat($("f-amag").value),
      fire_list_mi: parseInt($("f-flist").value, 10) || 100, fire_alert_mi: parseInt($("f-falert").value, 10) || 15, theme: $("f-theme").value, lang: $("f-lang").value,
      mesh: { mode: $("f-mmode").value, address: $("f-maddr").value.trim(), enabled: $("f-menabled").checked,
              broadcast_alerts: $("f-mbcast").checked, relay_inbound: $("f-mrelay").checked,
              alert_min_sev: +$("f-msev").value, alert_channel: +$("f-mch").value }
    };
    if (IS_KIOSK) body.screen = screenNow();
    $("cfg-msg").textContent = "TRANSMITTING…";
    fetch("api/settings", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) })
      .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, j: j }; }); })
      .then(function (res) {
        if (!res.ok) { $("cfg-msg").textContent = "ERROR: " + (res.j.error || "save failed"); return; }
        $("modal").hidden = true;
        setTimeout(poll, 300); setTimeout(poll, 5000);
      }).catch(function () { $("cfg-msg").textContent = "ERROR: NO LINK TO BOARD"; });
  });

  // ======================= FREE / PRO =======================
  var promos = null, promoIdx = 0, promoTimer = null;
  function isPro() { return !!(state && state.license && state.license.tier === "pro"); }
  function storeLink(u) {
    if (!promos) return "#";
    if (u === "PRO") return promos.pro_url || promos.store_url || "#";
    if (u && u.charAt(0) === "/") return (promos.store_url || "").replace(/\/$/, "") + u;
    return u || promos.store_url || "#";
  }
  function loadPromos() {
    fetch("promos.json", { cache: "no-cache" }).then(function (r) { return r.json(); }).then(function (j) {
      promos = j; $("promo-label").textContent = j.label || "SUPPORTED BY LL3D";
      clearInterval(promoTimer);
      promoTimer = setInterval(function () { promoIdx++; renderPromo(); }, Math.max(8, j.rotate_seconds || 20) * 1000);
      renderPromo();
    }).catch(function () {});
  }
  function renderPromo() {
    var el = $("promo");
    var list = (promos && promos.promos) || [];
    // never on PRO, never while something serious is happening, never on a display screen
    var busy = state && (state.condition.level >= 2 || !$("flash").hidden);
    var show = state && !isPro() && list.length && !busy && !document.body.classList.contains("display");
    el.hidden = !show;
    if (!show) return;
    var pr = list[promoIdx % list.length];
    var t = $("promo-text"); t.textContent = pr["text_" + CBL.lang()] || pr.text; t.classList.add("raw"); t.href = storeLink(pr.url);
    $("promo-cta").href = storeLink(pr.url);
    $("promo-cta").textContent = document.body.classList.contains("carousel") ? (promos.short || "SHOP") + " ›" : "SHOP ›";
  }
  $("promo-pro").addEventListener("click", function () { openCfg(); setTimeout(function () { $("f-key").focus(); }, 50); });

  function renderLicense() {
    if (!state) return;
    var L = state.license || { tier: "free" }, pro = L.tier === "pro";
    $("ver").innerHTML = "v" + esc(state.version) + (pro ? '<span class="pro-tag">PRO</span>' : "");
    // Wi-Fi display on a FREE host -> lock screen
    var lock = document.body.classList.contains("display") && !pro;
    $("prolock").hidden = !lock;
    if (lock && promos) $("prolock-url").textContent = "Get PRO: " + storeLink("PRO");
    renderPromo();
  }

  function renderLicenseCfg() {
    var L = (state && state.license) || { tier: "free" }, pro = L.tier === "pro";
    var feats = L.features || {}, fl = Object.keys(feats).map(function (k) { return "<li>" + esc(feats[k]) + "</li>"; }).join("");
    $("lic-tier-small").textContent = pro ? "PRO" : "FREE";
    $("lic-status").innerHTML = L.banned
      ? '<span class="err">✗ PRO KEY CANCELLED</span><br>' + esc(L.banned_msg || "") +
        '<br><span class="fine">Order ' + esc(L.order || "?") + " · key " + esc(L.key || "") + "</span>"
      : L.pending
      ? '<span class="warn">⏳ WAITING TO ACTIVATE</span>' + (L.name ? " · licensed to <b>" + esc(L.name) + "</b>" : "") +
        "<br>" + esc(L.act_msg || "This board needs the internet once to activate its PRO key.") +
        (pro && L.grace_until ? '<br><span class="fine">PRO stays on until ' + esc(new Date(L.grace_until * 1000).toISOString().slice(0, 10)) + " while it activates.</span>" : "") +
        '<br><span class="fine">Key ' + esc(L.key || "") + "</span>"
      : pro
      ? '<span class="pro">✓ CRASH BOARD™ PRO</span>' + (L.name ? " · licensed to <b>" + esc(L.name) + "</b>" : "") +
        (L.limit && L.board ? " · board <b>" + esc(L.board) + "</b> of " + esc(L.max_boards || 3) : "") +
        " · order <b>" + esc(L.order || "?") + "</b> · since " + esc(L.issued || "?") +
        (L.expires ? " · renews by " + esc(new Date(L.expires * 1000).toISOString().slice(0, 10)) : " · lifetime") +
        '<br><span class="fine">Key ' + esc(L.key || "") + "</span>"
      : "You're on <b>FREE</b>. Every alert and data panel is included. PRO adds:<ul>" + fl + "</ul>" +
        (promos ? '<a href="' + esc(storeLink("PRO")) + '" target="_blank" rel="noopener" class="fine">Get a PRO key › ' + esc(storeLink("PRO")) + "</a>" : "");
    $("lic-enter").hidden = pro || !!L.banned || !!L.pending; $("lic-have").hidden = !pro && !L.banned && !L.pending;
    $("btn-release").hidden = !L.limit || !!L.pending || !!L.banned;
    $("btn-unkey").textContent = L.limit && !L.pending && !L.banned ? "REMOVE WITHOUT RELEASING" : "REMOVE KEY FROM THIS BOARD";
    // lock PRO color schemes on FREE
    var free = L.free_themes || ["ops", "blackout"], opts = $("f-theme").options;
    for (var i = 0; i < opts.length; i++) {
      var locked = !pro && free.indexOf(opts[i].value) < 0;
      opts[i].disabled = locked;
      opts[i].textContent = opts[i].textContent.replace(/ · PRO$/, "") + (locked ? " · PRO" : "");
    }
  }
  function licPost(path, body) {
    $("lic-msg").className = "fine"; $("lic-msg").textContent = "CHECKING…";
    return fetch(path, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body || {}) })
      .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, j: j }; }); })
      .then(function (res) {
        if (!res.ok) { $("lic-msg").className = "fine err"; $("lic-msg").textContent = "✗ " + (res.j.error || "failed"); return; }
        state.license = res.j.license; renderLicenseCfg(); renderLicense();
        var NL = res.j.license;
        $("lic-msg").className = "fine ok";
        $("lic-msg").textContent = NL.pending ? (NL.act_msg || "Key saved - waiting to activate.")
          : NL.tier === "pro" ? "✓ PRO UNLOCKED" + (NL.limit && NL.board ? " (board " + NL.board + " of " + (NL.max_boards || 3) + ")" : "") + ". Thank you for supporting LL3D!"
          : /release/.test(path) ? "Board released - its slot is free for another board. This board is FREE."
          : "Key removed. This board is FREE.";
        $("f-key").value = ""; poll();
      }).catch(function () { $("lic-msg").className = "fine err"; $("lic-msg").textContent = "✗ NO LINK TO BOARD"; });
  }
  $("btn-key").addEventListener("click", function () { var k = $("f-key").value.trim(); if (k) licPost("api/license", { key: k }); });
  $("f-key").addEventListener("keydown", function (e) { if (e.key === "Enter") { e.preventDefault(); $("btn-key").click(); } });
  $("btn-unkey").addEventListener("click", function () { licPost("api/license/remove"); });
  $("btn-release").addEventListener("click", function () {
    if (window.confirm("Release this board? PRO turns off here and the slot becomes free for another board.")) licPost("api/license/release");
  });
  loadPromos(); setInterval(loadPromos, 3600000);

  // ---------- for the first-time setup (setup.js) ----------
  // ======================= MESH COMMS =======================
  var mesh = { seq: 0, msgs: [], snap: null, open: false, tab: "chat" };
  var meshRead = pref("meshRead", 0), meshTimer = null, firstMeshLoad = true;
  var STATUS_TXT = { connected: "● ONLINE", connecting: "CONNECTING…", error: "● OFFLINE", no_library: "LIBRARY MISSING", disabled: "LINK OFF" };

  function pollMesh() {
    return fetch("api/mesh?since=" + mesh.seq, { cache: "no-store" }).then(function (r) { return r.json(); }).then(function (d) {
      if (d.seq < mesh.seq) { mesh.seq = 0; mesh.msgs = []; return pollMesh(); }   // server log was reset
      mesh.snap = d;
      var fresh = (d.messages || []).filter(function (m) { return m.seq > mesh.seq; });
      mesh.msgs = mesh.msgs.concat(fresh).slice(-200);
      mesh.seq = d.seq || mesh.seq;
      if (firstMeshLoad) { firstMeshLoad = false; if (!meshRead) { meshRead = mesh.seq; setPref("meshRead", meshRead); } }
      else if (fresh.some(function (m) { return m.dir === "in"; }) && !(mesh.open && mesh.tab === "chat")) meshPing();
      renderMesh();
    }).catch(function () {});
  }
  function meshOn() { return !Q.has("app") && !!(state && state.config && state.config.mesh && state.config.mesh.enabled); }   // the phone app has no radio
  function scheduleMesh() { clearInterval(meshTimer); meshTimer = setInterval(function () { if (meshOn() || mesh.open) pollMesh(); }, mesh.open ? 4000 : 12000); }

  function meshPing() {        // soft radio chirp for new incoming traffic
    try { if (sound && audioReady() && !inQuiet()) SOUNDS.chirp(actx.currentTime + 0.05); } catch (e) {}
  }

  function unread() { return mesh.msgs.filter(function (m) { return m.dir === "in" && m.seq > meshRead; }).length; }
  function markRead() { if (mesh.open && mesh.tab === "chat" && mesh.seq > meshRead) { meshRead = mesh.seq; setPref("meshRead", meshRead); } }

  function nodeName(id) {
    var n = ((mesh.snap && mesh.snap.nodes) || []).filter(function (x) { return x.id === id; })[0];
    return n ? n.short : id;
  }
  function battHtml(b) {
    if (b == null) return "";
    if (b > 100) return '<span class="lbl">PWR</span> ';                           // >100 = on external power
    return '<span class="batt' + (b < 20 ? " low" : "") + '"><i style="width:' + Math.max(1, Math.round(b * 0.19)) + 'px"></i></span>' + b + "% ";
  }

  function renderMesh() {
    var d = mesh.snap; if (!d) return;
    var on = meshOn();
    $("btn-comms").hidden = !on && !mesh.open;              // COMMS shows once a Meshtastic radio is turned on
    $("legend-mesh").hidden = !on;
    var st = d.status || "disabled";
    var el = $("mesh-status");
    el.textContent = STATUS_TXT[st] || st.toUpperCase();
    el.className = "mesh-status " + (st === "connected" ? "ok" : st === "connecting" ? "wait" : "bad");
    $("btn-comms").classList.toggle("live", st === "connected");
    var u = unread(), badge = $("comms-badge");
    badge.hidden = !u || (mesh.open && mesh.tab === "chat"); badge.textContent = u > 99 ? "99+" : u;

    // who am I / problems
    var me = d.me || {}, info = "";
    if (st === "connected") info = "<b>" + esc(me.long || me.id || "RADIO") + "</b> (" + esc(me.short || "?") + ") · " + esc(me.id || "") + (me.hw ? " · " + esc(me.hw) : "") + " · " + (d.nodes || []).length + " NODES";
    else if (st === "no_library") info = '<span class="err">The Meshtastic library isn\'t installed.</span><pre>Pi:      pip install --break-system-packages meshtastic\nWindows: py -m pip install meshtastic\nThen restart Crash Board.</pre>';
    else if (st === "disabled") info = "Radio link is off. Turn it on in CFG → MESHTASTIC RADIO.";
    else if (st === "error") info = '<span class="err">' + esc(d.error || "Can't reach the radio.") + "</span> Retrying every 30 s.";
    else info = "Looking for your radio…";
    $("comms-me").innerHTML = info;

    // channels + recipients
    var chSel = $("msg-ch"), cur = chSel.value;
    var chs = (d.channels && d.channels.length) ? d.channels : [{ index: 0, name: "PRIMARY" }];
    var opts = chs.map(function (c) { return '<option value="' + c.index + '">' + esc(c.name) + "</option>"; }).join("");
    if (chSel.getAttribute("data-o") !== opts) { chSel.innerHTML = opts; chSel.setAttribute("data-o", opts); chSel.value = cur || "0"; }
    var toSel = $("msg-to"), curTo = toSel.value;
    var peers = (d.nodes || []).filter(function (n) { return !n.me; });
    var to = '<option value="^all">CHANNEL (ALL)</option>' + peers.map(function (n) { return '<option value="' + esc(n.id) + '">DM: ' + esc(n.short + " · " + n.long) + "</option>"; }).join("");
    if (toSel.getAttribute("data-o") !== to) { toSel.innerHTML = to; toSel.setAttribute("data-o", to); toSel.value = curTo || "^all"; if (!toSel.value) toSel.value = "^all"; }
    var locked = !isPro();                      // FREE: read the mesh + receive alerts; sending is PRO
    $("msg-send").disabled = st !== "connected" || locked;
    $("msg-text").disabled = locked;
    $("msg-text").placeholder = locked ? "Sending is a PRO feature: CFG → LICENSE" : "Type a message…";
    var qb = document.querySelectorAll("[data-quick]");
    for (var qi = 0; qi < qb.length; qi++) qb[qi].disabled = locked;

    // chat
    var list = $("chat-list"), atBottom = list.scrollHeight - list.scrollTop - list.clientHeight < 40;
    var chName = {}; chs.forEach(function (c) { chName[c.index] = c.name; });
    var html = mesh.msgs.map(function (m) {
      var cb = m.text.indexOf("[CB]") === 0, cls = "msg " + m.dir + (m.dm ? " dm" : "") + (cb ? " cb" : "");
      var who = m.dir === "out" ? "YOU" : '<button type="button" data-dm="' + esc(m.from) + '" title="Reply directly">' + esc(m.from_name || m.from) + "</button>";
      var where = m.dm ? (m.dir === "out" ? "DM → " + esc(nodeName(m.to)) : "DM") : esc(chName[m.channel] || "CH" + m.channel);
      var meta = zulu(m.time) + " · " + ago(m.time) + " AGO" + (m.snr != null ? " · SNR " + m.snr : "") + (m.hops != null ? " · " + m.hops + " HOP" + (m.hops === 1 ? "" : "S") : "");
      return '<li class="' + cls + '"><div class="who">' + who + "<span>" + where + "</span>" + (cb ? "<span>ALERT</span>" : "") + '</div><div class="txt">' + esc(m.text) + '</div><div class="meta">' + meta + "</div></li>";
    }).join("");
    list.innerHTML = html || '<li class="empty">NO TRAFFIC YET</li>';
    if (atBottom || firstRenderChat) { list.scrollTop = list.scrollHeight; firstRenderChat = false; }

    // nodes
    var nh = (d.nodes || []).map(function (n) {
      var heard = n.last ? ago(n.last) + " AGO" : "NEVER";
      var bits = [heard];
      if (n.snr != null) bits.push("SNR " + n.snr);
      if (n.hops != null) bits.push(n.hops === 0 ? "DIRECT" : n.hops + " HOP" + (n.hops === 1 ? "" : "S"));
      if (n.km != null) bits.push(n.km < 1 ? "<1 KM" : n.km + " KM");
      if (n.hw) bits.push(esc(n.hw));
      var fresh = n.last && nowS() - n.last < 3600;
      return li(fresh ? "l1" : "", (n.me ? "" : '<button type="button" class="btn dmbtn" data-dm="' + esc(n.id) + '">DM</button>') +
        '<div class="t"><b>' + esc(n.short) + "</b>" + esc(n.long) + (n.me ? '<span class="me-tag">THIS RADIO</span>' : "") + '</div><div class="m">' + battHtml(n.battery) + bits.join(" · ") + "</div>");
    }).join("");
    $("node-list").innerHTML = nh || li("empty", st === "connected" ? "NO OTHER NODES HEARD YET" : "CONNECT A RADIO TO SEE NODES");
    $("node-count").textContent = (d.nodes || []).length ? "(" + d.nodes.length + ")" : "";

    // map
    var dots = "";
    (d.nodes || []).forEach(function (n) {
      if (n.lat == null || (n.lat === 0 && n.lon === 0)) return;
      var p = proj(n.lat, n.lon);
      dots += '<path class="mnode' + (n.me ? " me" : "") + '" d="M' + p[0].toFixed(2) + " " + (p[1] - 2.2).toFixed(2) + "l2.2 2.2-2.2 2.2-2.2-2.2z\"><title>" + esc(n.short + " · " + n.long) + "</title></path>";
    });
    $("map-mesh").innerHTML = dots;
    markRead();
  }
  var firstRenderChat = true;

  function openComms(tab) {
    mesh.open = true; $("comms").hidden = false;
    if (tab) setTab(tab);
    firstRenderChat = true; renderMesh(); scheduleMesh(); pollMesh();
  }
  function closeComms() { mesh.open = false; $("comms").hidden = true; scheduleMesh(); renderMesh(); }
  function setTab(t) {
    mesh.tab = t;
    var tabs = document.querySelectorAll(".tab");
    for (var i = 0; i < tabs.length; i++) tabs[i].classList.toggle("on", tabs[i].getAttribute("data-tab") === t);
    $("tab-chat").hidden = t !== "chat"; $("tab-nodes").hidden = t !== "nodes";
    if (t === "chat") { firstRenderChat = true; renderMesh(); }
  }
  $("btn-comms").addEventListener("click", function () { mesh.open ? closeComms() : openComms(); });
  $("comms-close").addEventListener("click", closeComms);
  document.querySelector(".tabs").addEventListener("click", function (e) { var t = e.target.getAttribute("data-tab"); if (t) setTab(t); });
  $("comms").addEventListener("click", function (e) {
    var b = e.target.closest("[data-dm]"); if (!b) return;
    $("msg-to").value = b.getAttribute("data-dm"); if (!$("msg-to").value) $("msg-to").value = "^all";
    setTab("chat"); $("msg-text").focus();
  });
  document.addEventListener("keydown", function (e) { if (e.key === "Escape" && mesh.open) closeComms(); });

  function byteLen(t) { try { return new TextEncoder().encode(t).length; } catch (e) { return t.length; } }
  $("msg-text").addEventListener("input", function () {
    var n = byteLen(this.value), max = (mesh.snap && mesh.snap.max_bytes) || 200;
    $("msg-bytes").textContent = n + "/" + max; $("msg-bytes").classList.toggle("full", n > max);
  });
  function sendMesh(text, to, ch) {
    $("msg-err").textContent = "";
    return fetch("api/mesh/send", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text: text, to: to || "^all", channel: +(ch || 0) }) })
      .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, j: j }; }); })
      .then(function (res) {
        if (!res.ok) { $("msg-err").textContent = "NOT SENT: " + (res.j.error || "error"); return false; }
        pollMesh(); return true;
      }).catch(function () { $("msg-err").textContent = "NOT SENT: NO LINK TO BOARD"; return false; });
  }
  $("composer").addEventListener("submit", function (e) {
    e.preventDefault();
    var t = $("msg-text").value.trim(); if (!t) return;
    var max = (mesh.snap && mesh.snap.max_bytes) || 200;
    if (byteLen(t) > max) { $("msg-err").textContent = "TOO LONG FOR ONE MESH PACKET (" + max + " BYTES MAX)"; return; }
    sendMesh(t, $("msg-to").value, $("msg-ch").value).then(function (ok) { if (ok) { $("msg-text").value = ""; $("msg-bytes").textContent = "0/" + max; } });
  });
  var QUICK = {
    ok: function () { return "✓ SAFE · " + ((state && state.config.callsign) || "CRASH BOARD") + " checking in"; },
    help: function () {
      var l = (state && state.config.location) || {};
      return "⚠ NEED HELP" + (l.lat != null ? " · near " + (l.name || "") + " " + Number(l.lat).toFixed(4) + "," + Number(l.lon).toFixed(4) : "");
    },
    cond: function () {
      if (!state) return "";
      var c = state.condition;
      return "STATUS: CONDITION " + c.name + (c.reasons[0] ? " - " + c.reasons[0] : " - no significant threats");
    },
    loc: function () {
      var l = (state && state.config.location) || {};
      return l.lat == null ? "" : "LOC " + Number(l.lat).toFixed(4) + "," + Number(l.lon).toFixed(4) + (l.name ? " (" + l.name + ")" : "");
    }
  };
  document.querySelector(".quick").addEventListener("click", function (e) {
    var k = e.target.getAttribute("data-quick"); if (!k) return;
    var t = QUICK[k]();
    if (!t) { $("msg-err").textContent = "SET A LOCATION IN CFG FIRST"; return; }
    var max = (mesh.snap && mesh.snap.max_bytes) || 200;
    while (byteLen(t) > max) t = t.slice(0, -1);
    sendMesh(t, $("msg-to").value, $("msg-ch").value);
  });
  scheduleMesh();

  window.CB = {
    // phone BACK button (Android app): close whatever is open on top. Returns true if something was closed.
    back: function () {
      if (window.CBSetup && CBSetup.isOpen && CBSetup.isOpen()) { CBSetup.later(); return true; }
      if (mesh.open) { closeComms(); return true; }
      var m = $("modal");
      if (m && !m.hidden) { m.hidden = true; return true; }
      var open = document.querySelectorAll(".modal:not([hidden]), .overlay:not([hidden])");
      for (var i = 0; i < open.length; i++) { if (open[i].offsetParent !== null || getComputedStyle(open[i]).position === "fixed") { open[i].hidden = true; return true; } }
      return false;
    },
    state: function () { return state; },
    poll: poll,
    applyTheme: applyTheme,
    setLang: function (l) { CBL.set(l); },
    testSound: function (kind) {
      sound = true; ensureAudio(); renderAudioBtn();
      setTimeout(function () { if (audioReady()) { queue.push({ kind: kind || "seismic", sev: 2, title: "Test alert" }); playQueue(); } renderAudioBtn(); }, 150);
      return audioReady();
    },
    screen: screenNow,
    setScreen: function (o) {
      if ("sound" in o) { sound = !!o.sound; setPref("sound", sound); }
      if ("voice" in o) { voice = !!o.voice; setPref("voice", voice); }
      if (["all", "local", "global"].indexOf(o.alerts) >= 0) { scope = o.alerts; setPref("scope", scope); }
      if ("volume" in o) { volume = +o.volume; setPref("volume", volume); if (actx) ensureAudio(); }
      if (o.quiet) { quiet = o.quiet; setPref("quiet", quiet); }
      if (o.fx) { fx = o.fx; setPref("fx", fx); lite = fx === "off";
        document.body.classList.toggle("lite", lite); document.body.classList.toggle("fx-low", fx === "low"); }
      if (sound) ensureAudio();
      renderAudioBtn();
    },
    mesh: !!document.getElementById("btn-comms") && !Q.has("app"),      // the phone app has no radio link
    openCfg: openCfg
  };
  if (window.CBSetup) window.CBSetup.start();
})();

/* ---------- header auto-fit: shrink the top bar step by step until nothing overlaps ---------- */
(function () {
  var bar = document.querySelector(".topbar");
  if (!bar) return;
  var MAX = 7, busy = false;
  function box(sel) {
    var e = bar.querySelector(sel);
    if (!e || !e.offsetParent) return null;
    var r = e.getBoundingClientRect();
    return r.width ? r : null;
  }
  function hit(a, b) {
    return a && b && a.left < b.right + 12 && b.left < a.right + 12 && a.top < b.bottom && b.top < a.bottom;
  }
  function bad() {
    var c = box(".clocks"), n = box(".callsign"), a = box(".top-actions"), t = bar.getBoundingClientRect();
    if (hit(c, n) || hit(n, a) || hit(c, a)) return true;
    if (a && a.right > t.right + 1) return true;
    if (n && (n.left < t.left - 1 || n.right > t.right + 1)) return true;
    return document.documentElement.scrollWidth > window.innerWidth + 1;
  }
  function set(l) {
    for (var i = 1; i <= MAX; i++) document.body.classList.toggle("hdr-" + i, i <= l);
  }
  function fit() {
    if (busy) return;
    busy = true;
    var l = 0;
    set(0);
    while (l < MAX && bad()) set(++l);
    busy = false;
  }
  var t = null;
  function soon() { clearTimeout(t); t = setTimeout(fit, 80); }
  window.addEventListener("resize", soon);
  window.addEventListener("load", soon);
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(soon);
  // button text changes (AUDIO ON/OFF, badges, language) can change the widths
  new MutationObserver(function () { if (!busy) soon(); })
    .observe(bar, { subtree: true, childList: true, characterData: true });
  fit();
  setInterval(function () { if (bad()) fit(); }, 3000);
})();
