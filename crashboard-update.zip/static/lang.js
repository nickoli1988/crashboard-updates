/* CRASH BOARD language runtime. Needs i18n.js loaded first. English is the source text in the page;
   other languages are applied by swapping text nodes. Agency text (class "raw") is never touched. */
(function () {
  "use strict";
  var D = window.CB_I18N || { langs: {}, names: { en: "ENGLISH" }, voice: { en: "en-US" } };
  var EN = {
    mon: ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"],
    dow: ["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"],
    dir: ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"],
    ago: "{t} AGO", map: {}
  };
  var cur = "en", L = EN, RE = null;
  var AGO_RE = /(\d+[SMHD](?: \d+[SMHD])?|--) AGO\b/g;
  var SKIP = ".raw, .ins, .txt, script, style, textarea, svg, code";
  var ATTRS = ["placeholder", "title", "aria-label"];

  function escRe(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); }
  function build() {
    if (cur === "en") { RE = null; return; }
    var keys = Object.keys(L.map).sort(function (a, b) { return b.length - a.length; });
    RE = keys.length ? new RegExp("(^|[^A-Za-z0-9À-ÿ])(" + keys.map(escRe).join("|") + ")(?=[^A-Za-z0-9À-ÿ]|$)", "g") : null;
  }
  function t(s) {
    if (cur === "en" || s == null) return s;
    s = String(s).replace(AGO_RE, function (_, x) { return L.ago.replace("{t}", x); });
    return RE ? s.replace(RE, function (_, pre, key) { return pre + L.map[key]; }) : s;
  }

  function skip(el) { return !el || (el.closest && el.closest(SKIP)); }
  function doText(n) {
    if (n.nodeValue === n.__out) return;                 // our own write
    n.__en = n.nodeValue;
    if (!/[A-Za-z]/.test(n.__en) || skip(n.parentElement)) { n.__out = n.__en; return; }
    var out = t(n.__en);
    n.__out = out;
    if (out !== n.nodeValue) n.nodeValue = out;
  }
  function doAttrs(el) {
    if (skip(el)) return;
    for (var i = 0; i < ATTRS.length; i++) {
      var a = ATTRS[i], v = el.getAttribute(a);
      if (v == null) continue;
      var k = "__a_" + a;
      if (!el[k] || v !== el[k].out) el[k] = { en: v };
      var out = t(el[k].en);
      el[k].out = out;
      if (out !== v) el.setAttribute(a, out);
    }
  }
  function walk(root) {
    if (!root) return;
    if (root.nodeType === 3) { doText(root); return; }
    if (root.nodeType !== 1) return;
    if (skip(root)) return;
    doAttrs(root);
    var els = root.querySelectorAll("[placeholder],[title],[aria-label]");
    for (var i = 0; i < els.length; i++) doAttrs(els[i]);
    var w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null, false), n;
    while ((n = w.nextNode())) doText(n);
  }
  function reset(root) {   // put English back so a language switch starts clean
    var w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null, false), n;
    while ((n = w.nextNode())) if (n.__en != null && n.nodeValue === n.__out) { n.__out = n.__en; n.nodeValue = n.__en; }
    var els = root.querySelectorAll("*");
    for (var i = 0; i < els.length; i++) for (var j = 0; j < ATTRS.length; j++) {
      var k = "__a_" + ATTRS[j], o = els[i][k];
      if (o && els[i].getAttribute(ATTRS[j]) === o.out) { els[i].setAttribute(ATTRS[j], o.en); o.out = o.en; }
    }
  }

  var mo = null;
  function observe() {
    if (mo || !window.MutationObserver) return;
    mo = new MutationObserver(function (list) {
      if (cur === "en") return;
      for (var i = 0; i < list.length; i++) {
        var m = list[i];
        if (m.type === "characterData") doText(m.target);
        else if (m.type === "attributes") doAttrs(m.target);
        else for (var j = 0; j < m.addedNodes.length; j++) walk(m.addedNodes[j]);
      }
    });
    mo.observe(document.documentElement, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ATTRS });
  }

  function set(lang) {
    if (!D.langs[lang]) lang = "en";
    if (lang === cur) return false;
    if (cur !== "en") reset(document.body);
    cur = lang;
    L = lang === "en" ? EN : D.langs[lang];
    build();
    document.documentElement.lang = lang;
    try { localStorage.setItem("cb.lang", JSON.stringify(lang)); } catch (e) {}
    if (cur !== "en") { walk(document.head.querySelector("title") || document.head); walk(document.body); }
    observe();
    return true;
  }

  var touched = false;
  window.CBL = {
    set: function (l) { touched = true; return set(l); }, t: t,
    lang: function () { return cur; },
    langs: function () { return ["en"].concat(Object.keys(D.langs)); },
    name: function (l) { return (D.names && D.names[l]) || l.toUpperCase(); },
    mon: function (i) { return (L.mon || EN.mon)[i]; },
    dow: function (i) { return (L.dow || EN.dow)[i]; },
    dir: function (d) { var i = EN.dir.indexOf(d); return i < 0 ? d : (L.dir || EN.dir)[i]; },
    voice: function () { return (D.voice && D.voice[cur]) || "en-US"; },
    flash: function () { return (D.flash && D.flash[cur]) || "Flash traffic."; },
    mag: function () { return (D.mag && D.mag[cur]) || "magnitude $1 point $2"; }
  };

  // first paint: use the language this screen saw last, until the board config arrives
  var q = new URLSearchParams(location.search).get("lang"), saved = null;
  try { saved = JSON.parse(localStorage.getItem("cb.lang")); } catch (e) {}
  function boot() { if (!touched) set(q || saved || "en"); }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot); else boot();
})();
