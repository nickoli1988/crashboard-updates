/* ALERT LIGHTS: CFG section for flashing an IR LED strip through a Wi-Fi (Tasmota) IR blaster.
   Changes here save straight away; they don't wait for the CFG SAVE button. */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  if (!$("ir-on")) return;
  var learnTimer = null, saveTimer = null;

  function post(url, body) {
    return fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body || {}) })
      .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, j: j }; }); });
  }

  function setStatus(text, cls) {
    var el = $("ir-status");
    el.textContent = text;
    el.className = "fine" + (cls ? " " + cls : "");
  }

  function render(s) {
    if (document.activeElement !== $("ir-host")) $("ir-host").value = s.host || "";
    $("ir-on").checked = !!s.enabled;
    $("ir-remote").value = s.remote === "custom" ? "custom" : (s.remote || "24key");
    $("ir-min").value = String(s.min_level || 1);
    $("ir-clear").value = s.clear || "off";
    if (!s.host) setStatus("Enter the IR blaster's address, then tick the box above.", "");
    else if (s.online) setStatus("✓ CONNECTED TO " + String(s.device || "IR BLASTER").toUpperCase() + (s.enabled ? "" : " · tick the box to turn alert lights on"), "good");
    else setStatus("✗ " + (s.error || "Can't reach the IR blaster."), "bad");
    var lr = s.learn || {};
    if (lr.state === "waiting") setStatus("● " + lr.msg, "");
    else if (lr.state === "done" || lr.state === "saved") setStatus("✓ " + lr.msg, "good");
    else if (lr.state === "timeout" || lr.state === "failed") setStatus("✗ " + lr.msg, "bad");

    var box = $("ir-slots");
    box.innerHTML = "";
    (s.slots || []).forEach(function (sl) {
      var d = document.createElement("div");
      d.className = "ir-slot";
      var tag = sl.learned ? '<i class="ok">LEARNED</i>' : sl.has_code ? "<i>BUILT-IN</i>" : '<i>NOT SET</i>';
      d.innerHTML = "<b>" + sl.name + "</b>" + tag +
        '<button type="button" class="btn" data-learn="' + sl.slot + '">LEARN</button>' +
        (sl.has_code ? '<button type="button" class="btn" data-press="' + sl.slot + '" title="Send this button once">▶</button>' : "") +
        (sl.learned ? '<button type="button" class="btn" data-forget="' + sl.slot + '" title="Forget the learned code">✕</button>' : "");
      box.appendChild(d);
    });
    return s;
  }

  var LOCKED_IDS = ["ir-on", "ir-host", "ir-remote", "ir-min", "ir-clear"];
  function setLocked(on) {
    LOCKED_IDS.forEach(function (id) { if ($(id)) $(id).disabled = on; });
    var box = $("ir-slots"); if (box && on) box.innerHTML = "";
    var tests = document.querySelectorAll("[data-irtest]");
    for (var i = 0; i < tests.length; i++) tests[i].disabled = on;
  }
  function load() {
    return fetch("api/ir", { cache: "no-store" }).then(function (r) {
      if (r.status === 402) { setLocked(true); setStatus("Alert lights are part of Crash Board PRO. Add your key under LICENSE to turn them on.", ""); return null; }
      setLocked(false);
      return r.json().then(render);
    }).catch(function () { setStatus("✗ This board can't do alert lights yet (update Crash Board).", "bad"); });
  }

  function save() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(function () {
      post("api/ir", {
        enabled: $("ir-on").checked, host: $("ir-host").value.trim(), remote: $("ir-remote").value,
        min_level: parseInt($("ir-min").value, 10), clear: $("ir-clear").value
      }).then(load);
    }, 300);
  }

  ["ir-on", "ir-remote", "ir-min", "ir-clear"].forEach(function (id) { $(id).addEventListener("change", save); });
  $("ir-host").addEventListener("change", save);

  $("ir-slots").addEventListener("click", function (e) {
    var b = e.target.closest("button");
    if (!b) return;
    if (b.dataset.learn) {
      post("api/ir/learn", { slot: b.dataset.learn }).then(function (res) {
        if (!res.ok) return setStatus("✗ " + (res.j.error || "can't learn"), "bad");
        clearInterval(learnTimer);
        var tries = 0;
        learnTimer = setInterval(function () {
          tries++;
          load().then(function (s) {
            var st = s && s.learn && s.learn.state;
            if (st !== "waiting" || tries > 40) clearInterval(learnTimer);
          });
        }, 1000);
        load();
      });
    } else if (b.dataset.press) {
      post("api/ir/test", { what: b.dataset.press });
    } else if (b.dataset.forget) {
      post("api/ir/forget", { slot: b.dataset.forget }).then(load);
    }
  });

  document.querySelectorAll("[data-irtest]").forEach(function (b) {
    b.addEventListener("click", function () {
      post("api/ir/test", { what: b.dataset.irtest });
      setStatus("Sending " + b.textContent + " to the strip…", "");
      setTimeout(load, 4000);
    });
  });

  $("btn-settings").addEventListener("click", load);
})();
