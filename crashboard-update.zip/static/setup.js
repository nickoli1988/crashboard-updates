/* CRASH BOARD first-time setup: a few questions the first time the board is opened.
   Shown on any screen until someone finishes or skips it (saved on the board, so it only runs once).
   CFG > FIRST-TIME SETUP runs it again. Vanilla ES5, no dependencies (old WebKit safe). */
(function () {
  "use strict";

  var PROFILES = {
    home: {
      name: "HOME DASHBOARD", icon: "⌂",
      desc: "On a PC, laptop or tablet at home. Full effects, sound on, quiet at night.",
      screen: { sound: true, volume: 70, voice: true, quiet: { on: true, start: "22:00", end: "07:00" }, fx: "full" }
    },
    wall: {
      name: "WALL / TV DISPLAY", icon: "▣",
      desc: "An always-on screen people glance at. Louder alarms and spoken callouts, quiet at night.",
      screen: { sound: true, volume: 85, voice: true, quiet: { on: true, start: "22:00", end: "07:00" }, fx: "full" }
    },
    offgrid: {
      name: "OFF-GRID / MESH", icon: "⌁",
      desc: "Battery or solar, with a Meshtastic radio. Lighter effects to save power, alarms at any hour, shares alerts over the mesh.",
      screen: { sound: true, volume: 80, voice: true, quiet: { on: false, start: "22:00", end: "07:00" }, fx: "low" },
      mesh: { enabled: true, broadcast_alerts: true, relay_inbound: true }
    },
    alerts: {
      name: "JUST ALERTS", icon: "!",
      desc: "Stays calm until something big happens. No motion, and sound only for real alerts, day or night.",
      screen: { sound: true, volume: 75, voice: true, quiet: { on: false, start: "22:00", end: "07:00" }, fx: "off" }
    }
  };
  var THEMES = [
    ["ops", "OPS", "Olive drab (original)", "#13170f", "#8fd65a"],
    ["blackout", "BLACKOUT", "Black / orange", "#101010", "#ff8a1f"],
    ["hazard", "HAZARD", "Orange / black", "#ee761d", "#111111"],
    ["coyote", "COYOTE", "Brown / tan", "#241e15", "#e3b86e"],
    ["vault", "VAULT", "Blue / yellow", "#11264b", "#f5c518"],
    ["cva", "CVA", "Amber CRT / 70s", "#100904", "#ff9d33"],
    ["halloween", "HALLOWEEN", "Pumpkin / purple", "#170c1f", "#ff7518"]
  ];
  var LANGS = [["en", "ENGLISH"], ["es", "ESPAÑOL"], ["fr", "FRANÇAIS"], ["de", "DEUTSCH"], ["pt", "PORTUGUÊS"]];

  var $ = function (id) { return document.getElementById(id); };
  var root = null, step = 0, steps = [], ans = null, idleTimer = null, started = false;

  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function post(body) {
    return fetch("api/settings", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) })
      .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, j: j }; }); });
  }
  function clone(o) { return JSON.parse(JSON.stringify(o)); }

  // ------------------------------------------------------------------ steps
  function stepList() {
    var s = ["profile", "location", "sound", "look", "radio", "done"];
    return s;
  }

  function header(n, title, sub) {
    var dots = "";
    for (var i = 1; i < steps.length - 1; i++) dots += '<i class="' + (i < n ? "done" : i === n ? "on" : "") + '"></i>';
    return '<div class="su-top"><span class="sec">SETUP</span><b>' + esc(title) + "</b>" +
      (n > 0 && n < steps.length - 1 ? '<span class="su-dots">' + dots + "</span>" : "") +
      '<button type="button" class="btn su-later" data-act="later" title="Hide for now">LATER</button></div>' +
      (sub ? '<p class="su-sub">' + sub + "</p>" : "");
  }
  function nav(nextLabel, canBack) {
    return '<p class="su-msg" id="su-msg"></p><div class="su-nav">' +
      (canBack ? '<button type="button" class="btn" data-act="back">◂ BACK</button>' : '<button type="button" class="btn" data-act="skip">SKIP SETUP</button>') +
      '<span class="spacer"></span><button type="button" class="btn primary" data-act="next">' + (nextLabel || "NEXT ▸") + "</button></div>";
  }

  var VIEWS = {
    profile: function () {
      var h = header(0, "WELCOME TO CRASH BOARD™",
        "A few quick questions to set the board up the way you'll use it. Takes about a minute, and you can change everything later in <b>CFG</b>.") +
        '<div class="su-label">HOW WILL YOU USE THIS BOARD?</div><div class="su-cards">';
      for (var k in PROFILES) {
        if (k === "offgrid" && !window.CB.mesh) PROFILES[k].mesh = null;
        h += '<button type="button" class="su-card' + (ans.profile === k ? " on" : "") + '" data-profile="' + k + '">' +
          '<span class="su-ico">' + PROFILES[k].icon + "</span><b>" + PROFILES[k].name + "</b><small>" + esc(PROFILES[k].desc) + "</small></button>";
      }
      return h + "</div>" + nav("START ▸", false);
    },

    location: function () {
      var c = ans.cfg, loc = c.location || {};
      return header(1, "YOUR LOCATION",
        "Used for local weather warnings, wildfires near you and how far away quakes are. It stays on this board.") +
        '<label class="su-field">ZIP / POSTCODE, CITY, OR "LAT, LON"<input id="su-loc" value="' + esc(loc.query || "") +
        '" placeholder="e.g. 32216 · Jacksonville, FL · M5V · Brighton" autocomplete="off"></label>' +
        '<div class="su-row"><label class="su-field">COUNTRY<select id="su-cc"><option value="AUTO">AUTO (FROM CITY)</option></select></label>' +
        '<label class="su-field">UNITS<select id="su-units"><option value="imperial">IMPERIAL (°F, MPH, MILES)</option><option value="metric">METRIC (°C, KM/H, KM)</option></select></label></div>' +
        (loc.name ? '<p class="su-ok">✓ CURRENT: ' + esc(loc.name) + "</p>" : "") +
        nav("SAVE + NEXT ▸", true);
    },

    sound: function () {
      var sc = ans.screen;
      return header(2, "SOUND + ALERTS", "Crash Board makes its own alarm sounds, so they work with no internet. Each kind of event has its own sound.") +
        '<div class="su-switch"><button type="button" data-sound="1" class="' + (sc.sound ? "on" : "") + '">SOUND ON</button>' +
        '<button type="button" data-sound="0" class="' + (sc.sound ? "" : "on") + '">SOUND OFF</button></div>' +
        '<div id="su-snd"' + (sc.sound ? "" : " hidden") + ">" +
        '<label class="su-field">VOLUME <span id="su-volv">' + sc.volume + '%</span><input type="range" id="su-vol" min="10" max="100" step="5" value="' + sc.volume + '"></label>' +
        '<div class="su-tests"><span>TRY IT:</span><button type="button" class="btn" data-sutest="seismic">QUAKE</button>' +
        '<button type="button" class="btn" data-sutest="weather">WEATHER</button><button type="button" class="btn" data-sutest="klaxon">RED ALERT</button></div>' +
        '<label class="su-field">MAKE SOUND FOR<select id="su-scope">' +
        [["all", "ALL EVENTS (LOCAL + WORLD)"], ["local", "LOCAL EVENTS ONLY (NEAR ME)"], ["global", "GLOBAL EVENTS ONLY (WORLD)"]]
          .map(function (o) { return '<option value="' + o[0] + '"' + ((sc.alerts || "all") === o[0] ? " selected" : "") + ">" + o[1] + "</option>"; }).join("") + "</select></label>" +
        '<label class="su-chk"><input type="checkbox" id="su-voice"' + (sc.voice ? " checked" : "") + "> SPEAK ALERTS OUT LOUD <small>e.g. “Tornado warning for your area”</small></label>" +
        '<label class="su-chk"><input type="checkbox" id="su-quiet"' + (sc.quiet.on ? " checked" : "") + "> QUIET HOURS <small>only critical alerts make noise</small></label>" +
        '<div class="su-row" id="su-qrow"' + (sc.quiet.on ? "" : " hidden") + '><label class="su-field">FROM<input type="time" id="su-qs" value="' + esc(sc.quiet.start) + '"></label>' +
        '<label class="su-field">TO<input type="time" id="su-qe" value="' + esc(sc.quiet.end) + '"></label></div>' +
        '<label class="su-field">SOUND THE ALARM FOR EARTHQUAKES OF<select id="su-amag">' +
        [[6, "MAGNITUDE 6 OR BIGGER (MORE ALERTS)"], [6.5, "MAGNITUDE 6.5 OR BIGGER"], [7, "MAGNITUDE 7 OR BIGGER (RECOMMENDED)"], [7.5, "MAGNITUDE 7.5 OR BIGGER"], [8, "MAGNITUDE 8 OR BIGGER (ONLY HUGE ONES)"]]
          .map(function (o) { return '<option value="' + o[0] + '">' + o[1] + "</option>"; }).join("") + "</select></label>" +
        "</div>" + nav(null, true);
    },

    look: function () {
      var st = window.CB.state() || {}, L = st.license || {}, pro = L.tier === "pro", free = L.free_themes || ["ops", "blackout"];
      var h = header(3, "LOOK + SCREEN", "Pick a color scheme. It changes on every screen showing this board.") + '<div class="su-themes">';
      THEMES.forEach(function (t) {
        var locked = !pro && free.indexOf(t[0]) < 0;
        h += '<button type="button" class="su-theme' + (ans.theme === t[0] ? " on" : "") + (locked ? " locked" : "") + '" data-theme-pick="' + t[0] + '"' + (locked ? " disabled" : "") + ">" +
          '<span class="sw" style="background:' + t[3] + ";border-color:" + t[4] + '"><i style="background:' + t[4] + '"></i></span><b>' + t[1] + "</b><small>" + (locked ? "PRO" : esc(t[2])) + "</small></button>";
      });
      h += "</div>" +
        '<div class="su-row"><label class="su-field">LANGUAGE<select id="su-lang">' +
        LANGS.map(function (l) { return '<option value="' + l[0] + '">' + l[1] + "</option>"; }).join("") + "</select></label>" +
        '<label class="su-field">EFFECTS<select id="su-fx"><option value="full">FULL: SMOOTH (PC, PI 3+)</option>' +
        '<option value="low">LOW: SAVES POWER (PI ZERO)</option><option value="off">OFF: NO MOTION</option></select></label></div>' +
        nav(null, true);
      return h;
    },

    radio: function () {
      var c = ans.cfg, m = ans.mesh, h;
      if (!window.CB.mesh) {
        return header(4, "NAME YOUR BOARD", "Shown at the top of the board and on the browser tab.") +
          '<label class="su-field">BOARD NAME<input id="su-call" maxlength="24" value="' + esc(c.callsign || "CRASH BOARD") + '"></label>' + nav(null, true);
      }
      h = header(4, "MESHTASTIC RADIO", "Crash Board™ can send and receive messages and alerts through a Meshtastic radio, even with no internet or cell service. No radio? Pick NO RADIO YET.") +
        '<div class="su-label">IS A MESHTASTIC RADIO CONNECTED?</div><div class="su-cards su-cards4">' +
        [["auto", "USB CABLE", "Plugged into this computer or Pi. Found automatically."],
         ["tcp", "WI-FI", "The radio is on your Wi-Fi network."],
         ["ble", "BLUETOOTH", "Paired by Bluetooth."],
         ["off", "NO RADIO YET", "Turn the radio link off for now. Add one any time in CFG."]]
          .map(function (o) {
            var on = (o[0] === "off" && m.enabled === false) || (m.enabled !== false && (m.mode === o[0] || (o[0] === "auto" && m.mode === "serial")));
            return '<button type="button" class="su-card sm' + (on ? " on" : "") + '" data-mmode="' + o[0] + '"><b>' + o[1] + "</b><small>" + o[2] + "</small></button>";
          }).join("") + "</div>" +
        '<label class="su-field" id="su-maddr-row"' + (m.mode === "tcp" || m.mode === "ble" ? "" : " hidden") + '><span id="su-maddr-lbl">' +
        (m.mode === "ble" ? "RADIO'S BLUETOOTH NAME OR ADDRESS" : "RADIO'S IP ADDRESS") + '</span><input id="su-maddr" value="' + esc(m.address || "") +
        '" placeholder="' + (m.mode === "ble" ? "e.g. Meshtastic_1a2b" : "e.g. 192.168.1.50") + '" autocomplete="off" autocapitalize="off" spellcheck="false"></label>' +
        '<label class="su-field">CALLSIGN / BOARD NAME <small>shown at the top, and on alerts this board shares</small><input id="su-call" maxlength="24" value="' + esc(c.callsign || "CRASH BOARD") + '"></label>' +
        '<label class="su-chk"><input type="checkbox" id="su-bcast"' + (m.broadcast_alerts !== false ? " checked" : "") + "> SHARE BIG ALERTS WITH THE MESH <small>PRO</small></label>" +
        '<label class="su-chk"><input type="checkbox" id="su-relay"' + (m.relay_inbound !== false ? " checked" : "") + "> SHOW ALERTS SHARED BY OTHER CRASH BOARDS</label>" +
        nav(null, true);
      return h;
    },

    done: function () {
      var st = window.CB.state() || {}, ad = st.address || {}, c = ans.cfg, loc = c.location || {};
      var url = ad.ip ? "http://" + ad.ip + ":" + ad.port : "";
      var sc = ans.screen, p = PROFILES[ans.profile] || {};
      var lines = [
        ["SET UP AS", p.name || "--"],
        ["LOCATION", loc.name || "NOT SET (local panels stay empty)"],
        ["SOUND", sc.sound ? "ON · " + sc.volume + "%" + (sc.voice ? " · SPOKEN ALERTS" : "") + ({ local: " · LOCAL ONLY", global: " · GLOBAL ONLY" }[sc.alerts] || "") + (sc.quiet.on ? " · QUIET " + sc.quiet.start + "–" + sc.quiet.end : "") : "OFF"],
        ["EFFECTS", { full: "FULL", low: "LOW", off: "OFF" }[sc.fx] || "FULL"]
      ];
      if (window.CB.mesh) lines.push(["RADIO", ans.mesh.enabled === false ? "OFF" : ({ auto: "USB", serial: "USB", tcp: "WI-FI", ble: "BLUETOOTH" }[ans.mesh.mode] || "USB")]);
      return header(5, "ALL SET", "") +
        '<div class="su-done"><b>✓</b> Your board is ready. It checks every source on its own and changes color when something needs your attention.</div>' +
        '<dl class="su-sum">' + lines.map(function (l) { return "<dt>" + l[0] + "</dt><dd>" + esc(l[1]) + "</dd>"; }).join("") + "</dl>" +
        (url ? '<div class="su-addr">OPEN THIS BOARD ON ANY PHONE OR COMPUTER ON YOUR WI-FI:<span class="raw">' + esc(url) + "</span></div>" : "") +
        '<p class="su-sub">Change anything later with the <b>CFG</b> button at the top.' + (window.CB.mesh ? " Read and send mesh messages with <b>COMMS</b>." : "") + "</p>" +
        '<p class="su-msg" id="su-msg"></p><div class="su-nav"><button type="button" class="btn" data-act="back">◂ BACK</button><span class="spacer"></span>' +
        '<button type="button" class="btn primary" data-act="finish">GO TO MY BOARD ▸</button></div>';
    }
  };

  // ------------------------------------------------------------------ fill in + read back each step
  function afterRender() {
    var name = steps[step], st = window.CB.state() || {};
    if (name === "location") {
      var sel = $("su-cc"), list = st.countries || [], loc = ans.cfg.location || {};
      list.forEach(function (x) { var o = document.createElement("option"); o.value = x[0]; o.textContent = String(x[1]).toUpperCase(); sel.appendChild(o); });
      sel.value = loc.cc_pref || "AUTO"; if (!sel.value) sel.value = "AUTO";
      $("su-units").value = ans.cfg.units || "imperial";
      setTimeout(function () { try { $("su-loc").focus(); } catch (e) {} }, 50);
      $("su-loc").addEventListener("keydown", function (e) { if (e.key === "Enter") { e.preventDefault(); next(); } });
    }
    if (name === "sound") {
      $("su-amag").value = String(ans.cfg.alert_quake_mag || 7);
      if (!$("su-amag").value) $("su-amag").value = "7";
      $("su-vol").addEventListener("input", function () { $("su-volv").textContent = this.value + "%"; window.CB.setScreen({ volume: +this.value }); });
      $("su-quiet").addEventListener("change", function () { $("su-qrow").hidden = !this.checked; });
    }
    if (name === "look") {
      $("su-lang").value = ans.cfg.lang || "en";
      $("su-fx").value = ans.screen.fx || "full";
      $("su-lang").addEventListener("change", function () { window.CB.setLang(this.value); post({ lang: this.value }); });
    }
  }

  function readStep() {
    var name = steps[step];
    if (name === "sound") {
      var sc = ans.screen;
      if (sc.sound) {
        sc.volume = +$("su-vol").value; sc.voice = $("su-voice").checked; sc.alerts = $("su-scope").value || "all";
        sc.quiet = { on: $("su-quiet").checked, start: $("su-qs").value || "22:00", end: $("su-qe").value || "07:00" };
        ans.amag = parseFloat($("su-amag").value) || 7;
      }
    }
    if (name === "look") ans.screen.fx = $("su-fx").value;
    if (name === "radio") {
      ans.callsign = ($("su-call").value || "").trim() || "CRASH BOARD";
      if (window.CB.mesh) {
        ans.mesh.address = $("su-maddr") ? $("su-maddr").value.trim() : "";
        ans.mesh.broadcast_alerts = $("su-bcast").checked; ans.mesh.relay_inbound = $("su-relay").checked;
      }
    }
  }

  // saves this step to the board; resolves true to move on
  function saveStep() {
    var name = steps[step], body = null;
    if (name === "location") {
      var q = $("su-loc").value.trim();
      body = { location: q, country: $("su-cc").value, units: $("su-units").value };
      if (!q) { msg("No location: local weather, alerts and fires will stay empty. Press NEXT again to carry on anyway, or type a ZIP or city.", ""); if (!ans.noLocOk) { ans.noLocOk = true; return Promise.resolve(false); } }
      msg("FINDING " + (q ? q.toUpperCase() : "") + "…", "");
    }
    if (name === "sound") body = { alert_quake_mag: ans.amag || 7 };
    if (name === "look") body = { theme: ans.theme };
    if (name === "radio") {
      body = { callsign: ans.callsign };
      if (window.CB.mesh) {
        if ((ans.mesh.mode === "tcp" || ans.mesh.mode === "ble") && ans.mesh.enabled !== false && !ans.mesh.address && ans.mesh.mode === "tcp") {
          msg("Type the radio's IP address. You can find it in the Meshtastic app under Settings › Network.", "bad"); return Promise.resolve(false);
        }
        body.mesh = { enabled: ans.mesh.enabled !== false, mode: ans.mesh.mode, address: ans.mesh.address,
                      broadcast_alerts: ans.mesh.broadcast_alerts, relay_inbound: ans.mesh.relay_inbound };
      }
    }
    if (!body) return Promise.resolve(true);
    return post(body).then(function (res) {
      if (!res.ok) { msg("✗ " + (res.j.error || "Couldn't save that. Check it and try again."), "bad"); return false; }
      if (res.j.config) ans.cfg = res.j.config;
      return true;
    }).catch(function () { msg("✗ Can't reach the board. Is it still running?", "bad"); return false; });
  }

  function msg(t, cls) { var m = $("su-msg"); if (m) { m.textContent = t || ""; m.className = "su-msg" + (cls ? " " + cls : ""); } }

  // ------------------------------------------------------------------ flow
  function render() {
    root.querySelector(".su-sheet").innerHTML = VIEWS[steps[step]]();
    root.querySelector(".su-sheet").scrollTop = 0;
    afterRender();
  }
  function next() {
    readStep();
    var btn = root.querySelector('[data-act="next"]'); if (btn) btn.disabled = true;
    saveStep().then(function (ok) {
      if (btn) btn.disabled = false;
      if (!ok) return;
      step = Math.min(step + 1, steps.length - 1); render();
    });
  }
  function finish(skipped) {
    var body = { setup_done: true };
    if (!skipped) { body.profile = ans.profile; body.screen = ans.screen; window.CB.setScreen(ans.screen); }
    post(body).then(function () { close(); window.CB.poll(); }).catch(function () { close(); });
  }
  function close() { if (root) { root.parentNode.removeChild(root); root = null; } var c = $("su-chip"); if (c) c.parentNode.removeChild(c); clearTimeout(idleTimer); }
  function later() {
    if (!root) return;
    root.hidden = true;
    if (!$("su-chip")) {
      var chip = document.createElement("button");
      chip.type = "button"; chip.id = "su-chip"; chip.className = "btn su-chip"; chip.textContent = "◂ FINISH SETUP";
      chip.addEventListener("click", function () { root.hidden = false; chip.parentNode.removeChild(chip); poke(); });
      document.body.appendChild(chip);
    }
  }
  // nobody touching it (e.g. a wall screen with no mouse): tuck it into a corner after 3 minutes
  function poke() { clearTimeout(idleTimer); idleTimer = setTimeout(later, 180000); }

  function pickProfile(k) {
    ans.profile = k;
    var p = PROFILES[k];
    ans.screen = clone(p.screen);
    if (p.mesh && window.CB.mesh) { ans.mesh.enabled = true; ans.mesh.broadcast_alerts = true; ans.mesh.relay_inbound = true; }
    var cards = root.querySelectorAll("[data-profile]");
    for (var i = 0; i < cards.length; i++) cards[i].classList.toggle("on", cards[i].getAttribute("data-profile") === k);
  }

  function onClick(e) {
    poke();
    var t = e.target.closest ? e.target.closest("button") : null;
    if (!t || !root.contains(t)) return;
    var act = t.getAttribute("data-act");
    if (act === "next") { if (steps[step] === "profile" && !ans.profile) pickProfile("home"); return next(); }
    if (act === "back") { readStep(); step = Math.max(0, step - 1); return render(); }
    if (act === "skip") { if (window.confirm("Skip setup? The board starts with its normal settings, and you can run setup again from CFG.")) finish(true); return; }
    if (act === "later") return later();
    if (act === "finish") return finish(false);
    if (t.hasAttribute("data-profile")) { pickProfile(t.getAttribute("data-profile")); return; }
    if (t.hasAttribute("data-sound")) {
      ans.screen.sound = t.getAttribute("data-sound") === "1";
      window.CB.setScreen({ sound: ans.screen.sound });
      readStep(); render(); return;
    }
    if (t.hasAttribute("data-sutest")) {
      window.CB.setScreen({ volume: +$("su-vol").value });
      window.CB.testSound(t.getAttribute("data-sutest"));
      setTimeout(function () { if (!window.CB.testSound) return; }, 0);
      return;
    }
    if (t.hasAttribute("data-theme-pick")) {
      ans.theme = t.getAttribute("data-theme-pick");
      window.CB.applyTheme(ans.theme);
      var b = root.querySelectorAll("[data-theme-pick]");
      for (var i = 0; i < b.length; i++) b[i].classList.toggle("on", b[i] === t);
      return;
    }
    if (t.hasAttribute("data-mmode")) {
      var mm = t.getAttribute("data-mmode");
      readStep();
      if (mm === "off") ans.mesh.enabled = false; else { ans.mesh.enabled = true; ans.mesh.mode = mm; }
      render(); return;
    }
  }

  function open(fromCfg) {
    var st = window.CB.state();
    if (!st || root) return;
    var c = st.config || {};
    ans = {
      cfg: clone(c), profile: c.profile || "", theme: c.theme || "ops",
      screen: clone(window.CB.screen()),
      mesh: clone(c.mesh || { enabled: true, mode: "auto" })
    };
    if (ans.screen.quiet == null) ans.screen.quiet = { on: true, start: "22:00", end: "07:00" };
    steps = stepList(); step = 0;
    root = document.createElement("div");
    root.className = "modal su"; root.id = "setup";
    root.innerHTML = '<div class="sheet su-sheet" role="dialog" aria-label="First-time setup"></div>';
    document.body.appendChild(root);
    root.addEventListener("click", onClick);
    root.addEventListener("input", poke);
    render();
    if (!fromCfg) poke();
  }

  // CFG > FIRST-TIME SETUP
  function addCfgButton() {
    var act = document.querySelector("#cfg-form .actions");
    if (!act || $("btn-setup")) return;
    var b = document.createElement("button");
    b.type = "button"; b.className = "btn"; b.id = "btn-setup"; b.textContent = "FIRST-TIME SETUP";
    b.addEventListener("click", function () { $("modal").hidden = true; open(true); });
    act.insertBefore(b, act.firstChild.nextSibling);
  }

  window.CBSetup = {
    start: function () {
      if (started || !window.CB) return;
      started = true;
      addCfgButton();
      var tries = 0;
      (function wait() {
        var st = window.CB.state();
        if (st && st.config) {
          var q = new URLSearchParams(location.search);
          if (!st.config.setup_done && q.get("display") !== "1" && q.get("setup") !== "0") open(false);
          return;
        }
        if (++tries < 120) setTimeout(wait, 500);
      })();
    },
    open: function () { open(true); },
    isOpen: function () { return !!(root && !root.hidden); },
    later: function () { later(); }
  };
  if (window.CB) window.CBSetup.start();
})();
