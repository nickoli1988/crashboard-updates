#!/usr/bin/env bash
# CRASH BOARD installer for Raspberry Pi OS (Lite or Desktop), incl. Pi Zero W.
#
#   ./install.sh                  HOST, no screen: runs Crash Board; view it from any phone/PC
#   ./install.sh --kiosk          HOST + SCREEN:   runs Crash Board and shows it on the attached screen
#   ./install.sh --display [URL]  DISPLAY ONLY:    shows a Crash Board hosted on another device
#                                 (Pi 3, PC...) over Wi-Fi, full PC layout. Asks for the address
#                                 if you leave it off, e.g.  ./install.sh --display 192.168.1.40
set -euo pipefail

MODE=host
HOST_URL=""
case "${1:-}" in
  --kiosk)   MODE=kiosk ;;
  --display) MODE=display; HOST_URL="${2:-}" ;;
  "")        ;;
  *) echo "Unknown option: $1  (use --kiosk or --display)"; exit 1 ;;
esac

APP_DIR="$(cd "$(dirname "$0")" && pwd)"
RUN_USER="${SUDO_USER:-$USER}"
PORT="${CRASHBOARD_PORT:-8080}"
SERVICE=crashboard.service

echo "== CRASH BOARD install ($MODE) =="
echo "   dir:  $APP_DIR"
echo "   user: $RUN_USER"

command -v python3 >/dev/null || { sudo apt-get update && sudo apt-get install -y python3; }

# ---- radio (RTL-SDR stick) drivers, so the RADIO page works with no extra steps ----
if ! command -v rtl_fm >/dev/null 2>&1; then
  echo "   installing radio (RTL-SDR) drivers..."
  sudo apt-get install -y rtl-sdr >/dev/null 2>&1 || { sudo apt-get update >/dev/null 2>&1 && sudo apt-get install -y rtl-sdr >/dev/null 2>&1; } \
    || echo "   (radio drivers skipped - use INSTALL RADIO SUPPORT on the RADIO page later)"
fi
echo 'blacklist dvb_usb_rtl28xxu' | sudo tee /etc/modprobe.d/blacklist-dvb_usb_rtl28xxu.conf >/dev/null || true
sudo modprobe -r dvb_usb_rtl28xxu 2>/dev/null || true

# ---- let the RADIO page's INSTALL RADIO SUPPORT button work (only this one root-owned helper, nothing else)
sudo install -o root -g root -m 755 "$APP_DIR/setup/radio-helper.sh" /usr/local/sbin/crashboard-radio-setup
printf '%s ALL=(root) NOPASSWD: /usr/local/sbin/crashboard-radio-setup install, /usr/local/sbin/crashboard-radio-setup reboot\n' "$RUN_USER" \
  | sudo tee /etc/sudoers.d/crashboard-radio >/dev/null
sudo chmod 440 /etc/sudoers.d/crashboard-radio
sudo visudo -cf /etc/sudoers.d/crashboard-radio >/dev/null 2>&1 || sudo rm -f /etc/sudoers.d/crashboard-radio
mkdir -p "$APP_DIR/data"
chown -R "$RUN_USER":"$RUN_USER" "$APP_DIR/data" 2>/dev/null || true

# ---- Meshtastic radio support (COMMS) is built in: library + USB permission (skipped quietly if offline) ----
if ! sudo -u "$RUN_USER" python3 -c "import meshtastic" >/dev/null 2>&1; then
  echo "   installing Meshtastic radio support (a few minutes on a Pi Zero)..."
  sudo apt-get install -y python3-pip >/dev/null 2>&1 || true
  sudo -u "$RUN_USER" python3 -m pip install --user --break-system-packages -q meshtastic >/dev/null 2>&1 || \
    sudo -u "$RUN_USER" python3 -m pip install --user -q meshtastic >/dev/null 2>&1 || \
    echo "   (Meshtastic support skipped - no internet? Run this installer again later to add it)"
fi
sudo usermod -aG dialout "$RUN_USER" 2>/dev/null || true      # lets the board open a radio's USB port

# ---- moving over from the old separate Mesh edition (crashboard-mesh): keep its settings, PRO key and messages ----
OLD_MESH="$(dirname "$APP_DIR")/crashboard-mesh"
if [ -d "$OLD_MESH/data" ] && [ "$OLD_MESH" != "$APP_DIR" ]; then
  if [ ! -f "$APP_DIR/data/config.json" ]; then
    echo "   copying your settings from the old Crash Board Mesh install"
    cp -an "$OLD_MESH/data/." "$APP_DIR/data/" 2>/dev/null || true
    rm -f "$APP_DIR/data/port.txt"
    chown -R "$RUN_USER":"$RUN_USER" "$APP_DIR/data" 2>/dev/null || true
  fi
  if systemctl list-unit-files 2>/dev/null | grep -q "^crashboard-mesh.service"; then
    echo "   turning off the old separate Mesh edition (it's built into this board now)"
    sudo systemctl disable --now crashboard-mesh.service >/dev/null 2>&1 || true
  fi
  sudo rm -f /usr/share/applications/crashboard-mesh.desktop 2>/dev/null || true
  rm -f "/home/$RUN_USER/Desktop/crashboard-mesh.desktop" 2>/dev/null || true
fi

# ------------------------------------------------------------------ helpers
reachable() {   # reachable URL -> 0 if a Crash Board answers there
  python3 - "$1" <<'PY' >/dev/null 2>&1
import sys, urllib.request
urllib.request.urlopen(sys.argv[1].rstrip("/") + "/api/state", timeout=5)
PY
}

setup_server() {
  rm -f "$APP_DIR/data/display.conf"          # this device is a host again
  sudo tee /etc/systemd/system/$SERVICE >/dev/null <<EOF
[Unit]
Description=Crash Board threat monitor
After=network-online.target
Wants=network-online.target

[Service]
User=$RUN_USER
WorkingDirectory=$APP_DIR
Environment=CRASHBOARD_PORT=$PORT
ExecStart=/usr/bin/python3 $APP_DIR/server.py --port $PORT
Restart=always
RestartSec=10
Nice=5

[Install]
WantedBy=multi-user.target
EOF
  sudo systemctl daemon-reload
  sudo systemctl enable --now $SERVICE
  echo "   service: $SERVICE enabled (port $PORT)"
  # ---- Pi with a desktop: a Crash Board icon in the main menu and on the desktop (opens in its own window)
  if [ -d /usr/share/applications ]; then
    OPEN="$APP_DIR/open-board.sh"
    cat > "$OPEN" <<EOF
#!/usr/bin/env bash
# Opens Crash Board in its own window (the board itself runs in the background service).
PORT="\$(cat "$APP_DIR/data/port.txt" 2>/dev/null || echo $PORT)"
URL="http://127.0.0.1:\$PORT/?desktop=1"
for b in chromium chromium-browser; do
  command -v "\$b" >/dev/null && exec "\$b" --app="\$URL" --class=crashboard --autoplay-policy=no-user-gesture-required
done
exec xdg-open "\$URL"
EOF
    chmod +x "$OPEN"; chown "$RUN_USER":"$RUN_USER" "$OPEN" 2>/dev/null || true
    DESK="/usr/share/applications/crashboard.desktop"
    sudo tee "$DESK" >/dev/null <<EOF
[Desktop Entry]
Type=Application
Name=Crash Board
Comment=Threat dashboard: earthquakes, severe weather, wildfires and more
Exec=$OPEN
Icon=$APP_DIR/static/icon-512.png
Terminal=false
Categories=Utility;Network;
StartupWMClass=crashboard
EOF
    DESKTOP_DIR="$(sudo -u "$RUN_USER" xdg-user-dir DESKTOP 2>/dev/null || echo "/home/$RUN_USER/Desktop")"
    if [ -d "$DESKTOP_DIR" ]; then
      cp "$DESK" "$DESKTOP_DIR/crashboard.desktop"
      chmod +x "$DESKTOP_DIR/crashboard.desktop"; chown "$RUN_USER":"$RUN_USER" "$DESKTOP_DIR/crashboard.desktop" 2>/dev/null || true
      sudo -u "$RUN_USER" gio set "$DESKTOP_DIR/crashboard.desktop" metadata::trusted true 2>/dev/null || true
    fi
    echo "   desktop: Crash Board added to the menu and the desktop"
  fi
}

setup_screen() {
  echo "== screen setup =="
  ARCH="$(uname -m)"
  PKGS="xserver-xorg xinit x11-xserver-utils unclutter python3-pil fonts-dejavu-core"
  # Pi Zero / Zero W / Pi 1 are ARMv6: they draw the board with zero/fbboard.py (python3-pil) instead of a
  # browser; surf stays installed as a fallback (touch data/use-browser to use it).
  sudo usermod -aG video,tty,input,audio "$RUN_USER" 2>/dev/null || true
  if [[ "$ARCH" == "armv6l" ]]; then BROWSER_PKG="surf"; else BROWSER_PKG="chromium-browser"; fi
  sudo apt-get update
  # The light browser (surf) plays alert sounds through GStreamer: without these it stays silent
  sudo apt-get install -y --no-install-recommends gstreamer1.0-plugins-base gstreamer1.0-plugins-good gstreamer1.0-alsa >/dev/null 2>&1 || true
  # Chromium's package name differs between OS releases: try both, then fall back to surf.
  sudo apt-get install -y --no-install-recommends $PKGS $BROWSER_PKG || \
    sudo apt-get install -y --no-install-recommends $PKGS chromium || \
    sudo apt-get install -y --no-install-recommends $PKGS surf
  chmod +x "$APP_DIR/kiosk.sh"

  # auto-login on the console (tty1)
  if command -v raspi-config >/dev/null; then sudo raspi-config nonint do_boot_behaviour B2 || true; fi

  # start X + the board when logging in on tty1
  PROFILE="/home/$RUN_USER/.bash_profile"
  MARK="# crashboard-kiosk"
  sed -i "/$MARK/,/^fi\$/d" "$PROFILE" 2>/dev/null || true      # replace an older hook
  sed -i "/# crashboard-mesh-kiosk/,/^fi\$/d" "$PROFILE" 2>/dev/null || true   # the old Mesh edition's screen hook
  cat >> "$PROFILE" <<EOF

$MARK
if [ -z "\$DISPLAY" ] && [ "\$(tty)" = "/dev/tty1" ]; then
  CB_XFAIL=0
  while true; do
    CB_FB=0
    case "\$(uname -m)" in armv6l) CB_FB=1;; esac
    grep -qaE "Raspberry Pi ([123]|Zero)" /proc/device-tree/model 2>/dev/null && CB_FB=1
    [ -f $APP_DIR/data/use-fb ] && CB_FB=1
    [ -f $APP_DIR/data/use-browser ] && CB_FB=0
    [ \$CB_XFAIL -ge 3 ] && CB_FB=1                # the browser screen failed to start 3 times
    python3 -c "import PIL" 2>/dev/null || CB_FB=0  # no Pillow: only the browser can draw
    mkdir -p $APP_DIR/data
    if [ "\$CB_FB" = 1 ]; then
      # Pi Zero / Pi 1-3: draw the board straight onto the screen (no web browser)
      python3 $APP_DIR/zero/fbboard.py >$APP_DIR/data/fb.log 2>&1
    else
      CB_T0=\$(date +%s)
      startx $APP_DIR/kiosk.sh >$APP_DIR/data/x.log 2>&1
      [ \$(( \$(date +%s) - CB_T0 )) -lt 30 ] && CB_XFAIL=\$((CB_XFAIL+1))
    fi
    sleep 3
  done
fi
EOF
  chown "$RUN_USER":"$RUN_USER" "$PROFILE"

  # Pi 1-3: the browser draws, but with the "modesetting" driver the picture never reaches HDMI (black screen).
  # Draw through the framebuffer instead (the same screen the light screen uses), and run the TV at 720p.
  if grep -qaE "Raspberry Pi ([123]|Zero)" /proc/device-tree/model 2>/dev/null; then
    sudo mkdir -p /etc/X11/xorg.conf.d
    printf '%s\n' 'Section "Device"' '    Identifier "CrashBoardScreen"' '    Driver     "fbdev"' \
      '    Option     "fbdev" "/dev/fb0"' '    Option     "ShadowFB" "on"' 'EndSection' | sudo tee /etc/X11/xorg.conf.d/99-crashboard-screen.conf >/dev/null
    for c in /boot/firmware/cmdline.txt /boot/cmdline.txt; do
      [ -f "$c" ] && ! grep -q "video=HDMI" "$c" && sudo sed -i '1 s/$/ video=HDMI-A-1:1280x720@60/' "$c" || true
    done
  fi
  # Pi 5: point the browser screen at the graphics device that drives HDMI (checked at every start)
  if [ -f "$APP_DIR/setup/crashboard-pi5-screen.service" ]; then
    sed "s#@APP@#$APP_DIR#g" "$APP_DIR/setup/crashboard-pi5-screen.service" | sudo tee /etc/systemd/system/crashboard-pi5-screen.service >/dev/null
    sudo systemctl enable crashboard-pi5-screen.service >/dev/null 2>&1 || true
    sudo bash "$APP_DIR/setup/pi5-screen.sh" >/dev/null 2>&1 || true
  fi
  echo "   screen: board will appear on boot (browser: $BROWSER_PKG)"
}

# ------------------------------------------------------------------ modes
if [[ $MODE == host || $MODE == kiosk ]]; then
  setup_server
  [[ $MODE == kiosk ]] && setup_screen
  IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
  echo
  echo "== DONE =="
  echo "This device is a Crash Board HOST."
  echo "Open http://${IP:-<pi-ip>}:$PORT on any phone/PC on this network. Tap CFG to set your location."
  echo "Wi-Fi displays can show it with:   ./install.sh --display ${IP:-<this-ip>}:$PORT"
  [[ $MODE == kiosk ]] && echo "Reboot to start the attached-screen board:  sudo reboot"
  exit 0
fi

# ---- DISPLAY ONLY ----
if [[ -z "$HOST_URL" ]]; then
  echo
  echo "Which device runs Crash Board? Type its address and press Enter."
  echo "   examples:  192.168.1.40      crashboard.local      192.168.1.40:8080"
  read -r -p "   host address: " HOST_URL
fi
HOST_URL="$(echo "$HOST_URL" | tr -d '[:space:]')"
[[ -z "$HOST_URL" ]] && { echo "No address given."; exit 1; }
[[ "$HOST_URL" =~ ^https?:// ]] || HOST_URL="http://$HOST_URL"
# add the default port if none was typed
if ! python3 -c "import sys,urllib.parse;sys.exit(0 if urllib.parse.urlparse(sys.argv[1]).port else 1)" "$HOST_URL"; then
  HOST_URL="${HOST_URL%/}:8080"
fi
HOST_URL="${HOST_URL%/}"

echo "   checking $HOST_URL ..."
if reachable "$HOST_URL"; then
  echo "   OK: found Crash Board at $HOST_URL"
else
  echo "   WARNING: no Crash Board answered at $HOST_URL right now."
  echo "   The display will keep trying every few seconds, so this is fine if the host is off."
fi

cat > "$APP_DIR/data/display.conf" <<EOF
# Crash Board DISPLAY settings (read by kiosk.sh at boot)
HOST_URL="$HOST_URL"
# Width the page lays out at before being zoomed to fit the screen.
# 1280 = full PC layout, readable on a 7" screen. Bigger = more like a big monitor, smaller text.
LAYOUT_WIDTH=1280
EOF
chown "$RUN_USER":"$RUN_USER" "$APP_DIR/data/display.conf" 2>/dev/null || true

# a display doesn't run its own server: switch off a local one from an earlier install
if systemctl list-unit-files 2>/dev/null | grep -q "^$SERVICE"; then
  echo "   turning off this device's own Crash Board server (it's a display now)"
  sudo systemctl disable --now $SERVICE || true
fi

setup_screen
echo
echo "== DONE =="
echo "This device is a Crash Board DISPLAY for $HOST_URL"
echo "Reboot to start it:  sudo reboot"
echo "To change the host later:  ./install.sh --display <new address>"
