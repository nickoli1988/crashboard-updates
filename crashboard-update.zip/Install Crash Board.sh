#!/usr/bin/env bash
# CRASH BOARD(TM) - double-click installer for Raspberry Pi OS with Desktop (Pi 3, 4, 5).
# Double-click this file and choose "Execute in Terminal". No typing needed.
cd "$(dirname "$(readlink -f "$0")")"
echo
echo "  CRASH BOARD: installing... this takes a few minutes. Leave this window open."
echo
if bash install.sh; then
  echo
  echo "  ============================================================"
  echo "   DONE!  Crash Board is in your main menu and on your desktop."
  echo "   It starts by itself every time the Pi turns on."
  echo "   Future updates install themselves (or from a USB stick)."
  echo "  ============================================================"
  [ -x ./open-board.sh ] && (./open-board.sh >/dev/null 2>&1 &)
else
  echo
  echo "  Something went wrong. Take a photo of this window and send it to LL3D."
fi
echo
read -r -p "  Press Enter to close this window... " _
