"""
CRASH BOARD licensing: FREE vs PRO.

A PRO key is a small record ({"t":"pro","o":order,...}) signed with LL3D's private Ed25519
key. The board only holds the PUBLIC key below, so it can check a key offline but nobody can
make new keys without the private key (kept by the seller, see tools/keygen.py).

A key can carry the buyer's name ("Licensed to ...", shown in CFG), so a shared key points back to its buyer.
LL3D can cancel a leaked key with a BAN LIST: a small file, signed with the same private key, published
at BAN_LIST_URL. Boards check it about once a day when online. Offline boards keep working.

BOARD LIMIT (optional): when ACTIVATION_URL is set, a key also has to be activated online once per board.
LL3D's activation service remembers up to MAX_BOARDS board IDs per key and sends back a small token signed
with a SEPARATE activation key (ACTIVATION_PUBLIC_KEY_HEX). After that the board works offline for good.
"Release this board" frees its slot. Leave ACTIVATION_URL empty and keys work exactly as before.

Safety features (alerts, sounds, every data panel) are never locked.
"""
import base64
import hashlib
import json
import os
import secrets
import time

# Replaced automatically by `python tools/keygen.py new-signing-key`.
PUBLIC_KEY_HEX = "00eeab4e55a4170e60f4cbd915bd31173f389a58c9b704f1ac7ebb695ca92146"

# Where LL3D publishes the signed ban list. Set with `python keygen.py set-ban-list-url <url> <app folders>`.
BAN_LIST_URL = ""

# Board limit: set with `python keygen.py set-activation-url <url> <app folders>` and `new-activation-key`.
ACTIVATION_URL = ""
ACTIVATION_PUBLIC_KEY_HEX = ""
MAX_BOARDS = 3

KEY_PREFIX = "CB-"
FREE_THEMES = ("ops", "blackout", "halloween", "nvg")     # night vision is free: it is a safety tool
PRO_FEATURES = {
    "no_promos": "No LL3D promo strip",
    "themes": "All color schemes",
    "displays": "Wi-Fi displays and TV dongles",
    "mesh": "Meshtastic COMMS: send messages and share alerts",
    "crash_bank": "CRASH BANK local file library",
}

# ---------------------------------------------------------------------------
# Ed25519 (RFC 8032 reference implementation, pure Python, standard library only)
# ---------------------------------------------------------------------------
_p = 2 ** 255 - 19
_q = 2 ** 252 + 27742317777372353535851937790883648493


def _inv(x):
    return pow(x, _p - 2, _p)


_d = -121665 * _inv(121666) % _p
_SQRT_M1 = pow(2, (_p - 1) // 4, _p)


def _sha512(b):
    return hashlib.sha512(b).digest()


def _add(P, Q):
    A = (P[1] - P[0]) * (Q[1] - Q[0]) % _p
    B = (P[1] + P[0]) * (Q[1] + Q[0]) % _p
    C = 2 * P[3] * Q[3] * _d % _p
    D = 2 * P[2] * Q[2] % _p
    E, F, G, H = B - A, D - C, D + C, B + A
    return (E * F % _p, G * H % _p, F * G % _p, E * H % _p)


def _mul(s, P):
    Q = (0, 1, 1, 0)
    while s > 0:
        if s & 1:
            Q = _add(Q, P)
        P = _add(P, P)
        s >>= 1
    return Q


def _equal(P, Q):
    return (P[0] * Q[2] - Q[0] * P[2]) % _p == 0 and (P[1] * Q[2] - Q[1] * P[2]) % _p == 0


def _recover_x(y, sign):
    if y >= _p:
        return None
    x2 = (y * y - 1) * _inv(_d * y * y + 1) % _p
    if x2 == 0:
        return None if sign else 0
    x = pow(x2, (_p + 3) // 8, _p)
    if (x * x - x2) % _p != 0:
        x = x * _SQRT_M1 % _p
    if (x * x - x2) % _p != 0:
        return None
    if (x & 1) != sign:
        x = _p - x
    return x


_gy = 4 * _inv(5) % _p
_gx = _recover_x(_gy, 0)
_G = (_gx, _gy, 1, _gx * _gy % _p)


def _compress(P):
    zi = _inv(P[2])
    x, y = P[0] * zi % _p, P[1] * zi % _p
    return int.to_bytes(y | ((x & 1) << 255), 32, "little")


def _decompress(s):
    if len(s) != 32:
        return None
    y = int.from_bytes(s, "little")
    sign = y >> 255
    y &= (1 << 255) - 1
    x = _recover_x(y, sign)
    return None if x is None else (x, y, 1, x * y % _p)


def _expand(secret):
    h = _sha512(secret)
    a = int.from_bytes(h[:32], "little")
    a &= (1 << 254) - 8
    a |= 1 << 254
    return a, h[32:]


def _hq(b):
    return int.from_bytes(_sha512(b), "little") % _q


def public_from_secret(secret):
    return _compress(_mul(_expand(secret)[0], _G))


def sign(secret, msg):
    a, prefix = _expand(secret)
    A = _compress(_mul(a, _G))
    r = _hq(prefix + msg)
    Rs = _compress(_mul(r, _G))
    s = (r + _hq(Rs + A + msg) * a) % _q
    return Rs + int.to_bytes(s, 32, "little")


def verify_sig(public, msg, sig):
    if len(public) != 32 or len(sig) != 64:
        return False
    A, R = _decompress(public), _decompress(sig[:32])
    if not A or not R:
        return False
    s = int.from_bytes(sig[32:], "little")
    if s >= _q:
        return False
    h = _hq(sig[:32] + public + msg)
    return _equal(_mul(s, _G), _add(R, _mul(h, A)))


# ---------------------------------------------------------------------------
# keys
# ---------------------------------------------------------------------------
def clean_name(name):
    """Buyer name as stored in a key: letters, digits, spaces and . ' - only, 32 characters at most."""
    n = "".join(ch for ch in str(name or "") if ch.isalnum() or ch in " .'-")
    return " ".join(n.split())[:32]


def make_key(secret, order, tier="pro", days=0, name=""):
    """Seller side: create a key string. days=0 means it never expires. name = the buyer (optional).
    Payload is tiny on purpose ("P|1001|20261006||Jane Doe"): the signature alone is 64 bytes."""
    t = {"pro": "P"}.get(tier, "P")
    exp = str(int(time.time() // 86400 + days)) if days else ""           # expiry as a day number
    order = "".join(ch for ch in str(order) if ch.isalnum() or ch in "-_#")[:16]
    fields = [t, order, time.strftime("%Y%m%d"), exp]
    if clean_name(name):
        fields.append(clean_name(name))
    payload = "|".join(fields).encode("utf-8")
    b32 = base64.b32encode(sign(secret, payload) + payload).decode().rstrip("=")
    return KEY_PREFIX + "-".join(b32[i:i + 5] for i in range(0, len(b32), 5))


def key_id(payload):
    """Short fingerprint of a key (what the ban list lists, so keys themselves are never published)."""
    return hashlib.sha256(payload).hexdigest()[:16]


def check_key(key, public_hex=None):
    """Board side: returns the license record if the key is genuine, else raises ValueError."""
    pub_hex = public_hex or PUBLIC_KEY_HEX
    if pub_hex.startswith("__"):
        raise ValueError("this copy of Crash Board has no license key installed by the seller")
    k = "".join(ch for ch in (key or "").upper() if ch.isalnum())
    if k.startswith("CB"):
        k = k[2:]
    try:
        blob = base64.b32decode(k + "=" * (-len(k) % 8))
    except Exception:
        raise ValueError("that doesn't look like a Crash Board key (check for typos)")
    if len(blob) < 70:
        raise ValueError("key is too short: copy the whole thing")
    sig, payload = blob[:64], blob[64:]
    if not verify_sig(bytes.fromhex(pub_hex), payload, sig):
        raise ValueError("key not valid (typo, or not an official LL3D key)")
    try:
        parts = payload.decode("utf-8").split("|")
        t, order, issued, exp = parts[:4]
        name = parts[4] if len(parts) > 4 else ""
    except (ValueError, UnicodeDecodeError):
        raise ValueError("key format not recognised")
    rec = {"t": {"P": "pro"}.get(t, t), "o": order, "d": "%s-%s-%s" % (issued[:4], issued[4:6], issued[6:8]),
           "id": key_id(payload)}
    if name:
        rec["n"] = name
    if exp:
        rec["x"] = int(exp) * 86400 + 86399
        if time.time() > rec["x"]:
            raise ValueError("this key expired on " + time.strftime("%Y-%m-%d", time.gmtime(rec["x"])))
    return rec


# ---------------------------------------------------------------------------
# ban list (cancelled keys)
# ---------------------------------------------------------------------------
def _ban_body(b):
    return json.dumps({"v": 1, "issued": b.get("issued", ""), "orders": sorted(b.get("orders", [])),
                       "ids": sorted(b.get("ids", []))}, sort_keys=True, separators=(",", ":")).encode()


def make_ban_list(secret, orders=(), ids=()):
    """Seller side: a signed list of cancelled orders and key fingerprints."""
    b = {"v": 1, "issued": time.strftime("%Y-%m-%d %H:%M:%S"), "orders": sorted(set(map(str, orders))),
         "ids": sorted(set(ids))}
    b["sig"] = sign(secret, _ban_body(b)).hex()
    return b


def check_ban_list(b, public_hex=None):
    """Board side: True if this ban list really comes from LL3D."""
    try:
        return verify_sig(bytes.fromhex(public_hex or PUBLIC_KEY_HEX), _ban_body(b), bytes.fromhex(b["sig"]))
    except Exception:
        return False


def is_banned(rec, b):
    return bool(rec) and (str(rec.get("o")) in b.get("orders", []) or rec.get("id") in b.get("ids", []))


BANNED_MSG = "This PRO key was cancelled by LL3D (it was shared or refunded). Contact LL3D if you think this is a mistake."


# ---------------------------------------------------------------------------
# activation (board limit)
# ---------------------------------------------------------------------------
def _b64u_dec(s):
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def make_token(act_secret, kid, device, slot, max_boards):
    """Activation-service side (also used by tests): token = base64url(signature + payload)."""
    payload = ("A|%s|%s|%d|%d|%d" % (kid, device, slot, max_boards, int(time.time()))).encode()
    return base64.urlsafe_b64encode(sign(act_secret, payload) + payload).decode().rstrip("=")


def check_token(token, kid, device, public_hex=None):
    """Board side: True if this activation token was issued by LL3D for this key on this board."""
    pub = public_hex or ACTIVATION_PUBLIC_KEY_HEX
    try:
        blob = _b64u_dec(token)
        sig, payload = blob[:64], blob[64:]
        if not verify_sig(bytes.fromhex(pub), payload, sig):
            return None
        f = payload.decode().split("|")
        if f[0] != "A" or f[1] != kid or f[2] != device:
            return None
        return {"slot": int(f[3]), "max": int(f[4]), "t": int(f[5])}
    except Exception:
        return None


def board_id(data_dir):
    """A random ID for this board, made once and kept in data/device.json (never hardware details)."""
    path = os.path.join(data_dir, "device.json")
    try:
        with open(path) as f:
            d = json.load(f).get("id", "")
        if len(d) == 20:
            return d
    except Exception:
        pass
    d = secrets.token_hex(10)
    try:
        with open(path, "w") as f:
            json.dump({"id": d}, f)
    except Exception:
        pass
    return d


def _act_call(action, body, timeout=20):
    """POST to LL3D's activation service. Returns (http_status, json) or raises OSError when offline."""
    import urllib.request
    import urllib.error
    req = urllib.request.Request(ACTIVATION_URL.rstrip("/") + "/" + action, data=json.dumps(body).encode(),
                                 headers={"Content-Type": "application/json", "User-Agent": "CrashBoard"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, json.loads(r.read().decode() or "{}")
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read().decode() or "{}")
        except Exception:
            return e.code, {}


FULL_MSG = ("This key is already active on %d boards (the limit). On one of those boards open CFG > PRO > "
            "RELEASE THIS BOARD, then try again here. Lost a board? Contact LL3D to free its slot.")
OFFLINE_MSG = "Key saved. This board needs the internet once to activate it - it will activate by itself as soon as it's online."


class License:
    """Holds this board's license, saved in data/license.json (the last ban list in data/banlist.json)."""

    def __init__(self, data_dir, log=print):
        self.path = os.path.join(data_dir, "license.json")
        self.ban_path = os.path.join(data_dir, "banlist.json")
        self.data_dir = data_dir
        self.log = log
        self.rec, self.key, self.banned = None, "", False
        self.token, self.act, self.act_error, self.grace_until = "", None, "", 0
        self.device = board_id(data_dir)
        self.bans = self._load_bans()
        saved = {}
        try:
            with open(self.path) as f:
                saved = json.load(f)
            self.key = saved.get("key", "")
            if self.key:
                self.rec = check_key(self.key)
                self.banned = is_banned(self.rec, self.bans)
        except ValueError as e:
            self.log("license: saved key rejected:", e)
            self.rec = None
        except Exception:
            pass
        if self.rec:
            self.token = saved.get("act", "")
            self.act = check_token(self.token, self.rec["id"], self.device) if self.token else None
            if self.limit_on() and not self.act:
                if "act" not in saved and "pending" not in saved:
                    # a key activated before the board limit existed: keep PRO for 14 days while it activates
                    self.grace_until = int(saved.get("grace_until") or time.time() + 14 * 86400)
                else:
                    self.grace_until = int(saved.get("grace_until") or 0)
                self._save()

    @staticmethod
    def limit_on():
        return bool(ACTIVATION_URL and ACTIVATION_PUBLIC_KEY_HEX)

    @property
    def pending(self):
        return bool(self.rec and self.limit_on() and not self.act)

    @property
    def pro(self):
        if not (self.rec and self.rec.get("t") == "pro" and not self.banned):
            return False
        return (not self.pending) or time.time() < self.grace_until

    def activate(self, key):
        rec = check_key(key)                       # raises ValueError with a friendly message
        if is_banned(rec, self.bans):
            raise ValueError(BANNED_MSG)
        if self.limit_on():
            if self.rec and self.rec.get("id") != rec["id"] and self.act:
                self.release(quiet=True)           # swapping keys: give the old key's slot back
            try:
                ok, msg = self._activate_online(rec, key.strip())
            except OSError:
                self.rec, self.key, self.banned, self.token, self.act = rec, key.strip(), False, "", None
                self.grace_until, self.act_error = 0, OFFLINE_MSG
                self._save()
                return rec
            if not ok:
                raise ValueError(msg)
        self.rec, self.key, self.banned = rec, key.strip(), False
        self.act_error = ""
        self._save()
        return rec

    def _activate_online(self, rec, key):
        """Ask the activation service for this board's slot. Raises OSError if it can't be reached."""
        label = os.environ.get("CRASHBOARD_BOARD_LABEL") or __import__("platform").node()[:24] or "board"
        code, d = _act_call("activate", {"key": key, "device": self.device, "label": label})
        if code == 200 and d.get("ok"):
            info = check_token(d.get("token", ""), rec["id"], self.device)
            if not info:
                return False, "Activation reply could not be verified. Update Crash Board and try again."
            self.token, self.act = d["token"], info
            self.grace_until = 0
            return True, ""
        if d.get("error") == "full":
            return False, FULL_MSG % int(d.get("max") or MAX_BOARDS)
        if d.get("error") == "banned":
            return False, BANNED_MSG
        if code >= 500 or not d:
            raise OSError("activation service error %s" % code)
        return False, d.get("message") or "Activation refused (%s)" % (d.get("error") or code)

    def retry_activation(self):
        """Called in the background while a key waits for its first online activation."""
        if not self.pending:
            return False
        try:
            ok, msg = self._activate_online(self.rec, self.key)
        except Exception as e:
            self.log("license: still waiting to activate (offline?):", str(e)[:80])
            return False
        if ok:
            self.act_error = ""
            self.log("license: activated online (board %d of %d)" % (self.act["slot"], self.act["max"]))
        else:
            self.act_error = msg
            self.log("license: activation refused:", msg)
        self._save()
        return ok

    def release(self, quiet=False):
        """Free this board's slot on LL3D's service, then remove the key here. Needs internet when the limit is on."""
        if self.limit_on() and self.rec and self.act:
            try:
                code, d = _act_call("release", {"key": self.key, "device": self.device})
            except OSError:
                if quiet:
                    return False
                raise ValueError("Releasing needs the internet (so the slot can be freed). Connect and try again, "
                                 "or use REMOVE WITHOUT RELEASING.")
            if code != 200 and not quiet:
                raise ValueError(d.get("message") or "Release failed (%s)" % code)
        self.remove()
        return True

    def remove(self):
        self.rec, self.key, self.banned = None, "", False
        self.token, self.act, self.act_error, self.grace_until = "", None, "", 0
        self._save()

    def _save(self):
        tmp = self.path + ".tmp"
        d = {"key": self.key}
        if self.limit_on() and self.key:
            d["act"] = self.token
            if self.pending:
                d["pending"] = True
                d["grace_until"] = self.grace_until
        with open(tmp, "w") as f:
            json.dump(d, f)
        os.replace(tmp, self.path)

    # ---- ban list
    def _load_bans(self):
        try:
            with open(self.ban_path) as f:
                b = json.load(f)
            return b if check_ban_list(b) else {}
        except Exception:
            return {}

    def check_bans(self, url=None, timeout=15):
        """Fetch LL3D's ban list (if a URL is set). Never blocks PRO when offline or when the list is unreachable."""
        url = url if url is not None else BAN_LIST_URL
        if not url:
            return None
        import urllib.request
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "CrashBoard", "Cache-Control": "no-cache"})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                b = json.loads(r.read().decode("utf-8"))
        except Exception as e:
            self.log("license: ban list not reachable (that's fine):", e)
            return None
        if not check_ban_list(b):
            self.log("license: ban list ignored (signature not valid)")
            return None
        if b.get("issued", "") < self.bans.get("issued", ""):
            return None                            # never go back to an older list
        self.bans = b
        tmp = self.ban_path + ".tmp"
        with open(tmp, "w") as f:
            json.dump(b, f)
        os.replace(tmp, self.ban_path)
        was = self.banned
        self.banned = is_banned(self.rec, b)
        if self.banned and not was:
            self.log("license: this board's PRO key was cancelled by LL3D (order %s)" % (self.rec or {}).get("o"))
        return self.banned

    def info(self):
        r = self.rec or {}
        masked = (self.key[:8] + "…" + self.key[-5:]) if self.key else ""
        act = self.act or {}
        return {"tier": "pro" if self.pro else "free", "order": r.get("o"), "name": r.get("n", ""),
                "issued": r.get("d"), "expires": r.get("x"), "key": masked, "banned": self.banned,
                "banned_msg": BANNED_MSG if self.banned else "",
                "limit": self.limit_on(), "pending": self.pending, "act_msg": self.act_error,
                "grace_until": self.grace_until if self.pending else 0,
                "board": act.get("slot"), "max_boards": act.get("max") or MAX_BOARDS,
                "free_themes": list(FREE_THEMES), "features": PRO_FEATURES}

    def allows_theme(self, theme):
        return self.pro or theme in FREE_THEMES
