#!/usr/bin/env python3
"""CRASH BOARD screen for the Pi Zero / Pi 1.

A web browser is too heavy for these boards, so this draws the board straight onto the screen
(the Linux framebuffer, /dev/fb0) with Pillow. It reads the same /api/state the web board uses,
so all data, alerts, colour schemes and languages match. Also draws the first-time setup screen
(QR codes) on SD-card images.

  python3 zero/fbboard.py                 run on the attached screen (started from ~/.bash_profile)
  CB_FB_OUT=x.png CB_FB_SIZE=1280x720 python3 zero/fbboard.py --once     render one frame to a PNG
"""
import json, math, os, re, sys, threading, time, urllib.request
from PIL import Image, ImageChops, ImageColor, ImageDraw, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(APP, "setup"))
DATA = os.path.join(APP, "data")
MESH = os.path.basename(APP.rstrip("/")) == "crashboard-mesh"     # legacy Mesh folder (Mesh is built into every board now)
SETUP_STATUS = os.environ.get("CB_SETUP_STATUS", "/run/crashboard-setup/status.json")
ONCE = "--once" in sys.argv
STATE_URL = os.environ.get("CB_STATE_URL")
HOST_URL, HOST_EDITION = "", ""        # DISPLAY mode: show a Crash Board hosted on another device
try:
    _conf = open(os.path.join(DATA, "display.conf")).read()
    _host = re.search(r'HOST_URL="?([^"\n]+)', _conf)
    _ed = re.search(r'HOST_EDITION="?([a-z-]+)', _conf)
    HOST_EDITION = _ed.group(1) if _ed else ""
    if _host and not STATE_URL:
        HOST_URL = _host.group(1).strip().rstrip("/")
        STATE_URL = HOST_URL + "/api/state"
except OSError:
    pass


def set_host(url):
    """Point this screen at a (new) board address. Called by the LINK menu and the auto-finder."""
    global HOST_URL, STATE_URL
    HOST_URL = url.rstrip("/")
    STATE_URL = HOST_URL + "/api/state"

# ------------------------------------------------------------------ colour schemes (match style.css)
BASE = dict(bg="#0a0c08", panel="#13170f", panel2="#171c12", line="#2c3523", line2="#3d4a2e", olive="#56693a",
            khaki="#b9b38a", text="#cdd6b4", dim="#7f8a6b", faint="#4f5842", green="#8fd65a", amber="#ffb22e",
            orange="#ff7a1a", red="#ff3b2f", yellow="#f2d23c", cyan="#6fd3c7", ink="#0b0d08", clock="#8fd65a",
            hot="#ffb22e", ok="#8fd65a", sev1="#f2d23c", sev2="#ff7a1a", sev3="#ff3b2f",
            map_bg="#0c100a", map_grid="#1f2818", map_land="#1d2616", map_coast="#3b4a2c")
THEMES = {
    "ops": {},
    "blackout": dict(bg="#050505", panel="#101010", panel2="#161616", line="#262626", line2="#383838", olive="#fc6e08",
                     khaki="#f2ebe3", text="#e3e3e3", dim="#8a8a8a", faint="#525252", ink="#050505", clock="#ff8a1f",
                     hot="#ff8a1f", map_bg="#080808", map_grid="#1a1a1a", map_land="#1b1b1b", map_coast="#5a3112"),
    "hazard": dict(bg="#c9500a", panel="#ee761d", panel2="#ff8a30", line="#a8460a", line2="#1a1a1a", olive="#111111",
                   khaki="#0a0a0a", text="#111111", dim="#4f2608", faint="#87400c", ink="#ff8a30", clock="#000000",
                   hot="#000000", ok="#174d08", sev1="#5c3300", sev2="#000000", sev3="#8f0000",
                   map_bg="#141414", map_grid="#262626", map_land="#272727", map_coast="#5e5e5e"),
    "coyote": dict(bg="#17130d", panel="#241e15", panel2="#2c241a", line="#43382a", line2="#5c4b36", olive="#a07d4f",
                   khaki="#dcc59e", text="#ebdec5", dim="#a39072", faint="#6a5a41", ink="#17130d", clock="#e3b86e",
                   hot="#e6a94c", map_bg="#120e09", map_grid="#2a2218", map_land="#2c2419", map_coast="#614f36"),
    "vault": dict(bg="#0a1730", panel="#11264b", panel2="#15305c", line="#22437a", line2="#335f9e", olive="#f5c518",
                  khaki="#ffd84a", text="#e4ebf7", dim="#91a8cc", faint="#4f6992", ink="#0a1730", clock="#ffd84a",
                  hot="#ffd23f", map_bg="#06122a", map_grid="#12294d", map_land="#10284d", map_coast="#2f5c99"),
    "cva": dict(bg="#170d06", panel="#26160b", panel2="#2f1b0d", line="#553114", line2="#77461c", olive="#d9731a",
                khaki="#f4b35a", text="#f6c47c", dim="#b07a3c", faint="#734c24", ink="#170d06", clock="#ffb347",
                hot="#ff9d33", map_bg="#100904", map_grid="#2c190a", map_land="#2b170a", map_coast="#7d4b1e"),
    "halloween": dict(bg="#0b0610", panel="#170c1f", panel2="#1f1029", line="#3a1f4a", line2="#58306c", olive="#ff7518",
                      khaki="#ff9a3c", text="#f1e6d6", dim="#a88fb8", faint="#5f4672", ink="#0b0610", clock="#9dff3a",
                      hot="#ff7518", ok="#9dff3a", map_bg="#0a0510", map_grid="#22122c", map_land="#2c1840", map_coast="#9a58c4"),
    # night vision: dim blue-green only, brighter = worse (red/orange/white flare in NVG tubes)
    "nvg": dict(bg="#000000", panel="#020805", panel2="#03100a", line="#0a2416", line2="#0f3520", olive="#0d4a2b",
                khaki="#38b677", text="#2a9a61", dim="#1c6a43", faint="#0f4129", green="#1f8a55", amber="#3fbf7f",
                orange="#6ee0a6", red="#b4ffd8", yellow="#3fbf7f", cyan="#2a9a61", ink="#000000", clock="#38b677",
                hot="#6ee0a6", ok="#1f8a55", sev1="#3fbf7f", sev2="#6ee0a6", sev3="#b4ffd8",
                map_bg="#000000", map_grid="#04140b", map_land="#041a0e", map_coast="#0f4a2b"),
    "lab": dict(bg="#08080a", panel="#111114", panel2="#18181c", line="#2a2a30", line2="#44444c", olive="#c8102e",
                khaki="#f4f4f6", text="#d9d9de", dim="#8e8e98", faint="#55555e", ink="#ffffff", clock="#f4f4f6",
                hot="#e3263f", map_bg="#060607", map_grid="#18181c", map_land="#1a1a1f", map_coast="#7a1c2a"),
}
C = dict(BASE)


def set_theme(name):
    C.clear(); C.update(BASE); C.update(THEMES.get(name or "ops", {}))


# ------------------------------------------------------------------ fonts
FONT_DIRS = ["/usr/share/fonts/truetype/dejavu", "/usr/share/fonts/dejavu", "/usr/share/fonts/TTF"]
_fonts = {}


def font(kind, size):
    size = max(8, int(size))
    key = (kind, size)
    if key not in _fonts:
        name = {"mono": "DejaVuSansMono.ttf", "monob": "DejaVuSansMono-Bold.ttf",
                "head": "DejaVuSansCondensed-Bold.ttf", "sans": "DejaVuSansCondensed.ttf"}[kind]
        f = None
        for d in FONT_DIRS:
            p = os.path.join(d, name)
            if os.path.exists(p):
                f = ImageFont.truetype(p, size); break
        _fonts[key] = f or ImageFont.load_default()
    return _fonts[key]


# ------------------------------------------------------------------ translations (same table as the web board)
class Lang:
    EN_DIR = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"]

    def __init__(self):
        self.d, self.cur, self.re, self.L = {}, "en", None, None
        try:
            src = open(os.path.join(APP, "static", "i18n.js"), encoding="utf-8").read()
            self.d = json.loads(src[src.index("{"):src.rindex("}") + 1])
        except (OSError, ValueError):
            pass

    def set(self, lang):
        if lang == self.cur:
            return
        self.cur = lang if lang in self.d.get("langs", {}) else "en"
        self.L = self.d["langs"][self.cur] if self.cur != "en" else None
        if self.L:
            keys = sorted(self.L["map"], key=len, reverse=True)
            self.re = re.compile("(^|[^A-Za-z0-9À-ÿ])(" + "|".join(re.escape(k) for k in keys) + ")(?=[^A-Za-z0-9À-ÿ]|$)")

    def t(self, s):
        if not self.L or not s:
            return s
        s = re.sub(r"(\d+[SMHD](?: \d+[SMHD])?|--) AGO\b", lambda m: self.L["ago"].replace("{t}", m.group(1)), s)
        return self.re.sub(lambda m: m.group(1) + self.L["map"][m.group(2)], s)

    def mon(self, i):
        return (self.L or {}).get("mon", ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"])[i]

    def dow(self, i):
        return (self.L or {}).get("dow", ["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"])[i]

    def dir(self, d):
        if d in self.EN_DIR and self.L:
            return self.L["dir"][self.EN_DIR.index(d)]
        return d


LANG = Lang()
T = LANG.t


# ------------------------------------------------------------------ framebuffer
class Screen:
    def __init__(self):
        self.out = os.environ.get("CB_FB_OUT")
        if self.out:
            w, h = (os.environ.get("CB_FB_SIZE") or "1280x720").split("x")
            self.w, self.h, self.bpp, self.stride, self.fb = int(w), int(h), 32, int(w) * 4, None
            return
        sysd = os.environ.get("CB_FB_SYSDIR", "/sys/class/graphics/fb0")
        self.w, self.h = [int(v) for v in open(sysd + "/virtual_size").read().strip().split(",")]
        self.bpp = int(open(sysd + "/bits_per_pixel").read().strip())
        try:
            self.stride = int(open(sysd + "/stride").read().strip())
        except OSError:
            self.stride = self.w * self.bpp // 8
        self.fb = open(os.environ.get("CB_FB_DEV", "/dev/fb0"), "r+b", buffering=0)
        self.graphics_mode(True)

    def graphics_mode(self, on):
        """Stop the text console drawing its cursor/text over the board (KDSETMODE)."""
        try:
            import fcntl
            with open("/dev/tty", "wb") as tty:
                fcntl.ioctl(tty, 0x4B3A, 1 if on else 0)
        except OSError:
            sys.stdout.write("\033[?25l\033[2J"); sys.stdout.flush()

    def raw(self, img):
        if self.bpp == 32:
            return img.tobytes("raw", "BGRX")
        if self.bpp == 16:                                   # RGB565, built with fast per-channel lookups
            r, g, b = img.split()
            hi = ImageChops.add(r.point(lambda v: v & 0xF8), g.point(lambda v: v >> 5))
            lo = ImageChops.add(g.point(lambda v: (v & 0x1C) << 3), b.point(lambda v: v >> 3))
            return Image.merge("LA", (lo, hi)).tobytes()
        if self.bpp == 24:
            return img.tobytes("raw", "BGR")
        raise SystemExit("unsupported framebuffer depth %d" % self.bpp)

    def show(self, img, box=None):
        if self.out:
            img.save(self.out); return
        box = box or (0, 0, self.w, self.h)
        x0, y0, x1, y1 = box
        data = self.raw(img.crop(box))
        rowlen = (x1 - x0) * self.bpp // 8
        if x0 == 0 and x1 == self.w and rowlen == self.stride:
            self.fb.seek(y0 * self.stride); self.fb.write(data); return
        for i in range(y1 - y0):
            self.fb.seek((y0 + i) * self.stride + x0 * self.bpp // 8)
            self.fb.write(data[i * rowlen:(i + 1) * rowlen])

    def close(self):
        if self.fb:
            self.graphics_mode(False)


# ------------------------------------------------------------------ drawing helpers
def hexc(c):
    c = c.lstrip("#"); return tuple(int(c[i:i + 2], 16) for i in (0, 2, 4))


def tw(d, s, f):
    return d.textlength(s, font=f)


def fit(d, s, f, w):
    s = str(s or "")
    if tw(d, s, f) <= w:
        return s
    while s and tw(d, s + "…", f) > w:
        s = s[:-1]
    return s.rstrip() + "…"


def wrap(d, s, f, w, lines):
    words, out, cur = str(s or "").split(), [], ""
    for wd in words:
        nxt = (cur + " " + wd).strip()
        if tw(d, nxt, f) <= w:
            cur = nxt
        else:
            if cur:
                out.append(cur)
            cur = wd
            if len(out) == lines:
                break
    if cur and len(out) < lines:
        out.append(cur)
    if len(out) == lines and " ".join(out) != " ".join(words):
        out[-1] = fit(d, out[-1] + " …", f, w)
    return out



def v1_badge(d, x, cy, size, col=None):
    """Boxed 'V1' version tag drawn after the CRASH BOARD wordmark; returns its width."""
    col = col or C["khaki"]
    f = font("head", size)
    tw = d.textlength("V1", font=f)
    px, py = size * 0.32, size * 0.2
    w = tw + 2 * px
    d.rectangle([x, cy - size * 0.5 - py, x + w, cy + size * 0.5 + py], outline=col, width=max(1, int(size / 9)))
    d.text((x + w / 2, cy + size * 0.04), "V1", font=f, fill=col, anchor="mm")
    return w


def spaced(d, xy, s, f, fill, sp, anchor="la"):
    """Letter-spaced text (the board's military headings)."""
    x, y = xy
    total = sum(tw(d, ch, f) for ch in s) + sp * max(0, len(s) - 1)
    if anchor[0] == "m":
        x -= total / 2
    elif anchor[0] == "r":
        x -= total
    for ch in s:
        d.text((x, y), ch, font=f, fill=fill, anchor="l" + anchor[1])
        x += tw(d, ch, f) + sp
    return total


def ago(ts, now):
    if not ts:
        return "--"
    s = max(0, now - ts)
    if s < 60: return "%dS" % s
    if s < 3600: return "%dM" % (s // 60)
    if s < 86400: return "%dH %dM" % (s // 3600, (s % 3600) // 60)
    return "%dD %dH" % (s // 86400, (s % 86400) // 3600)


def zulu(ts):
    if not ts:
        return "--"
    t = time.gmtime(ts)
    return "%02d %02d%02dZ" % (t.tm_mday, t.tm_hour, t.tm_min)


def r0(v):
    return "--" if v is None else str(int(round(v)))


def level_color(level):
    return [C["green"], C["yellow"], C["orange"], C["red"]][max(0, min(3, int(level or 0)))]


def sev_color(rank):
    return {3: C["sev3"], 2: C["sev2"], 1: C["sev1"]}.get(rank, C["faint"])


# The real Crash Board shield (traced from static/icon.svg, 1000-unit box). Keep it in sync with the icon.
LOGO = {"w":1000.0,"h":959.4,"outer":[[500,920],[38,472],[38,176],[177,39],[823,38],[962,176],[962,472]],"hole":[[501,856],[913,453],[913,192],[807,86],[193,86],[87,192],[87,453]],"parts":[[[42,129],[40,131],[38,129],[38,62],[62,38],[131,39],[120,52]],[[962,134],[867,40],[938,38],[950,50],[962,62]],[[500,548],[237,548],[193,503],[198,501],[808,501],[762,547]],[[501,778],[403,686],[452,582],[549,582],[598,686]]]}


def shield(d, cx, cy, h, color, fill=None):
    """The Crash Board shield badge (no text), drawn from the real logo outline, anti-aliased."""
    k = h / LOGO["h"]
    w = LOGO["w"] * k
    ss = 4
    tw, th = int(w + 4), int(h + 4)
    tile = Image.new("RGBA", (tw * ss, th * ss), (0, 0, 0, 0))
    g = ImageDraw.Draw(tile)
    pts = lambda p: [((x * k + 2) * ss, (y * k + 2) * ss) for x, y in p]
    col = ImageColor.getrgb(color)[:3] if isinstance(color, str) else tuple(color[:3])
    g.polygon(pts(LOGO["outer"]), fill=col + (255,))
    g.polygon(pts(LOGO["hole"]), fill=(19, 19, 19, 255))          # the logo's own dark interior
    for p in LOGO["parts"]:
        g.polygon(pts(p), fill=col + (255,))
    tile = tile.resize((tw, th), Image.LANCZOS)
    base = getattr(d, "_image", None)
    pos = (int(round(cx - w / 2 - 2)), int(round(cy - h / 2 - 2)))
    if base is not None:
        if base.mode == "RGBA":
            base.alpha_composite(tile, pos)
        else:
            base.paste(tile, pos, tile)


def stripes(img, box, color, step):
    """Hazard stripes, clipped to the box."""
    x0, y0, x1, y1 = [int(v) for v in box]
    w, h = x1 - x0, y1 - y0
    tile = Image.new("RGB", (w, h), C["bg"])
    td = ImageDraw.Draw(tile)
    x = -h
    while x < w:
        td.polygon([(x, h), (x + step / 2, h), (x + step / 2 + h, 0), (x + h, 0)], fill=color)
        x += step
    img.paste(tile, (x0, y0))


# ------------------------------------------------------------------ world map
class WorldMap:
    def __init__(self):
        self.polys, self.mtime, self.cache, self.next_try = [], 0, {}, 0

    def fetch(self, p):
        """No map saved on this Pi yet (DISPLAY mode: the board runs on another device).
        Copy it from that board's /api/map, so the coastlines show. Retries every 2 minutes."""
        if not HOST_URL or time.time() < self.next_try:
            return
        self.next_try = time.time() + 120
        try:
            d = urllib.request.urlopen(HOST_URL + "/api/map", timeout=15).read().decode("utf-8", "ignore")
            if d.startswith("M") and len(d) > 1000:
                with open(p + ".tmp", "w") as f:
                    f.write(d)
                os.replace(p + ".tmp", p)
        except (OSError, ValueError):
            pass

    def load(self):
        p = os.path.join(DATA, "land.svgpath")
        if not os.path.exists(p):
            self.fetch(p)
        try:
            m = os.path.getmtime(p)
        except OSError:
            return
        if m == self.mtime:
            return
        self.mtime, self.polys, self.cache = m, [], {}
        cur = []
        for cmd, x, y in re.findall(r"([MLZ])\s*(?:(-?[\d.]+)[ ,]+(-?[\d.]+))?", open(p).read()):
            if cmd == "M":
                if len(cur) > 2:
                    self.polys.append(cur)
                cur = [(float(x), float(y))]
            elif cmd == "L":
                cur.append((float(x), float(y)))
            elif cmd == "Z":
                if len(cur) > 2:
                    self.polys.append(cur)
                cur = []

    def base(self, w, h):
        key = (w, h, C["map_bg"], C["map_land"])
        if key not in self.cache:
            im = Image.new("RGB", (w, h), C["map_bg"])
            d = ImageDraw.Draw(im)
            sx, sy = w / 360.0, h / 180.0
            for gx in range(0, 361, 30):
                d.line([(gx * sx, 0), (gx * sx, h)], fill=C["map_grid"])
            for gy in range(0, 181, 30):
                d.line([(0, gy * sy), (w, gy * sy)], fill=C["map_coast"] if gy == 90 else C["map_grid"])
            for poly in self.polys:
                d.polygon([(x * sx, y * sy) for x, y in poly], fill=C["map_land"], outline=C["map_coast"])
            self.cache = {key: im}
        return self.cache[key]


WORLD = WorldMap()


# ------------------------------------------------------------------ board
class Board:
    def __init__(self, scr):
        self.scr, self.state, self.ok, self.page, self.tick_i = scr, None, False, 0, 0
        self.frame, self.last_seq, self.flash, self.flash_until = None, None, [], 0

    # ---- data
    def port(self):
        try:
            return int(open(os.path.join(DATA, "port.txt")).read().strip())
        except (OSError, ValueError):
            return 8090 if MESH else 8080

    def poll(self):
        url = STATE_URL or "http://127.0.0.1:%d/api/state" % self.port()
        try:
            self.state = json.loads(urllib.request.urlopen(url, timeout=10).read())
            self.ok = True
            self.skew = self.state.get("server_time", time.time()) - time.time()
            cfg = self.state.get("config", {})
            set_theme(cfg.get("theme"))
            LANG.set(cfg.get("lang") or "en")
            self.events()
        except Exception:
            self.ok = False

    def events(self):
        seq = self.state.get("event_seq")
        evs = self.state.get("events") or []
        if self.last_seq is not None and seq != self.last_seq:
            new = [e for e in evs if (e.get("seq") or 0) > self.last_seq and (e.get("sev") or 0) >= 3]
            if new:
                self.flash, self.flash_until = new[-3:], time.time() + 45
        self.last_seq = seq

    def feed(self, name):
        return ((self.state or {}).get("feeds") or {}).get(name) or {}

    def data(self, name):
        return self.feed(name).get("data")

    def now(self):
        return time.time() + getattr(self, "skew", 0)

    # ---- layout
    def render(self):
        W, H = self.scr.w, self.scr.h
        self.small = W < 1000 or H < 560          # small screens (7"): one big panel at a time
        s = min(W / 860.0, H / 520.0) if self.small else min(W / 1280.0, H / 720.0)
        self.s = s
        img = Image.new("RGB", (W, H), C["bg"])
        self.img = img
        d = ImageDraw.Draw(img)
        g = max(4, int(8 * s))
        top = int(66 * s)
        self.header(img, d, (0, 0, W, top))
        bh = int(48 * s)
        self.banner(d, (g, top + g, W - g, top + g + bh))
        tk = int(34 * s)
        y0, y1 = top + 2 * g + bh, H - tk - 2 * g
        if self.small:
            panels = [self.p_seismic, self.p_weather, self.p_alerts, self.p_defcon, self.p_fire, self.p_outbreaks, self.p_space]
            fn = panels[self.page % len(panels)]
            fn(img, d, (g, y0, W - g, y1 - int(10 * s)))
            n = len(panels); dw = int(18 * s)
            for i in range(n):                        # pager dashes
                x = W / 2 - n * dw / 2 + i * dw
                d.rectangle((x + 2, y1 - int(4 * s), x + dw - 4, y1), fill=C["green"] if i == self.page % n else C["line2"])
        else:
            cols = 4
            cw = (W - g * (cols + 1)) / cols
            rh = (y1 - y0 - g) / 2
            def cell(c, r, span=1):
                x = g + c * (cw + g)
                return (int(x), int(y0 + r * (rh + g)), int(x + span * cw + (span - 1) * g), int(y0 + r * (rh + g) + rh))
            self.p_defcon(img, d, cell(0, 0))
            self.p_seismic(img, d, cell(1, 0, 2))
            self.p_weather(img, d, cell(3, 0))
            self.p_outbreaks(img, d, cell(0, 1))
            self.p_fire(img, d, cell(1, 1))
            self.p_alerts(img, d, cell(2, 1))
            self.p_space(img, d, cell(3, 1))
        self.tick_box = (g, H - tk - g, W - g, H - g)
        self.ticker(d)
        if self.flash and time.time() < self.flash_until:
            self.flash_box(d, W, H)
        self.frame = img
        return img

    def header(self, img, d, box):
        x0, y0, x1, y1 = box
        s = self.s
        d.rectangle(box, fill=C["panel"]); d.line([(x0, y1 - 1), (x1, y1 - 1)], fill=C["line2"], width=max(1, int(2 * s)))
        cs = (self.state or {}).get("config", {}).get("callsign") or "CRASH BOARD"
        a, b = (cs.split(" ", 1) + [""])[:2] if " " in cs.strip() else ("", cs)
        hf = font("head", 30 * s)
        cy = y0 + (y1 - y0) * 0.42
        cx = (x0 + x1) / 2
        sp = 7 * s
        shield(d, cx, cy, 34 * s, C["orange"], C["bg"])
        if a:
            spaced(d, (cx - 30 * s, cy), a.upper(), hf, C["khaki"], sp, "rm")
            bw = spaced(d, (cx + 30 * s, cy), b.upper(), hf, C["khaki"], sp, "lm")
        else:
            bw = spaced(d, (cx + 30 * s, cy), b.upper(), hf, C["khaki"], sp, "lm")
        if cs.strip().upper() == "CRASH BOARD":             # trademark on the brand name, not on a custom callsign
            d.text((cx + 30 * s + bw + 3 * s, cy - 9 * s), "\u2122", font=font("head", 13 * s), fill=C["khaki"], anchor="lm")
            v1_badge(d, cx + 30 * s + bw + 20 * s, cy, 13 * s)
        sub = T("GLOBAL THREAT MONITOR") + (" · MESH" if MESH else "")
        spaced(d, (cx, y1 - 12 * s), sub, font("mono", 10 * s), C["dim"], 3 * s, "mm")
        # status on the right
        lf = font("monob", 13 * s)
        setup = (self.state or {}).get("setup")
        txt, col = ("● " + T("NO WI-FI"), C["red"]) if setup else (("● " + T("LINK"), C["green"]) if self.ok else ("● " + T("NO LINK"), C["red"]))
        d.text((x1 - 16 * s, cy), txt, font=lf, fill=col, anchor="rm")
        lic = ((self.state or {}).get("license") or {}).get("tier") == "pro"
        ver = "v" + str((self.state or {}).get("version", "")) + (" PRO" if lic else "")
        if getattr(self, "hint", False):
            ver = T("W: WI-FI") + "   " + (T("L: LINK") + "   " if HOST_URL or not self.ok else "") + ver
        d.text((x1 - 16 * s, y1 - 12 * s), ver, font=font("mono", 10 * s), fill=C["faint"], anchor="rm")
        self.clock_box = (x0 + int(10 * s), y0 + int(6 * s), x0 + int((265 if self.small else 470) * s), y1 - int(6 * s))
        self.clock(d)

    def clock(self, d):
        x0, y0, x1, y1 = self.clock_box
        s = self.s
        d.rectangle(self.clock_box, fill=C["panel"])
        lt, ut = time.localtime(), time.gmtime()
        vals = [(T("LOCAL"), time.strftime("%H:%M:%S", lt), C["clock"]), ("ZULU", time.strftime("%H:%M:%SZ", ut), C["clock"]),
                (T("DATE"), "%02d %s %d" % (lt.tm_mday, LANG.mon(lt.tm_mon - 1), lt.tm_year), C["text"])]
        x = x0
        lf, vf = font("mono", 10 * s), font("monob", 21 * s)
        if getattr(self, "small", False):
            vals = vals[:2]
        for lbl, v, col in vals:
            spaced(d, (x, y0 + 8 * s), lbl, lf, C["dim"], 2 * s, "lm")
            d.text((x, y1 - 14 * s), v, font=vf, fill=col, anchor="lm")
            x += tw(d, v, vf) + 26 * s

    def banner(self, d, box):
        x0, y0, x1, y1 = box
        s = self.s
        c = (self.state or {}).get("condition") or {"level": 0, "name": "--", "reasons": []}
        halves = [("LOCAL", c.get("local") or {"level": 0, "name": "GREEN", "reasons": []}),
                  ("GLOBAL", c.get("global") or c)]
        gap = int(6 * s)
        mid = (x0 + x1) // 2
        for i, (label, h) in enumerate(halves):
            bx0, bx1 = (x0, mid - gap // 2) if i == 0 else (mid + gap // 2, x1)
            self.banner_half(d, (bx0, y0, bx1, y1), label, h)

    def banner_half(self, d, box, label, c):
        x0, y0, x1, y1 = box
        s = self.s
        lvl = c.get("level", 0) or 0
        col = level_color(lvl)
        d.rectangle(box, fill=C["panel"], outline=col if lvl >= 1 else C["line"], width=max(1, int(2 * s)))
        sw = int(22 * s)
        if lvl >= 1:
            stripes(self.img, (x0 + 2, y0 + 2, x0 + sw, y1 - 2), col, int(12 * s))
        cy = (y0 + y1) / 2
        x = x0 + sw + 10 * s
        x += spaced(d, (x, cy), T(label), font("mono", 10 * s), col if lvl >= 1 else C["dim"], 2 * s, "lm") + 10 * s
        nm = T(c.get("name") or "--")
        x += spaced(d, (x, cy), nm, font("head", 22 * s), col, 4 * s, "lm") + 14 * s
        rs = [T(r[7:] if str(r).startswith("LOCAL: ") else r) for r in c.get("reasons") or []]
        reasons = "  //  ".join(rs) or T("NO SIGNIFICANT THREATS DETECTED")
        f = font("mono", 12 * s)
        if x1 - 10 * s - x > 30 * s:
            d.text((x, cy), fit(d, reasons, f, x1 - 10 * s - x), font=f, fill=C["text"], anchor="lm")

    def ticker_items(self):
        st, bits = self.state or {}, []
        if st.get("setup"):
            bits.append(T("NO WI-FI") + ": " + T("JOIN") + " " + st["setup"]["ap"] + " " + T("ON YOUR PHONE TO PICK A NETWORK"))
        q = self.data("quakes")
        if q and q.get("events"):
            e = q["events"][0]
            bits.append(T("LATEST") + " M%.1f %s · %s" % (e["mag"], str(e.get("place", "")).upper(), T(ago(e.get("time"), self.now()) + " AGO")))
        for n in (self.data("news") or {}).get("items", [])[:4]:
            bits.append("%s: %s" % (n.get("src", ""), str(n.get("title", "")).upper()))
        for e in (self.data("gdacs") or {}).get("events", [])[:3]:
            bits.append("GDACS %s %s: %s" % (e.get("level", ""), e.get("type", ""), str(e.get("title", "")).upper()))
        for e in (self.data("tsunami") or {}).get("events", [])[:2]:
            bits.append("%s %s: %s" % (T("TSUNAMI"), e.get("level", ""), str(e.get("title", "")).upper()))
        dd = st.get("config", {}).get("doomsday") or {}
        if dd.get("seconds"):
            bits.append("%s %s SEC %s" % (T("DOOMSDAY CLOCK"), dd["seconds"], T("TO MIDNIGHT")))
        return bits or [T("AWAITING FEEDS…")]

    def ticker(self, d):
        x0, y0, x1, y1 = self.tick_box
        s = self.s
        d.rectangle(self.tick_box, fill=C["panel"], outline=C["line"])
        lw = int(80 * s)
        d.rectangle((x0, y0, x0 + lw, y1), fill=C["amber"])
        spaced(d, (x0 + lw / 2, (y0 + y1) / 2), "FLASH", font("monob", 12 * s), C["ink"], 3 * s, "mm")
        items = self.ticker_items()
        txt = "◆ " + items[self.tick_i % len(items)]
        f = font("monob", 14 * s)
        d.text((x0 + lw + 14 * s, (y0 + y1) / 2), fit(d, txt, f, x1 - x0 - lw - 28 * s), font=f, fill=C["amber"], anchor="lm")

    def flash_box(self, d, W, H):
        s = self.s
        bw, bh = int(W * 0.7), int((70 + 40 * len(self.flash)) * s)
        x0, y0 = (W - bw) // 2, int(H * 0.28)
        d.rectangle((x0, y0, x0 + bw, y0 + bh), fill="#1a0504", outline=C["red"], width=max(2, int(4 * s)))
        spaced(d, (x0 + bw / 2, y0 + 30 * s), T("FLASH TRAFFIC"), font("head", 30 * s), C["red"], 8 * s, "mm")
        y = y0 + 64 * s
        for e in self.flash:
            f = font("monob", 16 * s)
            d.text((x0 + 24 * s, y), fit(d, T(str(e.get("title", ""))) + "  " + str(e.get("detail") or ""), f, bw - 48 * s), font=f, fill="#ffd9d4", anchor="lm")
            y += 40 * s

    # ---- panel frame
    def panel(self, d, box, code, title, tag=None, tag_hot=False):
        x0, y0, x1, y1 = box
        s = self.s
        d.rectangle(box, fill=C["panel"], outline=C["line"])
        hh = int(24 * s)
        d.rectangle((x0 + 1, y0 + 1, x1 - 1, y0 + hh), fill=C["panel2"])
        d.line([(x0, y0 + hh), (x1, y0 + hh)], fill=C["line"])
        cf = font("monob", 10 * s)
        cwid = tw(d, code, cf) + 10 * s
        d.rectangle((x0 + 8 * s, y0 + 5 * s, x0 + 8 * s + cwid, y0 + hh - 5 * s), fill=C["olive"])
        d.text((x0 + 8 * s + cwid / 2, y0 + hh / 2 + 1), code, font=cf, fill=C["ink"], anchor="mm")
        x = x0 + 16 * s + cwid
        tf = font("head", 13 * s)
        avail = x1 - x - 10 * s
        if tag:
            tg = font("mono", 10 * s)
            tws = tw(d, tag, tg) + 10 * s
            d.rectangle((x1 - 8 * s - tws, y0 + 5 * s, x1 - 8 * s, y0 + hh - 5 * s), fill=C["red"] if tag_hot else None, outline=C["red"] if tag_hot else C["line2"])
            d.text((x1 - 8 * s - tws / 2, y0 + hh / 2 + 1), tag, font=tg, fill=C["ink"] if tag_hot else C["dim"], anchor="mm")
            avail -= tws + 8 * s
        title = T(title)
        while title and spaced(ImageDraw.Draw(Image.new("RGB", (1, 1))), (0, 0), title, tf, C["khaki"], 3 * s) > avail:
            title = title[:-1]
        spaced(d, (x, y0 + hh / 2 + 1), title, tf, C["khaki"], 3 * s, "lm")
        return (x0 + int(10 * s), y0 + hh + int(8 * s), x1 - int(10 * s), y1 - int(8 * s))

    def empty(self, d, box, msg):
        x0, y0, x1, y1 = box
        d.text((x0, y0 + 4 * self.s), fit(d, T(msg), font("mono", 12 * self.s), x1 - x0), font=font("mono", 12 * self.s), fill=C["faint"])

    def item(self, d, x0, x1, y, t, m, color, tf=None, mf=None):
        """Two-line list item with a coloured severity bar. Returns the y below it."""
        s = self.s
        tf, mf = tf or font("monob", 13 * s), mf or font("mono", 11 * s)
        d.rectangle((x0, y + 2 * s, x0 + 3 * s, y + 34 * s), fill=color)
        d.text((x0 + 10 * s, y + 9 * s), fit(d, t, tf, x1 - x0 - 10 * s), font=tf, fill=C["text"], anchor="lm")
        d.text((x0 + 10 * s, y + 27 * s), fit(d, m, mf, x1 - x0 - 10 * s), font=mf, fill=C["dim"], anchor="lm")
        return y + 42 * s

    # ---- panels
    def p_defcon(self, img, d, box):
        s = self.s
        dc = self.data("defcon") or {}
        b = self.panel(d, box, "S-01", "DEFCON", T("UNOFFICIAL"))
        x0, y0, x1, y1 = b
        lvl = dc.get("level")
        cols = {1: "#ffffff", 2: C["red"], 3: C["orange"], 4: C["yellow"], 5: C["green"]}
        names = ["COCKED PISTOL", "FAST PACE", "ROUND HOUSE", "DOUBLE TAKE", "FADE OUT"]
        nw = int(min((x1 - x0) * 0.32, (y1 - y0) * 0.6))
        d.rectangle((x0, y0, x0 + nw, y0 + nw * 1.25), outline=C["line2"])
        d.text((x0 + nw / 2, y0 + nw * 0.62), str(lvl or "-"), font=font("head", nw * 0.95), fill=cols.get(lvl, C["dim"]), anchor="mm")
        rh = min(26 * s, (nw * 1.25) / 5)
        f = font("monob", 11 * s)
        for i, nm in enumerate(names):
            n = i + 1
            y = y0 + i * rh
            on = n == lvl
            d.rectangle((x0 + nw + 8 * s, y, x1, y + rh - 3 * s), fill=cols[n] if on else None, outline=None if on else C["line"])
            d.text((x0 + nw + 16 * s, y + (rh - 3 * s) / 2), fit(d, "%d  %s" % (n, nm), f, x1 - x0 - nw - 20 * s), font=f,
                   fill=C["ink"] if on else C["faint"], anchor="lm")
        y = y0 + nw * 1.25 + 14 * s
        mf = font("mono", 11 * s)
        src = ("SRC: " + str(dc.get("source", "")) + ". " + T("Actual DEFCON is classified and not published.")) if dc else T("Actual DEFCON is classified. Waiting on open-source estimate…")
        for ln in wrap(d, src, mf, x1 - x0, 2):
            d.text((x0, y), ln, font=mf, fill=C["dim"]); y += 15 * s
        dd = (self.state or {}).get("config", {}).get("doomsday") or {}
        if y < y1 - 20 * s:
            y = max(y + 6 * s, y1 - 30 * s)
            d.line([(x0, y - 6 * s), (x1, y - 6 * s)], fill=C["line"])
            d.text((x0, y + 8 * s), T("DOOMSDAY CLOCK"), font=font("mono", 11 * s), fill=C["dim"], anchor="lm")
            d.text((x1, y + 8 * s), "%s SEC" % dd.get("seconds", "--"), font=font("monob", 16 * s), fill=C["amber"], anchor="rm")

    def p_seismic(self, img, d, box):
        s = self.s
        q = self.data("quakes") or {}
        mag = float((self.state or {}).get("config", {}).get("quake_min_mag") or 6)
        b = self.panel(d, box, "G-01", "SEISMIC", "M%.1f+" % mag)
        x0, y0, x1, y1 = b
        ev, now = q.get("events") or [], self.now()
        wide = (x1 - x0) > (y1 - y0) * 1.6
        mw = int((x1 - x0) * 0.55) if wide else (x1 - x0)
        mh = min(int(mw / 2), (y1 - y0) if wide else int((y1 - y0) * 0.45))
        mw = mh * 2
        WORLD.load()
        img.paste(WORLD.base(mw, mh), (x0, y0))
        sx, sy = mw / 360.0, mh / 180.0
        P = lambda la, lo: (x0 + (lo + 180) * sx, y0 + (90 - la) * sy)
        for e in (self.data("gdacs") or {}).get("events", []):
            if e.get("lat") is not None:
                px, py = P(e["lat"], e["lon"]); r = 4 * s
                d.polygon([(px, py - r), (px + r, py + r), (px - r, py + r)], outline=C["orange"])
        fd = self.data("fire") or {}
        for f in fd.get("fires") or []:
            if f.get("lat") is not None:
                px, py = P(f["lat"], f["lon"]); d.rectangle((px - 1.5 * s, py - 1.5 * s, px + 1.5 * s, py + 1.5 * s), fill=C["orange"])
        for e in reversed(ev):
            age = now - (e.get("time") or 0)
            col = C["red"] if age < 86400 else C["amber"] if age < 7 * 86400 else C["dim"]
            r = max(2, (e["mag"] - 5.5) * 2.2) * s
            px, py = P(e["lat"], e["lon"])
            d.ellipse((px - r, py - r, px + r, py + r), outline=col, width=max(1, int(2 * s)))
            if age < 86400:
                d.ellipse((px - r * 2, py - r * 2, px + r * 2, py + r * 2), outline=col)
        loc = (self.state or {}).get("config", {}).get("location") or {}
        if loc.get("lat") is not None:
            px, py = P(loc["lat"], loc["lon"])
            d.line([(px - 6 * s, py), (px + 6 * s, py)], fill=C["cyan"], width=2); d.line([(px, py - 6 * s), (px, py + 6 * s)], fill=C["cyan"], width=2)
        # stats + list
        c24 = sum(1 for e in ev if now - e["time"] < 86400)
        c7 = sum(1 for e in ev if now - e["time"] < 7 * 86400)
        mx = max([e["mag"] for e in ev if now - e["time"] < 7 * 86400] or [0])
        tsu = sum(1 for e in ev if e.get("tsunami") and now - e["time"] < 7 * 86400)
        lx0 = x0 + mw + 12 * s if wide else x0
        ly = y0 if wide else y0 + mh + 10 * s
        stats = [("24H", str(c24), c24 > 0), ("7D", str(c7), False), (T("MAX 7D"), "%.1f" % mx if mx else "--", mx >= 7), (T("TSU FLAG"), str(tsu), tsu > 0)]
        sw = (x1 - lx0 - 3 * 6 * s) / 4
        for i, (lbl, v, hot) in enumerate(stats):
            sx0 = lx0 + i * (sw + 6 * s)
            d.rectangle((sx0, ly, sx0 + sw, ly + 44 * s), outline=C["line"])
            d.text((sx0 + 6 * s, ly + 10 * s), fit(d, lbl, font("mono", 9 * s), sw - 8 * s), font=font("mono", 9 * s), fill=C["dim"], anchor="lm")
            d.text((sx0 + 6 * s, ly + 30 * s), v, font=font("monob", 18 * s), fill=C["red"] if hot else C["text"], anchor="lm")
        y = ly + 54 * s
        if not ev:
            self.empty(d, (lx0, y, x1, y1), "AWAITING USGS" if not q else "NO EVENTS")
        for e in ev:
            if y + 40 * s > y1:
                break
            col = C["red"] if e["mag"] >= 7 else C["orange"] if e["mag"] >= 6.5 else C["yellow"]
            flags = (" · " + T("TSUNAMI FLAG")) if e.get("tsunami") else ""
            y = self.item(d, lx0, x1, y, "%.1f  %s%s" % (e["mag"], e.get("place", ""), flags),
                          "%s · %s · %s %s KM" % (zulu(e["time"]), T(ago(e["time"], now) + " AGO"), T("DEPTH"), r0(e.get("depth"))), col)

    def p_weather(self, img, d, box):
        s = self.s
        w = self.data("weather") or {}
        loc = (self.state or {}).get("config", {}).get("location") or {}
        b = self.panel(d, box, "L-01", "LOCAL WX", (loc.get("name") or T("NO LOC")).upper()[:18])
        x0, y0, x1, y1 = b
        if not w.get("configured"):
            return self.empty(d, b, "SET LOCATION IN CFG")
        imp = w.get("units") == "imperial"
        tu, su, pu = ("°F", "MPH", "IN") if imp else ("°C", "KM/H", "MM")
        tf = font("head", 52 * s)
        t = r0(w.get("temp"))
        d.text((x0, y0 + 30 * s), t, font=tf, fill=C["text"], anchor="lm")
        tx = x0 + tw(d, t, tf) + 4 * s
        d.text((tx, y0 + 12 * s), tu, font=font("monob", 14 * s), fill=C["dim"], anchor="lm")
        cx = tx + 40 * s
        d.text((cx, y0 + 20 * s), fit(d, T(str(w.get("cond", "")).upper()), font("head", 16 * s), x1 - cx), font=font("head", 16 * s), fill=C["amber"], anchor="lm")
        d.text((cx, y0 + 42 * s), "%s %s° · RH %s%%" % (T("FEELS"), r0(w.get("feels")), r0(w.get("rh"))), font=font("mono", 11 * s), fill=C["dim"], anchor="lm")
        cells = [(T("WIND") + " " + su, "%s %s" % (r0(w.get("wind")), LANG.dir(self.compass(w.get("wdir"))))), (T("GUST") + " " + su, r0(w.get("gust"))),
                 (T("PRESS HPA"), r0(w.get("pressure"))), (T("CLOUD"), r0(w.get("cloud")) + "%"),
                 (T("PRECIP") + " " + pu, "--" if w.get("precip") is None else str(w["precip"])),
                 ("SUN ↑↓", "%s/%s" % ((w.get("sunrise") or "")[11:16] or "--", (w.get("sunset") or "")[11:16] or "--"))]
        gy = y0 + 66 * s
        cwid = (x1 - x0 - 6 * s) / 2 if (x1 - x0) < 500 * s else (x1 - x0 - 12 * s) / 3
        per = 2 if (x1 - x0) < 500 * s else 3
        for i, (lbl, v) in enumerate(cells):
            cx0 = x0 + (i % per) * (cwid + 6 * s); cy0 = gy + (i // per) * 42 * s
            if cy0 + 38 * s > y1:
                break
            d.rectangle((cx0, cy0, cx0 + cwid, cy0 + 36 * s), outline=C["line"])
            d.text((cx0 + 6 * s, cy0 + 9 * s), fit(d, lbl, font("mono", 9 * s), cwid - 8 * s), font=font("mono", 9 * s), fill=C["dim"], anchor="lm")
            d.text((cx0 + 6 * s, cy0 + 26 * s), fit(d, v, font("monob", 14 * s), cwid - 8 * s), font=font("monob", 14 * s), fill=C["text"], anchor="lm")
        dy = gy + ((len(cells) + per - 1) // per) * 42 * s + 4 * s
        days = (w.get("days") or [])[:4]
        if days and dy + 56 * s <= y1:
            dw = (x1 - x0 - 6 * s * (len(days) - 1)) / len(days)
            for i, dd in enumerate(days):
                dx0 = x0 + i * (dw + 6 * s)
                lbl = T("TODAY") if i == 0 else LANG.dow((time.strptime(dd["date"], "%Y-%m-%d").tm_wday + 1) % 7)
                d.rectangle((dx0, dy, dx0 + dw, dy + 54 * s), outline=C["line"])
                d.text((dx0 + dw / 2, dy + 10 * s), lbl, font=font("mono", 10 * s), fill=C["dim"], anchor="mm")
                d.text((dx0 + dw / 2, dy + 26 * s), "%s°/%s°" % (r0(dd.get("hi")), r0(dd.get("lo"))), font=font("monob", 12 * s), fill=C["text"], anchor="mm")
                d.text((dx0 + dw / 2, dy + 42 * s), fit(d, T(str(dd.get("cond", "")).upper()), font("mono", 9 * s), dw - 6 * s), font=font("mono", 9 * s), fill=C["dim"], anchor="mm")

    @staticmethod
    def compass(deg):
        if deg is None:
            return "--"
        return Lang.EN_DIR[int(round(deg / 22.5)) % 16]

    def p_alerts(self, img, d, box):
        s = self.s
        a = self.data("alerts") or {}
        al = a.get("alerts") or []
        n = sum(1 for x in al if x.get("local") is not False)
        b = self.panel(d, box, "L-02", "LOCAL ALERTS", str(n), n > 0)
        x0, y0, x1, y1 = b
        if not a.get("configured"):
            return self.empty(d, b, "SET LOCATION IN CFG")
        if not al:
            return self.empty(d, b, a.get("note") or ("NO LOCAL WARNING FEED FOR THIS COUNTRY" if a.get("supported") is False else "NO ACTIVE ALERTS"))
        y = y0
        for x in al:
            if y + 40 * s > y1:
                break
            rank = {"Extreme": 3, "Severe": 2, "Moderate": 1}.get(x.get("severity"), 0)
            m = T(str(x.get("severity", "")).upper()) + (" · " + str(x.get("area", "")).upper() if x.get("area") else "") + (" · EXP " + zulu(x["expires"]) if x.get("expires") else "")
            y = self.item(d, x0, x1, y, str(x.get("event", "")).upper(), m, sev_color(rank) if x.get("local") is not False else C["faint"])

    def p_fire(self, img, d, box):
        s = self.s
        fd = self.data("fire") or {}
        cfg = (self.state or {}).get("config", {})
        imp = cfg.get("units") == "imperial"
        alert_km = (cfg.get("fire_alert_mi") or 15) * 1.609
        fires = fd.get("fires") or []
        near = sum(1 for f in fires if f.get("km", 1e9) <= alert_km)
        b = self.panel(d, box, "L-03", "FIRE & DROUGHT", "%d %s" % (fd.get("nearby") or 0, T("NEAR")) if fd.get("configured") else None, near > 0)
        x0, y0, x1, y1 = b
        dr = fd.get("drought")
        names = ["ABNORMALLY DRY", "MODERATE", "SEVERE", "EXTREME", "EXCEPTIONAL"]
        dh = 0
        if dr and dr.get("worst") is not None:
            w = dr["worst"]
            txt = T("NO DROUGHT AT YOUR LOCATION") if w < 0 else "D%d %s%s" % (w, T(names[w]), (" " + T("DROUGHT")) if w >= 1 else "")
            if w >= 0 and dr.get("cum"):
                txt += " · %d%%" % round(dr["cum"][w])
            col = C["green"] if w < 0 else [C["yellow"], C["yellow"], C["orange"], C["red"], C["red"]][w]
            f = font("monob", 12 * s)
            d.text((x0, y1 - 8 * s), fit(d, txt, f, x1 - x0), font=f, fill=col, anchor="lm")
            dh = 26 * s
        if not fd.get("configured"):
            return self.empty(d, b, "SET LOCATION IN CFG" if fd else "AWAITING NIFC")
        if fd.get("supported") is False:
            return self.empty(d, b, "NO LOCAL WILDFIRE DATA HERE · SEE GLOBAL DISASTERS")
        y = y0
        if not fires:
            self.empty(d, (x0, y, x1, y1), "NO ACTIVE WILDFIRES NEARBY")
        for f in fires:
            if y + 40 * s > y1 - dh:
                break
            dist = ("%d MI" % round(f["km"] / 1.609)) if imp else ("%d KM" % round(f["km"]))
            nearf = f["km"] <= alert_km
            sz = f.get("acres")
            size = "SATELLITE" if f.get("kind") == "hotspot" else ("SIZE ?" if sz is None else ("%s %s" % ("{:,}".format(int(round(sz if imp else sz / 2.471))), "AC" if imp else "HA")))
            cont = f.get("status") or ("" if f.get("contained") is None else "%d%% CONT" % round(f["contained"]))
            col = C["red"] if nearf else C["orange"] if (sz or 0) >= 1000 else C["yellow"] if (sz or 0) >= 100 else C["faint"]
            y = self.item(d, x0, x1, y, "%s %s  %s" % (dist, LANG.dir(f.get("dir", "")), f.get("name", "")), T(size + (" · " + cont if cont else "")), col)

    def p_outbreaks(self, img, d, box):
        s = self.s
        o = self.data("outbreaks") or {}
        cdc = [n for n in (o.get("cdc") or []) if (n.get("level") or 0) >= 2]
        top = max([n.get("level") or 0 for n in (o.get("cdc") or [])] or [0])
        b = self.panel(d, box, "B-01", "OUTBREAKS", ("CDC MAX L%d" % top) if top else None, top >= 3)
        x0, y0, x1, y1 = b
        y = y0
        if not o:
            return self.empty(d, b, "AWAITING FEEDS…")
        for n in cdc:
            if y + 40 * s > y1:
                break
            lv = n.get("level") or 0
            y = self.item(d, x0, x1, y, "L%d  %s" % (lv, n.get("title", "")), "CDC · " + (T(ago(n.get("time"), self.now()) + " AGO") if n.get("time") else ""), sev_color(min(3, lv - 1)))
        for w in (o.get("who") or [])[:6]:
            if y + 40 * s > y1:
                break
            y = self.item(d, x0, x1, y, w.get("title", ""), "WHO · " + T(ago(w.get("time"), self.now()) + " AGO"), C["orange"] if w.get("high") else C["faint"])

    def p_space(self, img, d, box):
        s = self.s
        sp = self.data("space") or {}
        b = self.panel(d, box, "G-03", "SPACE WX / GRID")
        x0, y0, x1, y1 = b
        if not sp:
            return self.empty(d, b, "AWAITING NOAA SWPC")
        g = sp.get("g") or 0
        gc = [C["green"], C["yellow"], C["amber"], C["orange"], C["red"], C["red"]][min(5, g)]
        bw = 60 * s
        d.rectangle((x0, y0, x0 + bw, y0 + bw * 0.8), outline=gc, width=max(1, int(2 * s)))
        d.text((x0 + bw / 2, y0 + bw * 0.4), "G%d" % g, font=font("head", 28 * s), fill=gc, anchor="mm")
        desc = ["QUIET", "MINOR STORM", "MODERATE STORM", "STRONG STORM", "SEVERE STORM", "EXTREME STORM"][min(5, g)]
        d.text((x0 + bw + 12 * s, y0 + 14 * s), fit(d, T(desc), font("head", 16 * s), x1 - x0 - bw - 12 * s), font=font("head", 16 * s), fill=gc, anchor="lm")
        kp = sp.get("kp"); pk = sp.get("kp_peak_24h")
        d.text((x0 + bw + 12 * s, y0 + 36 * s), "KP %s · %s %s" % ("--" if kp is None else "%.2f" % kp, T("24H PEAK"), "--" if pk is None else "%.1f" % pk),
               font=font("mono", 11 * s), fill=C["dim"], anchor="lm")
        series = sp.get("series") or []
        by0, by1 = y0 + bw * 0.8 + 16 * s, min(y1 - 20 * s, y0 + bw * 0.8 + 110 * s)
        if series and by1 > by0 + 20 * s:
            n = len(series); gap = 2 * s; cw = (x1 - x0 - gap * (n - 1)) / n
            for i, k in enumerate(series):
                h = max(3 * s, (k / 9.0) * (by1 - by0))
                col = C["red"] if k >= 7 else C["orange"] if k >= 6 else C["amber"] if k >= 5 else C["olive"]
                bx = x0 + i * (cw + gap)
                d.rectangle((bx, by1 - h, bx + cw, by1), fill=col)
            f = font("mono", 9 * s)
            d.text((x0, by1 + 10 * s), fit(d, T("PLANETARY KP · 3H BINS · G4+ CAN DISRUPT POWER GRID / HF / GPS"), f, x1 - x0), font=f, fill=C["dim"], anchor="lm")


# ------------------------------------------------------------------ first-time setup screen (SD-card image)
def setup_status():
    try:
        st = json.load(open(SETUP_STATUS))
    except (OSError, ValueError):
        return None
    if not os.path.exists("/etc/crashboard-image") and not os.environ.get("CB_FB_OUT"):
        return None
    if os.path.exists(os.path.join(DATA, "setup-done.json")) or not st.get("first", True):
        # setup was finished before: only the Wi-Fi rescue screen (old Wi-Fi gone, rescue hotspot up)
        if st.get("phase") in ("hotspot", "connecting", "error"):
            return st
        return None
    if st.get("phase") in ("starting", "hotspot", "lan", "connecting", "applying", "done", "error"):
        return st
    return None


def draw_qr(img, text, box):
    import qr
    m = qr.qr_matrix(text)
    x0, y0, x1, y1 = box
    side = int(min(x1 - x0, y1 - y0))
    n = len(m) + 4
    cell = max(1, side // n)
    q = Image.new("RGB", (n * cell, n * cell), "white")
    qd = ImageDraw.Draw(q)
    for y, row in enumerate(m):
        for x, c in enumerate(row):
            if c:
                qd.rectangle(((x + 2) * cell, (y + 2) * cell, (x + 3) * cell - 1, (y + 3) * cell - 1), fill="black")
    img.paste(q, (int(x0 + ((x1 - x0) - q.width) / 2), int(y0 + ((y1 - y0) - q.height) / 2)))


def render_setup(scr, st):
    set_theme("ops")
    W, H = scr.w, scr.h
    s = min(W / 1280.0, H / 720.0)
    img = Image.new("RGB", (W, H), C["bg"])
    d = ImageDraw.Draw(img)
    hf = font("head", 40 * s)
    shield(d, W / 2, 44 * s, 46 * s, C["orange"])
    spaced(d, (W / 2 - 44 * s, 44 * s), "CRASH", hf, C["khaki"], 10 * s, "rm")
    bw = spaced(d, (W / 2 + 44 * s, 44 * s), "BOARD", hf, C["khaki"], 10 * s, "lm")
    d.text((W / 2 + 44 * s + bw + 4 * s, 32 * s), "\u2122", font=font("head", 16 * s), fill=C["khaki"], anchor="lm")
    v1_badge(d, W / 2 + 44 * s + bw + 24 * s, 44 * s, 16 * s)
    d.line([(20 * s, 84 * s), (W - 20 * s, 84 * s)], fill=C["line2"])
    rescue = not st.get("first", True) and st.get("phase") in ("hotspot", "connecting", "error")
    title = "SETUP COMPLETE" if st.get("phase") == "done" else "NO WI-FI · PICK A NEW NETWORK" if rescue else "FIRST-TIME SETUP"
    spaced(d, (W / 2, 100 * s), title, font("mono", 13 * s), C["dim"], 4 * s, "mm")
    y = 118 * s
    if st.get("error"):
        d.rectangle((40 * s, y, W - 40 * s, y + 40 * s), fill="#2a0f0c", outline=C["red"])
        d.text((W / 2, y + 20 * s), fit(d, st["error"], font("monob", 16 * s), W - 100 * s), font=font("monob", 16 * s), fill="#ffb3ab", anchor="mm")
        y += 50 * s
    ph = st.get("phase")
    if ph in ("hotspot", "lan"):
        ip = st.get("ip") or "10.42.0.1"
        steps = []
        if ph == "hotspot":
            ap = st.get("ap") or "CRASHBOARD-SETUP"
            steps.append(("1  JOIN THIS WI-FI ON YOUR PHONE", "WIFI:T:nopass;S:%s;;" % re.sub(r'([\\;,:"])', r"\\\1", ap), ap, "No password. Scan with your camera, or pick it in Wi-Fi settings."))
            steps.append(("2  FILL IN THE SETUP PAGE", "http://%s/" % ip, ip, "Most phones open it by themselves. If not, scan or type the address."))
        else:
            steps.append(("ON A PHONE ON THE SAME WI-FI, OPEN", "http://%s/" % ip, ip, "Scan the code with your phone camera."))
        n = len(steps)
        gw = 30 * s
        bw = (W - 60 * s - gw * (n - 1)) / n if n > 1 else min(W - 60 * s, 600 * s)
        bx = (W - (bw * n + gw * (n - 1))) / 2
        by1 = H - 50 * s
        for i, (title, data, big, small) in enumerate(steps):
            x0 = bx + i * (bw + gw)
            d.rectangle((x0, y, x0 + bw, by1), fill=C["panel"], outline=C["line"])
            spaced(d, (x0 + bw / 2, y + 22 * s), title, font("head", 18 * s), C["khaki"], 3 * s, "mm")
            qtop, qbot = y + 44 * s, by1 - 90 * s
            draw_qr(img, data, (x0 + 20 * s, qtop, x0 + bw - 20 * s, qbot))
            d.text((x0 + bw / 2, by1 - 62 * s), fit(d, big, font("monob", 26 * s), bw - 20 * s), font=font("monob", 26 * s), fill=C["green"], anchor="mm")
            for k, ln in enumerate(wrap(d, small, font("mono", 12 * s), bw - 30 * s, 2)):
                d.text((x0 + bw / 2, by1 - 34 * s + k * 16 * s), ln, font=font("mono", 12 * s), fill=C["dim"], anchor="mm")
        d.text((W / 2, H - 24 * s), "Waiting for your phone…", font=font("mono", 13 * s), fill=C["dim"], anchor="mm")
    else:
        big, small = {"connecting": ("CONNECTING TO %s…" % str(st.get("target", "")).upper(), "Joining your Wi-Fi. This can take a minute."),
                      "applying": ("SETTING UP YOUR BOARD…", "Finding your location and loading the first alerts."),
                      "done": ("ALL SET", "Restarting into Crash Board…"),
                      "starting": ("STARTING SETUP…", "Looking for Wi-Fi networks."),
                      "error": ("SETUP PROBLEM", st.get("error") or "")}.get(ph, ("…", ""))
        d.text((W / 2, H / 2 - 20 * s), fit(d, big, font("head", 46 * s), W - 60 * s), font=font("head", 46 * s), fill=C["green"], anchor="mm")
        d.text((W / 2, H / 2 + 36 * s), small, font=font("mono", 18 * s), fill=C["dim"], anchor="mm")
    return img


# ------------------------------------------------------------------ main loop
def menu_frame(scr, menu):
    W, H = scr.w, scr.h
    s = min(W / 860.0, H / 520.0) if (W < 1000 or H < 560) else min(W / 1280.0, H / 720.0)
    img = Image.new("RGB", (W, H), C["bg"])
    menu.draw(img, {"C": C, "T": T, "s": s, "font": font, "fit": fit, "spaced": spaced})
    return img


def main():
    scr = Screen()
    board = Board(scr)
    sys.path.insert(0, HERE)
    from wifimenu import Input, WifiMenu
    from linkmenu import LinkMenu, find_best, save_conf
    inp = Input(scr.w, scr.h) if not scr.out else None
    wifi = WifiMenu()
    link = LinkMenu(DATA, set_host)
    menu = wifi
    finder = {"busy": False, "last": 0, "fail_since": None}

    def auto_find(old):
        try:
            b = find_best(old, HOST_EDITION)
            if b and b["url"] != old:
                save_conf(DATA, b["url"], b["edition"])
                set_host(b["url"])
                print("relinked to", b["url"], flush=True)
        finally:
            finder["busy"] = False
    board.hint = bool(inp and inp.has_keys)
    try:
        last_poll = last_page = last_tick = last_menu = 0
        last_setup = None
        while True:
            t = time.time()
            # ---- Wi-Fi picker (keyboard W / F2, or tap the top bar)
            if menu.open:
                if menu.dirty or (menu.busy and t - last_menu >= 1):
                    scr.show(menu_frame(scr, menu)); menu.dirty = False; last_menu = t
                if not menu.busy and t - menu.touched > 120:
                    menu.close()
                for ev in (inp.poll(0.25) if inp else []):
                    if menu.handle(ev):
                        menu.dirty = True
                if not menu.open:
                    board.frame, last_poll = None, 0         # back to the board: full redraw
                if ONCE:
                    return
                continue
            st = setup_status()
            if st:
                key = json.dumps({k: st.get(k) for k in ("phase", "ap", "ip", "error", "target", "message")})
                if key != last_setup:
                    scr.show(render_setup(scr, st)); last_setup = key
                if ONCE:
                    return
                for ev in (inp.poll(2) if inp else []):
                    if (ev[0] == "key" and ev[1] in ("w", "W", "f2")) and st.get("phase") != "applying":
                        menu = wifi; menu.start(); menu.dirty = True; last_setup = None; break
                if not inp:
                    time.sleep(2)
                continue
            if last_setup is not None:
                last_setup, last_poll = None, 0
            redraw = False
            if t - last_poll >= 15:
                board.poll(); last_poll = t; redraw = True
                # display mode: the PC stopped answering for a while -> look for it on the network
                if HOST_URL and not board.ok:
                    finder["fail_since"] = finder["fail_since"] or t
                    if t - finder["fail_since"] > 45 and t - finder["last"] > 90 and not finder["busy"]:
                        finder.update(busy=True, last=t)
                        threading.Thread(target=auto_find, args=(HOST_URL,), daemon=True).start()
                else:
                    finder["fail_since"] = None
            if t - last_page >= 15:
                board.page += 1; last_page = t; redraw = redraw or getattr(board, "small", True)
            if t - last_tick >= 8:
                board.tick_i += 1; last_tick = t
                if not redraw and board.frame is not None:
                    d = ImageDraw.Draw(board.frame); board.ticker(d); scr.show(board.frame, tuple(int(v) for v in board.tick_box))
            if redraw or board.frame is None:
                scr.show(board.render())
                if ONCE:
                    return
            else:
                d = ImageDraw.Draw(board.frame); board.clock(d)
                scr.show(board.frame, tuple(int(v) for v in board.clock_box))
            wait = max(0.05, 1.0 - (time.time() % 1.0))
            if not inp:
                time.sleep(wait); continue
            for ev in inp.poll(wait):
                if (ev[0] == "key" and ev[1] in ("w", "W", "f2")) or (ev[0] == "tap" and ev[2] < scr.h * 0.12):
                    menu = wifi; menu.start(); menu.dirty = True; break
                if ev[0] == "key" and ev[1] in ("l", "L", "f3"):
                    menu = link; menu.start(); menu.dirty = True; break
                if ev[0] == "key" and ev[1] in ("left", "right") and getattr(board, "small", False):
                    board.page += 1 if ev[1] == "right" else -1; last_page = time.time()
                    scr.show(board.render())
                elif ev[0] == "tap" and getattr(board, "small", False):
                    board.page += 1 if ev[1] > scr.w / 2 else -1; last_page = time.time()
                    scr.show(board.render())
            board.hint = inp.has_keys
    except KeyboardInterrupt:
        pass
    finally:
        scr.close()


if __name__ == "__main__":
    main()
