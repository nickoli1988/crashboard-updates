"""Link the Pi's screen to a Crash Board on another computer (display mode).

Press L on the board: the Pi searches the network for Crash Boards and lists them. Pick one, or
choose TYPE AN ADDRESS and enter the address shown under CFG -> THIS BOARD'S ADDRESS on the PC.
The choice is saved in data/display.conf. fbboard.py also calls find_best() by itself when the
linked board stops answering (for example the PC got a new address or port).
"""
import json, os, re, socket, threading, time, urllib.request

from wifimenu import WifiMenu

DISCOVERY_PORT = 47474


def discover(timeout=2.5):
    """Ask the network 'CRASHBOARD?' and collect the answers: [{ip, port, name, edition, version, url}]."""
    found = {}
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        s.settimeout(0.4)
        for _ in range(2):
            for dst in ("255.255.255.255", "<broadcast>"):
                try:
                    s.sendto(b"CRASHBOARD?", (dst, DISCOVERY_PORT))
                except OSError:
                    pass
            end = time.time() + timeout / 2
            while time.time() < end:
                try:
                    data, addr = s.recvfrom(1024)
                except socket.timeout:
                    continue
                except OSError:
                    break
                try:
                    j = json.loads(data)
                except ValueError:
                    continue
                if not j.get("crashboard") or not j.get("port"):
                    continue
                ip, port = addr[0], int(j["port"])
                found[(ip, port)] = {"ip": ip, "port": port, "name": str(j.get("name") or "CRASH BOARD")[:30],
                                     "edition": j.get("edition") or "crashboard", "version": j.get("version") or "",
                                     "url": "http://%s:%d" % (ip, port)}
        s.close()
    except OSError:
        pass
    return sorted(found.values(), key=lambda b: (b["ip"], b["port"]))


def answers(url, timeout=5):
    try:
        j = json.loads(urllib.request.urlopen(url.rstrip("/") + "/api/state", timeout=timeout).read())
        return "feeds" in j
    except Exception:
        return False


def clean_address(text):
    """'192.168.1.4:8081', 'http://192.168.1.4:8081/' or just '192.168.1.4' -> URL (no port = try the usual ones)."""
    t = text.strip().replace(" ", "")
    t = re.sub(r"^https?://", "", t, flags=re.I).rstrip("/")
    m = re.fullmatch(r"([A-Za-z0-9.\-]+)(?::(\d{2,5}))?", t)
    if not m:
        return []
    host, port = m.group(1), m.group(2)
    ports = [int(port)] if port else [8080, 8081, 8090, 8082, 8091]
    return ["http://%s:%d" % (host, p) for p in ports]


def read_conf(data_dir):
    try:
        txt = open(os.path.join(data_dir, "display.conf")).read()
    except OSError:
        return {}
    return dict(re.findall(r'^([A-Z_]+)="?([^"\n]*)"?\s*$', txt, re.M))


def save_conf(data_dir, url, edition=""):
    """Write HOST_URL (and HOST_EDITION) into data/display.conf, keeping any other lines."""
    p = os.path.join(data_dir, "display.conf")
    try:
        lines = [l for l in open(p).read().splitlines() if not re.match(r"\s*(HOST_URL|HOST_EDITION)=", l)]
    except OSError:
        lines = ["# Crash Board display mode: this screen shows the board at HOST_URL"]
    lines.append('HOST_URL="%s"' % url)
    if edition:
        lines.append('HOST_EDITION="%s"' % edition)
    tmp = p + ".tmp"
    with open(tmp, "w") as f:
        f.write("\n".join(lines) + "\n")
    os.replace(tmp, p)


def find_best(current_url, edition_hint=""):
    """Linked board stopped answering: look for it again. Returns a board dict, or None if unsure."""
    m = re.match(r"https?://([^:/]+)(?::(\d+))?", current_url or "")
    old_ip, old_port = (m.group(1), int(m.group(2) or 80)) if m else ("", 0)
    want = edition_hint or ("mesh" if 8090 <= old_port < 8100 else "crashboard")
    boards = [b for b in discover() if b["edition"] == want]
    if not boards:
        return None
    same_ip = [b for b in boards if b["ip"] == old_ip]
    pick = same_ip if same_ip else boards
    return pick[0] if len(pick) == 1 else None


class LinkMenu(WifiMenu):
    TITLE = "LINK"
    SSID_LABEL = "ADDRESS SHOWN IN CFG ON YOUR PC (LIKE 192.168.1.4:8081)"
    LIST_HINT = "ARROWS + ENTER TO PICK · R TO SEARCH AGAIN · ESC TO CLOSE"
    OTHER = "TYPE AN ADDRESS…"
    TEXT_HINT = "TYPE THE ADDRESS · ENTER = LINK · ESC GOES BACK"

    def __init__(self, data_dir, on_link):
        self.data_dir, self.on_link = data_dir, on_link
        WifiMenu.__init__(self)

    def scan(self):
        if self.busy:
            return
        self.busy, self.msg = True, "SEARCHING FOR CRASH BOARDS…"

        def work():
            boards = discover()
            self.nets = [dict(b, ssid="%s · %s  %s:%d" % (b["name"], "MESH" if b["edition"] == "mesh" else "REGULAR", b["ip"], b["port"]),
                              signal=100, secure=False) for b in boards][:10]
            cur = read_conf(self.data_dir).get("HOST_URL", "")
            self.cur = re.sub(r"^https?://", "", cur)
            self.msg = "" if self.nets else "NONE FOUND. PICK TYPE AN ADDRESS."
            self.sel, self.busy, self.dirty = 0, False, True
        threading.Thread(target=work, daemon=True).start()

    def link(self, urls, edition=""):
        self.mode, self.msg, self.busy = "connecting", "CHECKING…", True; self.dirty = True

        def work():
            for u in urls:
                if answers(u):
                    save_conf(self.data_dir, u, edition)
                    self.on_link(u)
                    self.mode, self.msg, self.cur = "done", "✓ LINKED TO " + re.sub(r"^https?://", "", u), u
                    self.busy, self.dirty = False, True
                    time.sleep(3); self.open = False; self.dirty = True
                    return
            self.mode, self.msg, self.busy = "ssid", "✗ No Crash Board answered there. Check the address in CFG on the PC.", False
            self.dirty = True
        threading.Thread(target=work, daemon=True).start()

    def do(self, action):
        a = action[0]
        if a == "pick":
            i = action[1]
            self.sel = i
            if i >= len(self.nets):
                self.mode, self.text, self.msg = "ssid", "", ""
            else:
                b = self.nets[i]
                self.link([b["url"]], b.get("edition", ""))
            return True
        if a == "ok" and self.mode == "ssid":
            urls = clean_address(self.text)
            if not urls:
                self.msg = "✗ That doesn't look like an address. Example: 192.168.1.4:8081"; return True
            self.link(urls)
            return True
        return WifiMenu.do(self, action)
