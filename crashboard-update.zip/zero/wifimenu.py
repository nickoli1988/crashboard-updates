"""Keyboard / touchscreen input and the Wi-Fi picker for the Pi Zero screen (fbboard.py).

Keys:   W or F2 = open Wi-Fi   ·   arrows = move   ·   Enter = pick / connect   ·   Esc = back
Touch:  tap the top bar to open Wi-Fi, then tap a network and type on the on-screen keyboard.
Talks to the setup helper (setup/wizard.py, runs as root) at http://127.0.0.1/api/wifi/...
"""
import fcntl, glob, json, os, select, struct, threading, time, urllib.error, urllib.request

WIFI_URL = os.environ.get("CB_WIFI_URL", "http://127.0.0.1:80")
EVFMT = "llHHi"
EVSIZE = struct.calcsize(EVFMT)
EV_KEY, EV_ABS = 1, 3
BTN_TOUCH, BTN_LEFT = 330, 272

# US keyboard: code -> (normal, shifted)
KEYS = {2: "1!", 3: "2@", 4: "3#", 5: "4$", 6: "5%", 7: "6^", 8: "7&", 9: "8*", 10: "9(", 11: "0)", 12: "-_", 13: "=+",
        16: "qQ", 17: "wW", 18: "eE", 19: "rR", 20: "tT", 21: "yY", 22: "uU", 23: "iI", 24: "oO", 25: "pP", 26: "[{", 27: "]}",
        30: "aA", 31: "sS", 32: "dD", 33: "fF", 34: "gG", 35: "hH", 36: "jJ", 37: "kK", 38: "lL", 39: ";:", 40: "'\"", 41: "`~",
        71: "77", 72: "88", 73: "99", 74: "--", 75: "44", 76: "55", 77: "66", 78: "++", 79: "11", 80: "22", 81: "33",
        82: "00", 83: "..", 98: "//", 55: "**",
        43: "\\|", 44: "zZ", 45: "xX", 46: "cC", 47: "vV", 48: "bB", 49: "nN", 50: "mM", 51: ",<", 52: ".>", 53: "/?", 57: "  "}
NAMED = {1: "esc", 14: "backspace", 15: "tab", 28: "enter", 96: "enter", 103: "up", 108: "down", 105: "left", 106: "right",
         104: "pageup", 109: "pagedown", 60: "f2", 59: "f1", 61: "f3"}
SHIFTS = (42, 54)


def _absinfo(fd, code):
    try:
        buf = fcntl.ioctl(fd, 0x80184540 + code, b"\0" * 24)
        _v, mn, mx = struct.unpack("6i", buf)[:3]
        return (mn, mx) if mx > mn else None
    except OSError:
        return None


class Input:
    """Reads every /dev/input/event* device. poll(timeout) returns a list of ("key", name/char) and ("tap", x, y)."""

    def __init__(self, w, h):
        self.w, self.h, self.devs, self.shift, self.caps = w, h, {}, False, False
        self.last_scan = 0
        self.rescan()

    def rescan(self):
        self.last_scan = time.time()
        for path in glob.glob("/dev/input/event*"):
            if path in self.devs:
                continue
            try:
                fd = os.open(path, os.O_RDONLY | os.O_NONBLOCK)
            except OSError:
                continue
            ax = _absinfo(fd, 53) or _absinfo(fd, 0)
            ay = _absinfo(fd, 54) or _absinfo(fd, 1)
            self.devs[path] = {"fd": fd, "ax": ax, "ay": ay, "x": None, "y": None, "down": False}

    @property
    def has_keys(self):
        return bool(self.devs)

    def poll(self, timeout):
        if time.time() - self.last_scan > 10:
            self.rescan()                                   # keyboard plugged in later
        fds = {d["fd"]: (p, d) for p, d in self.devs.items()}
        if not fds:
            time.sleep(max(0, timeout)); return []
        try:
            ready, _, _ = select.select(list(fds), [], [], max(0, timeout))
        except (OSError, ValueError):
            return []
        out = []
        for fd in ready:
            path, d = fds[fd]
            try:
                data = os.read(fd, EVSIZE * 64)
            except OSError:
                os.close(fd); self.devs.pop(path, None); continue
            for i in range(0, len(data) - EVSIZE + 1, EVSIZE):
                _s, _u, typ, code, val = struct.unpack(EVFMT, data[i:i + EVSIZE])
                out += self._event(d, typ, code, val)
        return out

    def _event(self, d, typ, code, val):
        if typ == EV_ABS and d["ax"] and d["ay"]:
            if code in (0, 53):
                mn, mx = d["ax"]; d["x"] = (val - mn) * self.w / float(mx - mn)
            elif code in (1, 54):
                mn, mx = d["ay"]; d["y"] = (val - mn) * self.h / float(mx - mn)
            return []
        if typ != EV_KEY:
            return []
        if code in SHIFTS:
            self.shift = val != 0; return []
        if code == 58 and val == 1:
            self.caps = not self.caps; return []
        if code in (BTN_TOUCH, BTN_LEFT):
            if val == 1:
                d["down"] = True
            elif val == 0 and d["down"]:
                d["down"] = False
                if d["x"] is not None and d["y"] is not None:
                    return [("tap", d["x"], d["y"])]
            return []
        if val not in (1, 2):                               # press or auto-repeat
            return []
        if code in NAMED:
            return [("key", NAMED[code])]
        if code in KEYS:
            ch = KEYS[code][1 if self.shift else 0]
            if self.caps and ch.isalpha():
                ch = ch.swapcase()
            return [("key", ch)]
        return []


def api(path, body=None, timeout=60):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(WIFI_URL + path, data=data, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read())
    except urllib.error.HTTPError as e:
        try:
            return dict(json.loads(e.read()), _code=e.code)
        except ValueError:
            return {"error": "Wi-Fi helper error", "_code": e.code}
    except Exception:
        return {"error": "Wi-Fi helper is not running", "_code": 0}


# on-screen keyboard layers
OSK = {
    "abc": ["1234567890", "qwertyuiop", "asdfghjkl", "zxcvbnm"],
    "ABC": ["1234567890", "QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM"],
    "sym": ["!@#$%^&*()", "-_=+[]{}\\|", ";:'\",.<>/?", "`~ "],
}


class WifiMenu:
    """State machine for the Wi-Fi picker. The screen program calls handle() with input events and draw() to render."""
    TITLE = "WI-FI"
    SSID_LABEL = "NETWORK NAME"
    LIST_HINT = "ARROWS + ENTER TO PICK · R TO RESCAN · ESC TO CLOSE"
    OTHER = "OTHER / HIDDEN NETWORK…"
    TEXT_HINT = "TYPE ON THE KEYBOARD · ENTER = OK · ESC GOES BACK"

    def __init__(self):
        self.open, self.dirty = False, False
        self.reset()

    def reset(self):
        self.mode, self.nets, self.cur, self.sel, self.msg = "list", [], "", 0, ""
        self.ssid, self.text, self.show, self.layer, self.hidden = "", "", False, "abc", False
        self.busy, self.hits, self.touched = False, [], time.time()

    def start(self):
        self.reset(); self.open = True; self.scan()

    def close(self):
        self.open = False

    def scan(self):
        if self.busy:
            return
        self.busy, self.msg = True, "SCANNING…"

        def work():
            r = api("/api/wifi/scan", timeout=60)
            self.nets = (r.get("networks") or [])[:12]
            self.cur = (r.get("current") or {}).get("ssid", "")
            self.msg = r.get("error", "") if "error" in r else ("" if self.nets else "NO NETWORKS FOUND")
            self.sel = 0
            self.busy = False
            self.dirty = True
        threading.Thread(target=work, daemon=True).start()

    def connect(self):
        ssid, pw = self.ssid, self.text
        self.mode, self.msg, self.busy = "connecting", "CONNECTING TO %s…" % ssid.upper(), True

        def work():
            r = api("/api/wifi/connect", {"ssid": ssid, "password": pw, "hidden": self.hidden})
            if r.get("error"):
                self.mode, self.msg, self.busy = "password", "✗ " + r["error"], False; self.dirty = True; return
            for _ in range(120):
                time.sleep(2)
                st = api("/api/wifi/status", timeout=10)
                if st.get("state") == "ok":
                    self.mode, self.msg, self.cur = "done", "✓ CONNECTED TO %s" % ssid.upper(), ssid
                    self.busy = False; self.dirty = True
                    time.sleep(4); self.open = False; self.dirty = True; return
                if st.get("state") == "failed":
                    self.mode, self.msg, self.busy = "password", "✗ " + st.get("error", "failed"), False; self.dirty = True; return
            self.mode, self.msg, self.busy = "password", "✗ Still not connected. Check the name and password and try again.", False; self.dirty = True
        threading.Thread(target=work, daemon=True).start()

    # ---- input
    def items(self):
        return [n["ssid"] for n in self.nets] + [self.OTHER]

    def handle(self, ev):
        self.touched = time.time()
        if ev[0] == "tap":
            for (x0, y0, x1, y1), action in self.hits:
                if x0 <= ev[1] <= x1 and y0 <= ev[2] <= y1:
                    return self.do(action)
            return False
        return self.key(ev[1])

    def key(self, k):
        if self.mode == "connecting":
            return False
        if k == "esc":
            if self.mode in ("password", "ssid"):
                self.mode, self.msg = "list", ""; return True
            self.close(); return True
        if self.mode == "list":
            n = len(self.items())
            if k == "up": self.sel = (self.sel - 1) % n
            elif k == "down": self.sel = (self.sel + 1) % n
            elif k in ("r", "R", "f5"): self.scan()
            elif k == "enter": return self.do(("pick", self.sel))
            else: return False
            return True
        if k == "tab":
            self.show = not self.show; return True
        if k == "backspace":
            self.text = self.text[:-1]; return True
        if k == "enter":
            return self.do(("ok",))
        if len(k) == 1:
            limit = 32 if self.mode == "ssid" else 63
            if len(self.text) < limit:
                self.text += k
            return True
        return False

    def do(self, action):
        a = action[0]
        if a == "pick":
            i = action[1]
            self.sel = i
            if i >= len(self.nets):
                self.mode, self.text, self.hidden, self.msg = "ssid", "", True, ""
            else:
                n = self.nets[i]
                self.ssid, self.hidden, self.text, self.msg = n["ssid"], False, "", ""
                if n.get("secure"):
                    self.mode = "password"
                else:
                    self.connect()
            return True
        if a == "ok":
            if self.mode == "ssid":
                if self.text.strip():
                    self.ssid, self.text, self.mode = self.text.strip(), "", "password"
                return True
            if self.mode == "password":
                if self.text and len(self.text) < 8:
                    self.msg = "Wi-Fi passwords are 8 to 63 characters."; return True
                self.connect(); return True
        if a == "char":
            return self.key(action[1])
        if a == "bksp":
            return self.key("backspace")
        if a == "layer":
            self.layer = action[1]; return True
        if a == "show":
            self.show = not self.show; return True
        if a == "back":
            return self.key("esc")
        if a == "rescan":
            self.scan(); return True
        return False

    # ---- drawing (uses the screen program's helpers, passed in as h)
    def draw(self, img, h):
        C, T, s, font, fit, spaced = h["C"], h["T"], h["s"], h["font"], h["fit"], h["spaced"]
        from PIL import ImageDraw
        d = ImageDraw.Draw(img)
        W, H = img.size
        self.hits = []
        d.rectangle((0, 0, W, H), fill=C["bg"])
        top = 60 * s
        d.rectangle((0, 0, W, top), fill=C["panel"])
        d.line([(0, top), (W, top)], fill=C["line2"], width=max(1, int(2 * s)))
        spaced(d, (20 * s, top / 2), self.TITLE, font("head", 28 * s), C["khaki"], 6 * s, "lm")
        cur = (T("CONNECTED") + ": " + self.cur) if self.cur else T("NOT CONNECTED")
        d.text((170 * s, top / 2), fit(d, cur, font("mono", 14 * s), W - 420 * s), font=font("mono", 14 * s), fill=C["green"] if self.cur else C["dim"], anchor="lm")
        bw = 110 * s
        for i, (lbl, act) in enumerate([("CLOSE", ("back",)), ("SCAN", ("rescan",))] if self.mode == "list" else [("BACK", ("back",))]):
            x1 = W - 14 * s - i * (bw + 10 * s); x0 = x1 - bw
            d.rectangle((x0, 12 * s, x1, top - 12 * s), outline=C["line2"])
            d.text(((x0 + x1) / 2, top / 2), T(lbl), font=font("monob", 13 * s), fill=C["text"], anchor="mm")
            self.hits.append(((x0, 0, x1, top), act))
        y = top + 16 * s
        if self.msg:
            col = C["red"] if self.msg.startswith("✗") else C["green"] if self.msg.startswith("✓") else C["amber"]
            d.text((20 * s, y + 10 * s), fit(d, T(self.msg), font("monob", 15 * s), W - 40 * s), font=font("monob", 15 * s), fill=col, anchor="lm")
            y += 34 * s
        if self.mode == "list":
            rh = 44 * s
            items = self.items()
            for i, name in enumerate(items):
                if y + rh > H - 40 * s:
                    break
                on = i == self.sel
                d.rectangle((20 * s, y, W - 20 * s, y + rh - 6 * s), fill=C["panel2"] if on else C["panel"], outline=C["green"] if on else C["line"], width=max(1, int((2 if on else 1) * s)))
                if i < len(self.nets):
                    n = self.nets[i]
                    bars = 4 if n["signal"] > 75 else 3 if n["signal"] > 50 else 2 if n["signal"] > 25 else 1
                    for b in range(4):
                        bh = (b + 1) * 5 * s
                        d.rectangle((34 * s + b * 7 * s, y + rh / 2 + 8 * s - bh, 38 * s + b * 7 * s, y + rh / 2 + 8 * s), fill=C["green"] if b < bars else C["faint"])
                    d.text((80 * s, y + (rh - 6 * s) / 2), fit(d, name + ("  ✓" if name == self.cur else ""), font("monob", 17 * s), W - 200 * s), font=font("monob", 17 * s), fill=C["text"], anchor="lm")
                    if n.get("secure"):
                        d.text((W - 40 * s, y + (rh - 6 * s) / 2), "LOCK", font=font("mono", 11 * s), fill=C["dim"], anchor="rm")
                else:
                    d.text((80 * s, y + (rh - 6 * s) / 2), T(name), font=font("mono", 16 * s), fill=C["dim"], anchor="lm")
                self.hits.append(((20 * s, y, W - 20 * s, y + rh - 6 * s), ("pick", i)))
                y += rh
            d.text((W / 2, H - 18 * s), T(self.LIST_HINT), font=font("mono", 11 * s), fill=C["faint"], anchor="mm")
            return
        if self.mode in ("connecting", "done"):
            d.text((W / 2, H / 2), fit(d, T(self.msg), font("head", 30 * s), W - 40 * s), font=font("head", 30 * s), fill=C["green"], anchor="mm")
            return
        # text entry (network name or password) + on-screen keyboard
        label = T(self.SSID_LABEL) if self.mode == "ssid" else "%s · %s" % (T("WI-FI PASSWORD"), self.ssid)
        d.text((20 * s, y + 8 * s), fit(d, label, font("mono", 13 * s), W - 40 * s), font=font("mono", 13 * s), fill=C["dim"], anchor="lm")
        y += 24 * s
        shown = self.text if (self.show or self.mode == "ssid") else "•" * len(self.text)
        d.rectangle((20 * s, y, W - 20 * s, y + 46 * s), fill="#0c0f09", outline=C["line2"])
        d.text((32 * s, y + 23 * s), fit(d, shown + "_", font("monob", 20 * s), W - 70 * s), font=font("monob", 20 * s), fill=C["text"], anchor="lm")
        y += 58 * s
        rows = OSK[self.layer]
        kh = min(52 * s, (H - y - 70 * s) / (len(rows) + 1))
        gap = 6 * s
        for r, row in enumerate(rows):
            n = 10
            kw = (W - 40 * s - gap * (n - 1)) / n
            x = 20 * s + (n - len(row)) * (kw + gap) / 2
            for ch in row:
                x0, y0 = x, y + r * (kh + gap)
                d.rectangle((x0, y0, x0 + kw, y0 + kh), fill=C["panel2"], outline=C["line"])
                d.text((x0 + kw / 2, y0 + kh / 2), "␣" if ch == " " else ch, font=font("monob", 18 * s), fill=C["text"], anchor="mm")
                self.hits.append(((x0, y0, x0 + kw, y0 + kh), ("char", ch)))
                x += kw + gap
        y0 = y + len(rows) * (kh + gap)
        specials = [("SHIFT" if self.layer != "ABC" else "abc", ("layer", "ABC" if self.layer != "ABC" else "abc"), 1.4),
                    ("#+=" if self.layer != "sym" else "abc", ("layer", "sym" if self.layer != "sym" else "abc"), 1.4),
                    ("SPACE", ("char", " "), 3), ("DEL", ("bksp",), 1.4),
                    (T("HIDE") if self.show else T("SHOW"), ("show",), 1.6), (T("CONNECT") if self.mode == "password" else "OK", ("ok",), 2.2)]
        total = sum(w for _, _, w in specials)
        unit = (W - 40 * s - gap * (len(specials) - 1)) / total
        x = 20 * s
        for lbl, act, w in specials:
            x1 = x + unit * w
            hot = act[0] == "ok"
            d.rectangle((x, y0, x1, y0 + kh), fill=C["green"] if hot else C["panel2"], outline=C["line"])
            d.text(((x + x1) / 2, y0 + kh / 2), lbl, font=font("monob", 15 * s), fill=C["ink"] if hot else C["text"], anchor="mm")
            self.hits.append(((x, y0, x1, y0 + kh), act))
            x = x1 + gap
        d.text((W / 2, H - 14 * s), T(self.TEXT_HINT if self.mode == "ssid" else "TYPE ON THE KEYBOARD · TAB SHOWS THE PASSWORD · ENTER CONNECTS · ESC GOES BACK"), font=font("mono", 10 * s), fill=C["faint"], anchor="mm")
