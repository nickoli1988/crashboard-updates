#!/usr/bin/env python3
"""CRASH BOARD start-up splash (SD-card image).

Runs as root from crashboard-splash.service a few seconds after power-on and draws the logo
plus a status line straight onto the screen:  STARTING UP -> CONNECTING TO WI-FI -> LOADING THE BOARD.
It stops by itself as soon as the board (fbboard.py) or the kiosk browser (Xorg) takes over the
screen, or after a few minutes. If anything goes wrong it just exits, and the Pi starts normally.

Test without a Pi:  CB_FB_OUT=splash.png python3 zero/splash.py --once "CONNECTING TO WI-FI"
"""
import fcntl, json, os, re, socket, sys, time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import fbboard as fb                                   # noqa: E402  (same colours, fonts and logo as the board)
from PIL import Image, ImageDraw                       # noqa: E402

APP, DATA = fb.APP, fb.DATA
TTY = os.environ.get("CB_SPLASH_TTY", "/dev/tty1")
TIMEOUT = float(os.environ.get("CB_SPLASH_TIMEOUT", "240"))
KDSETMODE, KD_TEXT, KD_GRAPHICS = 0x4B3A, 0, 1


def version():
    try:
        m = re.search(r'^VERSION = "([^"]+)"', open(os.path.join(APP, "server.py")).read(), re.M)
        return m.group(1) if m else ""
    except OSError:
        return ""


def theme():
    try:
        return json.load(open(os.path.join(DATA, "config.json"))).get("theme") or "ops"
    except (OSError, ValueError):
        return "ops"


def tty_mode(mode):
    try:
        with open(TTY, "wb") as t:
            fcntl.ioctl(t, KDSETMODE, mode)
        if mode == KD_GRAPHICS:
            with open(TTY, "w") as t:
                t.write("\033[?25l")                   # hide the text cursor too
    except OSError:
        pass


def taken_over():
    """True once the board program or the kiosk's X server is running."""
    for pid in os.listdir("/proc"):
        if not pid.isdigit():
            continue
        try:
            argv = open("/proc/%s/cmdline" % pid, "rb").read().split(b"\0")
        except OSError:
            continue
        exe = os.path.basename(argv[0])
        if exe.startswith(b"python") and len(argv) > 1 and argv[1].endswith(b"zero/fbboard.py"):
            return True
        if exe in (b"Xorg", b"X"):
            return True
    return False


def online():
    try:
        for line in open("/proc/net/route").read().splitlines()[1:]:
            f = line.split()
            if len(f) > 2 and f[1] == "00000000" and f[0] != "lo":
                return True
    except OSError:
        pass
    return False


def board_answers():
    port = 8090 if fb.MESH else 8080
    try:
        port = int(open(os.path.join(DATA, "port.txt")).read().strip())
    except (OSError, ValueError):
        pass
    try:
        socket.create_connection(("127.0.0.1", port), timeout=1).close()
        return True
    except OSError:
        return False


def status():
    if not os.path.exists(os.path.join(DATA, "setup-done.json")) and os.path.exists("/etc/crashboard-image"):
        return "GETTING FIRST-TIME SETUP READY"
    if not online():
        return "CONNECTING TO WI-FI"
    if os.path.exists(os.path.join(DATA, "display.conf")) or board_answers():
        return "LOADING THE BOARD"
    return "STARTING THE BOARD"


def frame(W, H, msg, tick, ver):
    s = min(W / 1280.0, H / 720.0)
    img = Image.new("RGB", (W, H), fb.C["bg"])
    d = ImageDraw.Draw(img)
    band = int(14 * s)
    fb.stripes(img, (0, 0, W, band), fb.C["amber"], int(36 * s))      # hazard bands top and bottom
    fb.stripes(img, (0, H - band, W, H), fb.C["amber"], int(36 * s))
    cy = H * 0.42
    hf = fb.font("head", 96 * s)
    fb.shield(d, W / 2, cy, 120 * s, fb.C["orange"], fb.C["bg"])
    fb.spaced(d, (W / 2 - 92 * s, cy), "CRASH", hf, fb.C["khaki"], 22 * s, "rm")
    fb.spaced(d, (W / 2 + 92 * s, cy), "BOARD", hf, fb.C["khaki"], 22 * s, "lm")
    sub = "GLOBAL THREAT MONITOR" + (" · MESH" if fb.MESH else "")
    sf = fb.font("mono", 18 * s)
    sw = fb.spaced(ImageDraw.Draw(Image.new("RGB", (1, 1))), (0, 0), sub, sf, fb.C["dim"], 7 * s)
    bw = 40 * s                                            # V1 tag sits after the subtitle, the pair centred
    x = W / 2 - (sw + 24 * s + bw) / 2
    fb.spaced(d, (x, cy + 104 * s), sub, sf, fb.C["dim"], 7 * s, "lm")
    fb.v1_badge(d, x + sw + 24 * s, cy + 104 * s, 20 * s, fb.C["khaki"])
    return img, s


def status_box(W, H, s):
    return (0, int(H * 0.42 + 150 * s), W, int(H * 0.42 + 250 * s))


def draw_status(img, s, msg, tick):
    W, H = img.size
    d = ImageDraw.Draw(img)
    box = status_box(W, H, s)
    d.rectangle(box, fill=fb.C["bg"])
    y = box[1] + 22 * s
    dots = "." * (tick % 4)
    f = fb.font("monob", 22 * s)
    tw = d.textlength(msg + "...", font=f)
    d.text((W / 2 - tw / 2, y), msg + dots, font=f, fill=fb.C["green"], anchor="lm")
    n, cw, gap = 16, 26 * s, 6 * s                     # segmented progress bar with a moving bright block
    x0 = W / 2 - (n * cw + (n - 1) * gap) / 2
    by = y + 34 * s
    for i in range(n):
        lit = (i - tick) % n in (0, 1, 2)
        d.rectangle((x0 + i * (cw + gap), by, x0 + i * (cw + gap) + cw, by + 12 * s),
                    fill=fb.C["green"] if lit else fb.C["panel2"], outline=fb.C["line2"])
    return box


def main():
    fb.set_theme(theme())
    ver = version()
    once = "--once" in sys.argv
    if once:
        args = [a for a in sys.argv[1:] if a != "--once"]
        scr = fb.Screen()
        img, s = frame(scr.w, scr.h, "", 0, ver)
        draw_status(img, s, args[0] if args else "STARTING UP", 5)
        d = ImageDraw.Draw(img)
        d.text((24 * s, scr.h - 34 * s), "LL3D · LIBERTY LABS", font=fb.font("mono", max(11, 13 * s)), fill=fb.C["faint"], anchor="lm")
        d.text((scr.w - 24 * s, scr.h - 34 * s), "v" + ver, font=fb.font("mono", max(11, 13 * s)), fill=fb.C["faint"], anchor="rm")
        scr.show(img)
        return
    if taken_over():
        return
    os.environ.pop("CB_FB_OUT", None)
    for _ in range(40):                                # the screen driver can take a moment to appear
        if os.path.exists("/dev/fb0") and os.path.exists("/sys/class/graphics/fb0/virtual_size"):
            break
        time.sleep(0.25)
    scr = fb.Screen()                                  # opens /dev/fb0
    tty_mode(KD_GRAPHICS)
    img, s = frame(scr.w, scr.h, "", 0, ver)
    d = ImageDraw.Draw(img)
    d.text((24 * s, scr.h - 34 * s), "LL3D · LIBERTY LABS", font=fb.font("mono", max(11, 13 * s)), fill=fb.C["faint"], anchor="lm")
    d.text((scr.w - 24 * s, scr.h - 34 * s), "v" + ver, font=fb.font("mono", max(11, 13 * s)), fill=fb.C["faint"], anchor="rm")
    msg = "STARTING UP"
    draw_status(img, s, msg, 0)
    scr.show(img)
    t0, tick, last_full = time.time(), 0, time.time()
    while time.time() - t0 < TIMEOUT:
        time.sleep(0.5)
        if taken_over():
            return                                     # the board draws from here on
        tick += 1
        if tick % 4 == 0:
            msg = status()
        box = draw_status(img, s, msg, tick)
        if time.time() - last_full > 5:                # repaint everything now and then (covers stray console text)
            tty_mode(KD_GRAPHICS); scr.show(img); last_full = time.time()
        else:
            scr.show(img, box)
    tty_mode(KD_TEXT)                                  # nothing took over: give the console back


if __name__ == "__main__":
    try:
        main()
    except Exception as e:                             # never get in the way of starting up
        print("splash:", e, file=sys.stderr)
