@echo off
rem CRASH BOARD - prepare a freshly flashed Raspberry Pi SD card so it installs Crash Board by itself.
rem 1. Flash Raspberry Pi OS Lite (32-bit) with Raspberry Pi Imager (set username, password, Wi-Fi).
rem 2. Re-insert the card, then double-click this file.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0sdcard\prepare-sd-card.ps1"
