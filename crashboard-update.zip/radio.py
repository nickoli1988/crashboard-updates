"""RADIO: listen to FM / AM / NOAA Weather Radio and decode NOAA alerts (SAME) off the air.

Hardware: an RTL-SDR USB stick (RTL-SDR Blog V4 recommended). Software: the rtl-sdr command-line tools
(rtl_fm, rtl_power, rtl_test). On Windows they live in tools\\rtl-sdr\\ (get-radio-tools.bat fetches them);
on a Pi the RADIO page's INSTALL RADIO SUPPORT button installs them (see RadioInstaller below).

How it works
  * WATCH: rtl_fm tunes your NOAA Weather Radio channel. The audio goes through a SAME decoder (the
    digital burst at the start of every NWS warning). A warning for your county turns the board
    ORANGE/RED with no internet needed.
  * LISTEN: the browser plays any station. With one stick, listening to something other than NOAA
    pauses WATCH (internet alerts keep working) and WATCH resumes as soon as you stop. With two sticks,
    stick 1 watches NOAA nonstop and stick 2 is for listening.

Audio is sent to the browser as raw 16-bit mono PCM; the page plays it with the Web Audio API.
The SAME decoder is pure Python (no numpy needed).
"""
import cmath
import math
import os
import queue
import re
import shutil
import subprocess
import sys
import threading
import time
import json
import urllib.request
import zipfile

BASE = os.path.dirname(os.path.abspath(__file__))
EXE = ".exe" if os.name == "nt" else ""
NOAA_CHANNELS = (162.400, 162.425, 162.450, 162.475, 162.500, 162.525, 162.550)
WATCH_RATE = 11025              # audio rate for NOAA (voice + SAME tones up to 2.1 kHz)
DEFAULT = {
    "enabled": False,
    "noaa_freq": 162.550,
    "watch": True,              # decode NOAA alerts when the SDR isn't busy
    "ppm": 0,                   # frequency correction (the V4 has a 1 PPM TCXO, so 0 is fine)
    "gain": "",                 # "" = automatic, or a number in dB like 30
    "presets": [
        {"name": "NOAA WEATHER", "freq": 162.550, "band": "noaa"},
    ],
}
BANDS = {"fm": "FM", "am": "AM", "noaa": "NOAA"}

# ------------------------------------------------------------------ SAME event codes
# level: 3 = RED, 2 = ORANGE, 1 = YELLOW, 0 = information / tests (never alarms)
EVENTS = {
    "EAN": ("Emergency Action Notification", 3), "NIC": ("National Information Center", 0),
    "TOR": ("Tornado Warning", 3), "SVR": ("Severe Thunderstorm Warning", 2), "SVS": ("Severe Weather Statement", 1),
    "SPS": ("Special Weather Statement", 1), "FFW": ("Flash Flood Warning", 2), "FFA": ("Flash Flood Watch", 1),
    "FFS": ("Flash Flood Statement", 1), "FLW": ("Flood Warning", 2), "FLA": ("Flood Watch", 1), "FLS": ("Flood Statement", 1),
    "TOA": ("Tornado Watch", 1), "SVA": ("Severe Thunderstorm Watch", 1), "WSW": ("Winter Storm Warning", 2),
    "WSA": ("Winter Storm Watch", 1), "BZW": ("Blizzard Warning", 2), "HWW": ("High Wind Warning", 2), "HWA": ("High Wind Watch", 1),
    "EWW": ("Extreme Wind Warning", 3), "HUW": ("Hurricane Warning", 3), "HUA": ("Hurricane Watch", 1),
    "HLS": ("Hurricane Statement", 1), "TRW": ("Tropical Storm Warning", 2), "TRA": ("Tropical Storm Watch", 1),
    "SSW": ("Storm Surge Warning", 2), "SSA": ("Storm Surge Watch", 1), "TSW": ("Tsunami Warning", 3), "TSA": ("Tsunami Watch", 1),
    "SMW": ("Special Marine Warning", 1), "DSW": ("Dust Storm Warning", 2), "AVW": ("Avalanche Warning", 2), "AVA": ("Avalanche Watch", 1),
    "EQW": ("Earthquake Warning", 2), "FRW": ("Fire Warning", 2), "VOW": ("Volcano Warning", 2),
    "CEM": ("Civil Emergency Message", 3), "CDW": ("Civil Danger Warning", 3), "EVI": ("Evacuation Immediate", 3),
    "HMW": ("Hazardous Materials Warning", 3), "NUW": ("Nuclear Power Plant Warning", 3), "RHW": ("Radiological Hazard Warning", 3),
    "SPW": ("Shelter in Place Warning", 3), "LAE": ("Local Area Emergency", 2), "LEW": ("Law Enforcement Warning", 2),
    "TOE": ("911 Telephone Outage Emergency", 1), "CAE": ("Child Abduction Emergency", 1), "BLU": ("Blue Alert", 1),
    "ADR": ("Administrative Message", 0), "RWT": ("Required Weekly Test", 0), "RMT": ("Required Monthly Test", 0),
    "DMO": ("Practice/Demo Warning", 0), "NPT": ("National Periodic Test", 0), "NMN": ("Network Message Notification", 0),
}
SEVERITY = {3: "Extreme", 2: "Severe", 1: "Moderate", 0: "Minor"}
SAME_RE = re.compile(r"^ZCZC-([A-Z]{3})-([A-Z]{3})-((?:\d{6}-?)+)\+(\d{4})-(\d{7})-([^-]{1,8})-?$")


def parse_same(msg):
    m = SAME_RE.match(msg.strip())
    if not m:
        return None
    org, ev, locs, dur, issued, sender = m.groups()
    locs = [x for x in locs.split("-") if x]
    name, level = EVENTS.get(ev, ("%s alert" % ev, 1 if ev.endswith(("W", "A", "S")) else 0))
    if ev.endswith("W") and ev not in EVENTS:
        level = 2
    hours, mins = int(dur[:2]), int(dur[2:])
    return {"org": org, "code": ev, "event": name, "level": level, "locations": locs,
            "duration_s": hours * 3600 + mins * 60, "issued": issued, "sender": sender.strip(), "raw": msg.strip()}


def same_matches(locs, fips5):
    """True if any SAME location (PSSCCC) covers county fips5 (SSCCC). 000000 = everywhere, SS000 = whole state."""
    if not fips5:
        return None                        # unknown county
    st = fips5[:2]
    for l in locs:
        l = l[-5:]
        if l == "00000" or l == fips5 or l == st + "000":
            return True
    return False


# ------------------------------------------------------------------ SAME (AFSK) decoder
class SameDecoder:
    """520.83 baud FSK, mark 2083.3 Hz (1), space 1562.5 Hz (0), bytes LSB first, preamble 0xAB x16.
    Non-coherent detector (running tone correlators over one bit) plus a simple bit-clock PLL."""
    BAUD = 520.0 + 5.0 / 6.0

    def __init__(self, rate, on_message):
        self.rate = rate
        self.on_message = on_message
        self.spb = rate / self.BAUD
        n = self.n = int(round(self.spb))
        self.rm = cmath.exp(-2j * math.pi * 2083.3333 / rate)
        self.rs = cmath.exp(-2j * math.pi * 1562.5 / rate)
        self.pm = 1 + 0j
        self.ps = 1 + 0j
        self.bm = [0j] * n
        self.bs = [0j] * n
        self.sm = 0j
        self.ss = 0j
        self.i = 0
        self.k = 0
        self.last = 0
        self.phase = 0.0
        self.reg = 0
        self.synced = False
        self.nbits = 0
        self.buf = bytearray()
        self.copies = []                   # header copies waiting to be voted on
        self._vlock = threading.Lock()
        self.level = 0.0
        self.dc = 0.0

    def feed(self, pcm):
        rm, rs, n, spb = self.rm, self.rs, self.n, self.spb
        pm, ps, bm, bs, sm, ss, i = self.pm, self.ps, self.bm, self.bs, self.sm, self.ss, self.i
        last, phase, dc = self.last, self.phase, self.dc
        half = spb / 2.0
        mv = memoryview(pcm).cast("h") if len(pcm) % 2 == 0 else memoryview(pcm[:-1]).cast("h")
        for s in mv:
            x = s - dc
            dc += x * 0.002
            pm *= rm
            ps *= rs
            vm = x * pm
            vs = x * ps
            sm += vm - bm[i]
            ss += vs - bs[i]
            bm[i] = vm
            bs[i] = vs
            i += 1
            if i == n:
                i = 0
                pm /= abs(pm)
                ps /= abs(ps)
            em = sm.real * sm.real + sm.imag * sm.imag
            es = ss.real * ss.real + ss.imag * ss.imag
            bit = 1 if em > es else 0
            if bit != last:                     # transition: pull the clock so edges land at phase 0
                last = bit
                if phase < half:
                    phase -= phase * 0.35
                else:
                    phase += (spb - phase) * 0.35
            phase += 1.0
            if phase >= spb:
                phase -= spb
            elif half <= phase < half + 1.0:   # middle of a bit: take it
                self._bit(bit, em + es)
        self.pm, self.ps, self.sm, self.ss, self.i = pm, ps, sm, ss, i
        self.last, self.phase, self.dc = last, phase, dc

    def _bit(self, b, energy):
        self.reg = (self.reg >> 1) | (b << 7)
        if not self.synced:
            if self.reg == 0xAB:
                self.synced = True
                self.nbits = 0
                self.buf = bytearray()
            return
        self.nbits += 1
        if self.nbits < 8:
            return
        self.nbits = 0
        c = self.reg
        if c == 0xAB and not self.buf:
            return                              # still in the preamble
        if 32 <= c < 127 and len(self.buf) < 268:
            self.buf.append(c)
            txt = self.buf.decode("ascii", "ignore")
            if txt == "NNNN" or (txt.startswith("ZCZC") and SAME_RE.match(txt) and txt.endswith("-") and txt.count("-") >= 6 and self._complete(txt)):
                self._done(txt)
            return
        self._done(self.buf.decode("ascii", "ignore"))

    @staticmethod
    def _complete(txt):
        # ZCZC-ORG-EEE-PSSCCC...+TTTT-JJJHHMM-LLLLLLLL- : sender field ends with the last '-'
        parts = txt.rstrip("-").split("-")
        return len(parts) >= 6 and "+" in txt and re.match(r"^\d{7}$", parts[-2] or "") is not None

    def _done(self, txt):
        self.synced = False
        self.buf = bytearray()
        if txt == "NNNN":
            t = time.time()
            if t - getattr(self, "_nnnn", 0) > 10:
                self._nnnn = t
                self.on_message(txt)
            return
        if not txt.startswith("ZCZC"):
            return
        # NWS sends every header 3 times about 1 s apart. Collect the copies, then vote character by
        # character, so a bit error in one copy can't create a false (or garbled) alarm.
        with self._vlock:
            first = not self.copies
            self.copies.append(txt)
        if first:
            threading.Timer(3.8, self._vote).start()

    def _vote(self):
        with self._vlock:
            copies, self.copies = self.copies, []
        if not copies:
            return
        if len(copies) >= 2:
            L = max(set(len(c) for c in copies), key=lambda n: sum(1 for c in copies if len(c) == n))
            same = [c for c in copies if len(c) == L]
            if len(same) >= 2:
                txt = "".join(max(set(col), key=col.count) for col in zip(*same))
            else:
                txt = same[0]
        else:
            txt = copies[0]
        a = parse_same(txt)
        if not a:
            return
        if len(copies) < 2 and a["code"] not in EVENTS:
            return                               # one copy only and an unknown code: likely noise
        self.on_message(txt)


# ------------------------------------------------------------------ the radio itself
def find_tool(name):
    places = [BASE]
    if getattr(sys, "frozen", False):                # CrashBoard.exe: tools sit next to the program,
        places.append(os.path.dirname(sys.executable))   # or in the user's Crash Board data folder
    if os.environ.get("CRASHBOARD_DATA"):
        places.append(os.environ["CRASHBOARD_DATA"])
    for p in places:
        local = os.path.join(p, "tools", "rtl-sdr", name + EXE)
        if os.path.isfile(local):
            return local
    return shutil.which(name)


class Radio:
    def __init__(self, log, on_alert):
        self.log = log
        self.on_alert = on_alert            # called with an alert dict
        self.cfg = dict(DEFAULT)
        self.lock = threading.RLock()
        self.fips = ""
        self.devices = 0
        self.tools = {}
        self.watch_proc = None
        self.listen_proc = None
        self.station = None                 # what the browser is playing
        self.clients = []                   # (queue, rate)
        self.rate = WATCH_RATE
        self.messages = []                  # decoded SAME messages, newest first
        self.error = ""
        self.watch_state = "off"
        self.last_listener = 0
        self.scan_result = None
        self._stop = False
        threading.Thread(target=self._supervisor, daemon=True, name="radio").start()

    # -------------------------------------------------- setup
    def configure(self, cfg, fips=""):
        with self.lock:
            self.cfg = dict(DEFAULT)
            self.cfg.update(cfg or {})
            self.fips = fips or ""
        self.refresh_hw()

    def refresh_hw(self):
        self.tools = {t: find_tool(t) for t in ("rtl_fm", "rtl_power", "rtl_test")}
        n = 0
        if self.tools.get("rtl_test"):
            try:
                out = subprocess.run([self.tools["rtl_test"], "-t"], capture_output=True, text=True, timeout=8,
                                     **_nowin()).stderr
                m = re.search(r"Found (\d+) device", out)
                n = int(m.group(1)) if m else 0
            except Exception as e:
                self.error = "rtl_test failed: %s" % e
        self.devices = n

    def _args(self, dev, freq_hz, band):
        a = [self.tools["rtl_fm"], "-d", str(dev), "-f", str(int(freq_hz))]
        if band == "fm":
            a += ["-M", "wbfm"]                                  # 32 kHz output
            rate = 32000
        elif band == "am":
            a += ["-M", "am", "-s", "12000", "-r", "12000"]
            rate = 12000
        else:                                                    # noaa / narrow FM
            a += ["-M", "fm", "-s", "22050", "-r", str(WATCH_RATE), "-E", "dc"]
            rate = WATCH_RATE
        if self.cfg.get("ppm"):
            a += ["-p", str(int(self.cfg["ppm"]))]
        g = str(self.cfg.get("gain") or "").strip()
        if g:
            a += ["-g", g]
        return a + ["-"], rate

    # -------------------------------------------------- processes
    def _spawn(self, args):
        return subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, bufsize=0, **_nowin())

    def _kill(self, p):
        if p and p.poll() is None:
            try:
                p.terminate()
                p.wait(3)
            except Exception:
                try:
                    p.kill()
                except Exception:
                    pass

    def _pump(self, p, decoder, share_with_listeners, rate):
        """Read audio from rtl_fm: feed the SAME decoder and/or the browser listeners."""
        err = []
        threading.Thread(target=lambda: err.extend(p.stderr.read().decode("utf-8", "ignore").splitlines()[-6:]),
                         daemon=True).start()
        while not self._stop:
            chunk = p.stdout.read(4096)
            if not chunk:
                break
            if decoder:
                try:
                    decoder.feed(chunk)
                except Exception as e:
                    self.log("radio: decoder error", e)
            if share_with_listeners():
                self._broadcast(chunk)
        p.wait()
        msg = " ".join(l.strip() for l in err if l.strip())
        if "usb_claim_interface" in msg or "No supported devices" in msg or "Failed to open" in msg:
            self.error = "Can't open the SDR stick (unplugged, in use by another program, or driver not installed)."
        elif msg and p.returncode not in (0, None, -15, 1):
            self.error = msg[-200:]

    def _start_watch(self):
        f = float(self.cfg.get("noaa_freq") or 162.55)
        args, rate = self._args(0, f * 1e6, "noaa")
        dec = SameDecoder(rate, self._same)
        self.watch_proc = p = self._spawn(args)
        self.watch_state = "watching"
        self.log("radio: watching NOAA %.3f MHz for alerts" % f)
        share = lambda: bool(self.station and self.station.get("band") == "noaa" and self.listen_proc is None)
        threading.Thread(target=self._pump, args=(p, dec, share, rate), daemon=True).start()

    def _supervisor(self):
        """Keep NOAA watch running when it should be; hand the stick back after listening stops."""
        while not self._stop:
            time.sleep(2)
            try:
                with self.lock:
                    enabled = self.cfg.get("enabled") and self.tools.get("rtl_fm") and self.devices > 0
                    if not enabled:
                        self._kill(self.watch_proc); self.watch_proc = None
                        self.watch_state = "off"
                        continue
                    # listeners gone for 20 s: stop listening (gives NOAA watch back on a 1-stick setup)
                    if self.station and not self.clients and time.time() - self.last_listener > 20:
                        self._stop_listen_locked()
                    one_stick = self.devices < 2
                    busy = self.listen_proc is not None and one_stick
                    want = self.cfg.get("watch", True) and not busy
                    if want and (self.watch_proc is None or self.watch_proc.poll() is not None):
                        if self.watch_proc is not None and self.watch_proc.poll() is not None:
                            time.sleep(3)          # it died: don't spin
                        self._start_watch()
                    elif not want:
                        if self.watch_proc:
                            self._kill(self.watch_proc); self.watch_proc = None
                        self.watch_state = "paused" if busy else "off"
            except Exception as e:
                self.error = str(e)[:200]

    # -------------------------------------------------- listening
    def listen(self, station):
        band = station.get("band") if station.get("band") in BANDS else "fm"
        freq = float(station.get("freq") or 0)
        if band == "am" and not 0.5 <= freq <= 1.8 and not 500 <= freq <= 1800:
            raise ValueError("AM is 530-1700 kHz")
        if band == "am" and freq > 100:
            freq = freq / 1000.0                                   # kHz -> MHz
        if band == "fm" and not 76 <= freq <= 108.1:
            raise ValueError("FM is 88-108 MHz")
        if band == "noaa" and not 162.3 <= freq <= 162.6:
            raise ValueError("NOAA channels are 162.400-162.550 MHz")
        if not self.tools.get("rtl_fm") or self.devices < 1:
            raise ValueError("No SDR stick found")
        with self.lock:
            self._stop_listen_locked()
            self.station = {"name": station.get("name") or "", "freq": freq, "band": band}
            self.last_listener = time.time()
            watch_same = band == "noaa" and abs(freq - float(self.cfg.get("noaa_freq") or 0)) < 0.001
            if watch_same and self.watch_proc and self.watch_proc.poll() is None and self.cfg.get("watch", True):
                self.rate = WATCH_RATE                             # just share the NOAA watch audio
                return self.status()
            if self.devices < 2:
                self._kill(self.watch_proc); self.watch_proc = None
                self.watch_state = "paused"
                time.sleep(0.6)                                    # let the stick go
            dev = 1 if self.devices >= 2 else 0
            args, rate = self._args(dev, freq * 1e6, band)
            self.rate = rate
            self.listen_proc = p = self._spawn(args)
            self.log("radio: listening to %s %.3f MHz" % (band.upper(), freq))
            dec = SameDecoder(rate, self._same) if band == "noaa" else None
            threading.Thread(target=self._pump, args=(p, dec, lambda: True, rate), daemon=True).start()
        return self.status()

    def _stop_listen_locked(self):
        self._kill(self.listen_proc)
        self.listen_proc = None
        self.station = None
        for q, _ in list(self.clients):
            try:
                q.put_nowait(None)
            except queue.Full:
                pass

    def stop(self):
        with self.lock:
            self._stop_listen_locked()
        return self.status()

    def _broadcast(self, chunk):
        for q, _ in list(self.clients):
            try:
                q.put_nowait(chunk)
            except queue.Full:
                pass                          # slow listener: skip a chunk rather than lag

    def subscribe(self):
        q = queue.Queue(maxsize=64)
        with self.lock:
            self.clients.append((q, self.rate))
            self.last_listener = time.time()
        return q, self.rate

    def unsubscribe(self, q):
        with self.lock:
            self.clients = [c for c in self.clients if c[0] is not q]
            self.last_listener = time.time()

    # -------------------------------------------------- NOAA channel scan
    def scan_noaa(self):
        if not self.tools.get("rtl_power"):
            raise ValueError("rtl_power not found")
        with self.lock:
            self._stop_listen_locked()
            self._kill(self.watch_proc); self.watch_proc = None
            self.watch_state = "scanning"
            time.sleep(0.6)
            try:
                out = subprocess.run([self.tools["rtl_power"], "-d", "0", "-f", "162.3875M:162.5625M:6.25k", "-i", "4", "-1", "-"],
                                     capture_output=True, text=True, timeout=40, **_nowin()).stdout
            finally:
                self.watch_state = "off"
        bins = []
        for line in out.splitlines():
            p = [x.strip() for x in line.split(",")]
            if len(p) < 7:
                continue
            lo, step = float(p[2]), float(p[4])
            for k, db in enumerate(p[6:]):
                try:
                    bins.append((lo + (k + 0.5) * step, float(db)))
                except ValueError:
                    pass
        res = []
        for ch in NOAA_CHANNELS:
            near = [db for f, db in bins if abs(f - ch * 1e6) <= 6250]
            if near:
                res.append({"freq": ch, "db": round(max(near), 1)})
        if not res:
            raise ValueError("scan returned no data")
        floor = sorted(r["db"] for r in res)[0]
        for r in res:
            r["above_noise"] = round(r["db"] - floor, 1)
        best = max(res, key=lambda r: r["db"])
        self.scan_result = {"channels": res, "best": best["freq"], "time": time.time()}
        return self.scan_result

    # -------------------------------------------------- decoded alerts
    def _same(self, txt):
        t = time.time()
        if txt == "NNNN":
            self.log("radio: SAME end of message")
            return
        a = parse_same(txt)
        if not a:
            self.log("radio: SAME header not understood:", txt)
            return
        a["time"] = t
        a["expires"] = t + max(900, a["duration_s"])
        a["local"] = same_matches(a["locations"], self.fips)
        self.log("radio: SAME", a["code"], a["event"], {True: "for this county", False: "for another county", None: "county unknown"}[a["local"]], a["raw"])
        with self.lock:
            self.messages = ([a] + [m for m in self.messages if m["raw"] != a["raw"]])[:30]
        try:
            self.on_alert(a)
        except Exception as e:
            self.log("radio: alert hook failed", e)

    def active_alerts(self):
        """Decoded warnings still in force, shaped like the board's NWS alerts."""
        t = time.time()
        out = []
        for a in list(self.messages):
            if a["level"] <= 0 or a["expires"] < t:
                continue
            local = a["local"] is not False
            out.append({
                "id": "radio:" + a["raw"], "event": a["event"] + " (NOAA radio)", "severity": SEVERITY[a["level"]],
                "urgency": "Immediate", "certainty": "Observed",
                "headline": "NOAA RADIO: " + a["event"].upper(), "area": "Received on NOAA Weather Radio (%s)" % a["sender"],
                "onset": int(a["time"]), "expires": int(a["expires"]), "instruction": "",
                "description": "Decoded off the air with no internet: " + a["raw"],
                "rank": a["level"] + 1, "local": local, "source": "radio",
            })
        return out

    def status(self):
        with self.lock:
            st = dict(self.station) if self.station else None
            return {
                "enabled": bool(self.cfg.get("enabled")), "watch": bool(self.cfg.get("watch", True)),
                "noaa_freq": self.cfg.get("noaa_freq"), "ppm": self.cfg.get("ppm"), "gain": self.cfg.get("gain"),
                "presets": self.cfg.get("presets") or [],
                "tools_ok": bool(self.tools.get("rtl_fm")), "missing": [k for k, v in self.tools.items() if not v],
                "devices": self.devices, "two_sticks": self.devices >= 2,
                "watch_state": self.watch_state, "station": st, "listeners": len(self.clients), "rate": self.rate,
                "messages": [{k: m[k] for k in ("time", "code", "event", "level", "local", "raw", "expires")} for m in self.messages[:15]
                             if time.time() - m["time"] <= 72 * 3600 or (m.get("expires") or 0) > time.time()],   # 72 h unless still in force
                "error": self.error, "scan": self.scan_result, "county_fips": self.fips,
                "channels": list(NOAA_CHANNELS), "windows": os.name == "nt",
                "install": self.installer.info() if getattr(self, "installer", None) else None,
            }


# ------------------------------------------------------------------ INSTALL RADIO SUPPORT button
HELPER = "/usr/local/sbin/crashboard-radio-setup"     # root-owned copy of setup/radio-helper.sh (install.sh puts it there)
RTL_RELEASE_API = "https://api.github.com/repos/rtlsdrblog/rtl-sdr-blog/releases/latest"
ZADIG_RELEASE_API = "https://api.github.com/repos/pbatard/libwdi/releases/latest"


def _is_android():
    return bool(os.environ.get("ANDROID_ROOT") or hasattr(sys, "getandroidapilevel"))


def win_tools_dir():
    """Where Windows radio tools go: next to the app (or the exe), else the Crash Board data folder."""
    if getattr(sys, "frozen", False):
        root = os.path.dirname(sys.executable)
        if not os.access(root, os.W_OK) and os.environ.get("CRASHBOARD_DATA"):
            root = os.environ["CRASHBOARD_DATA"]
        return os.path.join(root, "tools")
    return os.path.join(BASE, "tools")


class RadioInstaller:
    """Installs the RTL-SDR drivers/tools from the board itself, no terminal.
    Pi/Linux: runs the root-owned helper through a sudo rule that allows only that helper (install.sh sets it up).
    Windows: downloads the RTL-SDR Blog tools into tools\\rtl-sdr and opens Zadig for the one USB-driver click."""

    def __init__(self, radio, log=print):
        self.radio, self.log = radio, log
        self.busy, self.done, self.ok = False, False, False
        self.step, self.error, self.lines = "", "", []
        self.need_reboot = False
        self.lock = threading.Lock()
        self._mode, self._mode_at = None, 0

    def mode(self):
        if self._mode is None or time.time() - self._mode_at > 60:
            self._mode, self._mode_at = self._detect(), time.time()
        return self._mode

    def _detect(self):
        if _is_android():
            return "none"
        if os.name == "nt":
            return "windows"
        if sys.platform.startswith("linux"):
            return "pi" if self._sudo_ok() else "pi-setup"      # pi-setup: the one-time reinstall hasn't been done yet
        return "none"

    def _sudo_ok(self):
        if not os.path.isfile(HELPER):
            return False
        if os.geteuid() == 0:
            return True
        try:
            return subprocess.run(["sudo", "-n", "-l", HELPER, "install"], capture_output=True, timeout=8).returncode == 0
        except Exception:
            return False

    def _say(self, line):
        line = str(line).rstrip()
        if not line:
            return
        self.lines = (self.lines + [line])[-40:]
        if line.startswith(("STEP", "DONE", "ERROR")):
            self.step = line.split(" ", 2)[-1] if line.startswith("STEP") else line[5:].strip() or line
        self.log("radio install:", line)

    def start(self):
        with self.lock:
            if self.busy:
                raise ValueError("Radio install is already running.")
            self._mode = None
            m = self.mode()
            if m not in ("pi", "windows"):
                raise ValueError("This board can't install radio support by itself yet." if m == "pi-setup"
                                 else "Radio install isn't available on this device.")
            self.busy, self.done, self.ok, self.error, self.lines, self.need_reboot = True, False, False, "", [], False
            self.step = "Starting…"
        threading.Thread(target=self._run_windows if m == "windows" else self._run_pi, daemon=True, name="radio-install").start()
        return self.info()

    def _finish(self, ok, err=""):
        try:
            self.radio.stop()
        except Exception:
            pass
        self.radio.refresh_hw()
        self.ok, self.error, self.done, self.busy = ok, err, True, False
        if ok and os.name != "nt" and not self.radio.devices:
            self.need_reboot = True
        if ok:
            self.step = ("Radio ready - %d stick%s found" % (self.radio.devices, "" if self.radio.devices == 1 else "s")) \
                if self.radio.devices else self.step or "Installed"

    def _run_pi(self):
        try:
            cmd = [HELPER, "install"] if os.geteuid() == 0 else ["sudo", "-n", HELPER, "install"]
            p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
            for line in p.stdout:
                self._say(line)
            rc = p.wait()
            self._finish(rc == 0, "" if rc == 0 else "Install stopped (code %d). Check the internet connection and try again." % rc)
        except Exception as e:
            self._finish(False, str(e)[:160])

    def reboot(self):
        if self.mode() != "pi":
            raise ValueError("Restart isn't available here.")
        cmd = [HELPER, "reboot"] if os.geteuid() == 0 else ["sudo", "-n", HELPER, "reboot"]
        subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return {"ok": True}

    def _get_json(self, url):
        req = urllib.request.Request(url, headers={"User-Agent": "CrashBoard", "Accept": "application/vnd.github+json"})
        with urllib.request.urlopen(req, timeout=30) as r:
            return json.loads(r.read().decode())

    def _download(self, url, dest):
        req = urllib.request.Request(url, headers={"User-Agent": "CrashBoard"})
        with urllib.request.urlopen(req, timeout=180) as r, open(dest, "wb") as f:
            shutil.copyfileobj(r, f)

    def _run_windows(self):
        try:
            tools = win_tools_dir()
            dest = os.path.join(tools, "rtl-sdr")
            os.makedirs(dest, exist_ok=True)
            self._say("STEP 1/3 Downloading the RTL-SDR Blog tools")
            rel = self._get_json(RTL_RELEASE_API)
            asset = next((a for a in rel.get("assets", []) if a["name"].lower().endswith(".zip")), None)
            if not asset:
                raise ValueError("No download found on the RTL-SDR Blog release page.")
            zp = os.path.join(tools, "rtl-sdr-download.zip")
            self._download(asset["browser_download_url"], zp)
            self._say("STEP 2/3 Unpacking")
            with zipfile.ZipFile(zp) as z:
                names = [n for n in z.namelist() if n.lower().endswith("rtl_fm.exe")]
                if not names:
                    raise ValueError("rtl_fm.exe wasn't in the download.")
                pick = sorted(names, key=lambda n: (0 if "x64" in n.lower() else 1, len(n)))[0]
                folder = pick[: -len("rtl_fm.exe")]
                for n in z.namelist():
                    if n.startswith(folder) and not n.endswith("/") and "/" not in n[len(folder):]:
                        with z.open(n) as src, open(os.path.join(dest, os.path.basename(n)), "wb") as out:
                            shutil.copyfileobj(src, out)
            os.remove(zp)
            self._say("STEP 3/3 Opening Zadig for the USB driver")
            zadig = os.path.join(tools, "zadig.exe")
            if not os.path.isfile(zadig):
                rel = self._get_json(ZADIG_RELEASE_API)
                za = next((a for a in rel.get("assets", []) if a["name"].lower().startswith("zadig") and a["name"].lower().endswith(".exe")), None)
                if za:
                    self._download(za["browser_download_url"], zadig)
            if os.path.isfile(zadig):
                try:
                    os.startfile(zadig)                    # Windows asks "allow changes?" - click Yes
                except Exception as e:
                    self._say("couldn't open Zadig: %s" % e)
            self._say("DONE Tools installed - finish the Zadig step, then press RE-DETECT")
            self._finish(True)
        except Exception as e:
            self._finish(False, "Download failed: %s" % str(e)[:140])

    def info(self):
        return {"mode": self.mode(), "busy": self.busy, "done": self.done, "ok": self.ok, "step": self.step,
                "error": self.error, "log": self.lines[-8:], "need_reboot": self.need_reboot}


def _nowin():
    """Hide the console window rtl_fm would otherwise pop up on Windows."""
    if os.name == "nt":
        return {"creationflags": 0x08000000}
    return {}
