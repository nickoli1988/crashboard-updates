"""Crash Board for Windows: the program inside CrashBoard.exe.

- Starts the board in the background and shows it in its own window (Microsoft Edge WebView2, built into
  Windows 10 and 11). If that isn't available, it opens in the browser instead.
- Closing the window keeps Crash Board watching: it tucks into the icon next to the clock
  (open, open in browser, start with Windows, quit).
- Settings, the PRO key and caches live in your Windows user folder
  (%LOCALAPPDATA%\\CrashBoard or %LOCALAPPDATA%\\CrashBoard Mesh), so updates and reinstalls keep them.
  The first time, settings from a "data" folder next to the program (the old start-windows.bat setup)
  are copied over.
"""
import importlib.util
import json
import os
import shutil
import sys
import threading
import time
import urllib.request
import webbrowser

if not getattr(sys, "frozen", False):                 # run as a script: the board's code is one folder up
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
MESH = False                       # one edition now: Meshtastic COMMS is built in
NAME = "Crash Board Mesh" if MESH else "Crash Board"
FROZEN = getattr(sys, "frozen", False)
EXE_DIR = os.path.dirname(sys.executable if FROZEN else os.path.abspath(__file__))
_LAD = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
DATA = os.path.join(_LAD, "CrashBoard Mesh" if MESH else "CrashBoard")
if not os.path.isdir(DATA) and os.path.isdir(os.path.join(_LAD, "CrashBoard Mesh")):
    DATA = os.path.join(_LAD, "CrashBoard Mesh")     # someone who used the old Mesh edition keeps their settings and PRO key


def migrate_old_settings():
    """First run: bring over settings from the script version (a data folder near the program)."""
    if os.path.exists(os.path.join(DATA, "config.json")):
        return
    for cand in (os.path.join(EXE_DIR, "data"), os.path.join(EXE_DIR, "..", "data"),
                 os.path.join(EXE_DIR, "..", "..", "data")):
        cand = os.path.abspath(cand)
        if os.path.exists(os.path.join(cand, "config.json")):
            for name in os.listdir(cand):
                src = os.path.join(cand, name)
                if os.path.isfile(src) and name not in ("port.txt", "server.log"):
                    shutil.copy2(src, os.path.join(DATA, name))
            print("settings copied from", cand)
            return


def board_url():
    try:
        port = int(open(os.path.join(DATA, "port.txt")).read().strip())
    except (OSError, ValueError):
        return None
    return "http://127.0.0.1:%d/" % port


def board_answers(url):
    try:
        with urllib.request.urlopen(url + "api/state", timeout=2) as r:
            return r.status == 200
    except Exception:
        return False


def open_board(*_):
    url = board_url()
    if url:
        webbrowser.open(url)


# ------------------------------------------------------------------ start with Windows
RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"
RUN_NAME = "CrashBoardMesh" if MESH else "CrashBoard"


def autostart_on():
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY) as k:
            winreg.QueryValueEx(k, RUN_NAME)
        return True
    except OSError:
        return False


def toggle_autostart(*_):
    import winreg
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_SET_VALUE) as k:
        if autostart_on():
            winreg.DeleteValue(k, RUN_NAME)
        else:
            winreg.SetValueEx(k, RUN_NAME, 0, winreg.REG_SZ, '"%s" --background' % sys.executable)


# ------------------------------------------------------------------ main
def main():
    os.makedirs(DATA, exist_ok=True)
    if sys.stdout is None or FROZEN:                    # a windowed .exe has no console: log to a file
        log = open(os.path.join(DATA, "server.log"), "a", buffering=1, encoding="utf-8", errors="replace")
        sys.stdout = sys.stderr = log
    background = "--background" in sys.argv            # started with Windows: don't pop the browser open

    # already running? just open it
    url = board_url()
    if url and board_answers(url):
        if not background:
            webbrowser.open(url)
        return

    migrate_old_settings()
    try:
        os.remove(os.path.join(DATA, "port.txt"))
    except OSError:
        pass
    os.environ["CRASHBOARD_DATA"] = DATA
    import server                                       # noqa: E402  (after CRASHBOARD_DATA is set)
    threading.Thread(target=server.main, args=([],), daemon=True, name="crashboard").start()

    for _ in range(120):                                # wait up to a minute for the board
        url = board_url()
        if url and board_answers(url):
            break
        time.sleep(0.5)
    try:
        import pystray
        from PIL import Image
    except ImportError:
        pystray = None
    try:
        import webview                                  # pywebview: its own window
    except ImportError:
        webview = None

    window = None
    if webview is not None and url:
        # alarm sounds may play without a click first (like the Pi screen)
        os.environ["WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS"] = "--autoplay-policy=no-user-gesture-required"
        try:
            window = webview.create_window(NAME + "\u2122 v1", url + "?sound=1&desktop=1", width=1400, height=860,
                                           min_size=(800, 520), background_color="#0a0c08", hidden=background)
        except Exception as e:
            print("own window not available:", e)
            window = None

    def show(*_):
        if window is not None:
            try:
                window.show(); window.restore()
                return
            except Exception:
                pass
        open_board()

    def quit_app(icon=None, _item=None):
        if icon is not None:
            icon.stop()
        os._exit(0)

    icon = None
    if pystray is not None:
        icon_png = os.path.join(os.path.dirname(os.path.abspath(server.__file__)), "static", "icon-192.png")
        image = Image.open(icon_png) if os.path.exists(icon_png) else Image.new("RGB", (64, 64), (255, 122, 26))
        menu = pystray.Menu(
            pystray.MenuItem("Open " + NAME, show, default=True),
            pystray.MenuItem("Open in browser", open_board),
            pystray.MenuItem("Start with Windows", toggle_autostart, checked=lambda _i: autostart_on()),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Quit " + NAME, quit_app),
        )
        icon = pystray.Icon(RUN_NAME, image, NAME + "\u2122 v1 is watching", menu)

    if window is not None:
        def on_closing():                               # the X button hides the window; the board keeps watching
            if icon is None:
                return True                             # no tray icon to come back from: really close
            window.hide()
            return False
        window.events.closing += on_closing
        if icon is not None:
            icon.run_detached()                         # the window needs the main thread
        try:
            webview.start(private_mode=False, storage_path=os.path.join(DATA, "window"))   # remembers this window's choices
        except Exception as e:
            print("own window failed:", e)
            open_board()
            if icon is not None:
                while True:
                    time.sleep(3600)
        quit_app(icon)
    else:                                               # no WebView2: use the browser, keep the tray icon
        if url and not background:
            webbrowser.open(url)
        if icon is not None:
            icon.run()
        else:
            while True:
                time.sleep(3600)

if __name__ == "__main__":
    main()
