@echo off
REM Makes the Crash Board server start silently every time you log in to Windows.
REM Run again with "remove" to undo:   autostart-windows.bat remove
cd /d "%~dp0"
set "VBS=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\CrashBoard.vbs"

if /i "%~1"=="remove" (
  del "%VBS%" 2>nul
  echo  Autostart removed.
  pause
  exit /b 0
)

set "PYW="
where pyw >nul 2>nul && set "PYW=pyw -3"
if not defined PYW where pythonw >nul 2>nul && set "PYW=pythonw"
if not defined PYW (
  echo  Python 3 not found. Install it from https://www.python.org/downloads/ first.
  pause
  exit /b 1
)

> "%VBS%" echo Set sh = CreateObject("WScript.Shell")
>>"%VBS%" echo sh.CurrentDirectory = "%~dp0"
>>"%VBS%" echo sh.Run "%PYW% ""%~dp0server.py""", 0, False

echo  Done. Crash Board will now start in the background whenever you log in.
echo  The board address is saved in data\port.txt (usually http://localhost:8080).
start "" wscript "%VBS%"
pause
