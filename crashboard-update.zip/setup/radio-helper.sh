#!/bin/bash
# Crash Board RADIO helper. Installed (root-owned) as /usr/local/sbin/crashboard-radio-setup by install.sh,
# so the RADIO page's INSTALL RADIO SUPPORT button can set up the SDR stick with no typing.
# The board may run ONLY these two exact commands as root (see /etc/sudoers.d/crashboard-radio):
#   crashboard-radio-setup install     -> radio drivers + stop the TV driver grabbing the stick
#   crashboard-radio-setup reboot      -> restart the Pi
set -e
export DEBIAN_FRONTEND=noninteractive PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
[ "$(id -u)" = 0 ] || { echo "ERROR: needs root"; exit 1; }

case "$1" in
reboot)
  echo "Restarting the Pi..."; sleep 2; systemctl reboot; exit 0 ;;
install) ;;
*) echo "usage: crashboard-radio-setup install|reboot"; exit 2 ;;
esac

echo "STEP 1/4 Stopping the TV-tuner driver from grabbing the stick"
echo 'blacklist dvb_usb_rtl28xxu' > /etc/modprobe.d/blacklist-dvb_usb_rtl28xxu.conf
modprobe -r dvb_usb_rtl28xxu 2>/dev/null || true

# An RTL-SDR Blog V4 needs newer drivers than Raspberry Pi OS ships; everything else (Nooelec etc.) is fine with apt.
V4=0
grep -qs "Blog V4" /sys/bus/usb/devices/*/product && V4=1

if [ "$V4" = 0 ]; then
  echo "STEP 2/4 Installing radio drivers (rtl-sdr)"
  if ! apt-get install -y rtl-sdr; then
    echo "  refreshing the package list and trying again"
    apt-get update && apt-get install -y rtl-sdr
  fi
  echo "STEP 3/4 Drivers installed"
else
  echo "STEP 2/4 RTL-SDR Blog V4 found - building its drivers (about 5 minutes on a Pi)"
  apt-get update
  apt-get install -y libusb-1.0-0-dev git cmake pkg-config build-essential
  apt-get purge -y '^librtlsdr' 'rtl-sdr' 2>/dev/null || true
  rm -rf /usr/lib/librtlsdr* /usr/include/rtl-sdr* /usr/local/lib/librtlsdr* /usr/local/include/rtl-sdr* /usr/local/include/rtl_* /usr/local/bin/rtl_*
  TMP=$(mktemp -d); cd "$TMP"
  git clone --depth 1 https://github.com/osmocom/rtl-sdr
  cd rtl-sdr; mkdir build; cd build
  cmake ../ -DINSTALL_UDEV_RULES=ON
  echo "STEP 3/4 Compiling"
  make -j"$(nproc)"
  make install
  cp ../rtl-sdr.rules /etc/udev/rules.d/
  ldconfig
  cd /; rm -rf "$TMP"
fi

echo "STEP 4/4 Letting the board use the stick"
udevadm control --reload-rules 2>/dev/null || true
udevadm trigger --subsystem-match=usb 2>/dev/null || true
sleep 2
if command -v rtl_test >/dev/null && timeout 8 rtl_test -t 2>&1 | grep -q "Found [1-9]"; then
  echo "DONE Radio ready"
else
  echo "DONE Drivers installed - restart the Pi if the stick isn't found"
fi
