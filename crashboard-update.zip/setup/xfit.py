#!/usr/bin/env python3
"""Crash Board: make the board's browser window fill the whole screen.

The SD-card image has no window manager (to stay light), so the browser's "fullscreen" request is
ignored and it opens at its default size (800x600), leaving part of the screen empty or the board cut off.
This watches for top-level windows and moves/resizes each one to cover the screen exactly.
It also re-checks if the screen size changes. Uses only libX11 (already on every Pi with X), no extra packages.

  python3 xfit.py            keep watching (started in the background by kiosk.sh)
  python3 xfit.py --once     fit what is there now, then exit
"""
import ctypes
import ctypes.util
import sys
import time

ONCE = "--once" in sys.argv


def main():
    lib = ctypes.util.find_library("X11") or "libX11.so.6"
    x = ctypes.CDLL(lib)
    x.XOpenDisplay.restype = ctypes.c_void_p
    x.XOpenDisplay.argtypes = [ctypes.c_char_p]
    x.XDefaultRootWindow.restype = ctypes.c_ulong
    x.XDefaultRootWindow.argtypes = [ctypes.c_void_p]
    x.XDefaultScreen.argtypes = [ctypes.c_void_p]
    x.XDisplayWidth.argtypes = [ctypes.c_void_p, ctypes.c_int]
    x.XDisplayHeight.argtypes = [ctypes.c_void_p, ctypes.c_int]
    x.XQueryTree.argtypes = [ctypes.c_void_p, ctypes.c_ulong, ctypes.POINTER(ctypes.c_ulong),
                             ctypes.POINTER(ctypes.c_ulong), ctypes.POINTER(ctypes.POINTER(ctypes.c_ulong)),
                             ctypes.POINTER(ctypes.c_uint)]
    x.XFree.argtypes = [ctypes.c_void_p]
    x.XMoveResizeWindow.argtypes = [ctypes.c_void_p, ctypes.c_ulong, ctypes.c_int, ctypes.c_int,
                                    ctypes.c_uint, ctypes.c_uint]
    x.XRaiseWindow.argtypes = [ctypes.c_void_p, ctypes.c_ulong]
    x.XSetInputFocus.argtypes = [ctypes.c_void_p, ctypes.c_ulong, ctypes.c_int, ctypes.c_ulong]
    x.XFlush.argtypes = [ctypes.c_void_p]
    x.XSync.argtypes = [ctypes.c_void_p, ctypes.c_int]
    x.XCloseDisplay.argtypes = [ctypes.c_void_p]

    class Attrs(ctypes.Structure):          # XWindowAttributes (only the leading fields matter here)
        _fields_ = [("x", ctypes.c_int), ("y", ctypes.c_int), ("width", ctypes.c_int), ("height", ctypes.c_int),
                    ("border_width", ctypes.c_int), ("depth", ctypes.c_int), ("visual", ctypes.c_void_p),
                    ("root", ctypes.c_ulong), ("c_class", ctypes.c_int), ("bit_gravity", ctypes.c_int),
                    ("win_gravity", ctypes.c_int), ("backing_store", ctypes.c_int),
                    ("backing_planes", ctypes.c_ulong), ("backing_pixel", ctypes.c_ulong),
                    ("save_under", ctypes.c_int), ("colormap", ctypes.c_ulong), ("map_installed", ctypes.c_int),
                    ("map_state", ctypes.c_int), ("all_event_masks", ctypes.c_long),
                    ("your_event_mask", ctypes.c_long), ("do_not_propagate_mask", ctypes.c_long),
                    ("override_redirect", ctypes.c_int), ("screen", ctypes.c_void_p)]
    x.XGetWindowAttributes.argtypes = [ctypes.c_void_p, ctypes.c_ulong, ctypes.POINTER(Attrs)]

    # ignore X errors (a window can vanish between listing and resizing it)
    HANDLER = ctypes.CFUNCTYPE(ctypes.c_int, ctypes.c_void_p, ctypes.c_void_p)
    keep = HANDLER(lambda d, e: 0)
    x.XSetErrorHandler.argtypes = [HANDLER]
    x.XSetErrorHandler(keep)

    dpy = None
    for _ in range(60):                      # X may still be starting
        dpy = x.XOpenDisplay(None)
        if dpy:
            break
        time.sleep(1)
    if not dpy:
        print("xfit: no X display"); return 1
    root = x.XDefaultRootWindow(dpy)
    scr = x.XDefaultScreen(dpy)
    last = {}
    while True:
        W, H = x.XDisplayWidth(dpy, scr), x.XDisplayHeight(dpy, scr)
        r, p, kids, n = ctypes.c_ulong(), ctypes.c_ulong(), ctypes.POINTER(ctypes.c_ulong)(), ctypes.c_uint()
        if x.XQueryTree(dpy, root, ctypes.byref(r), ctypes.byref(p), ctypes.byref(kids), ctypes.byref(n)):
            wins = [kids[i] for i in range(n.value)]
            if kids:
                x.XFree(kids)
            for w in wins:
                a = Attrs()
                if not x.XGetWindowAttributes(dpy, w, ctypes.byref(a)):
                    continue
                if a.map_state != 2 or a.override_redirect:      # only visible, normal windows (not menus/tooltips)
                    continue
                if a.width < 200 or a.height < 150:              # skip tiny helper windows
                    continue
                if (a.x, a.y, a.width, a.height) != (0, 0, W, H):
                    x.XMoveResizeWindow(dpy, w, 0, 0, W, H)
                    x.XRaiseWindow(dpy, w)
                    x.XSetInputFocus(dpy, w, 1, 0)               # RevertToPointerRoot, CurrentTime
                    if last.get(w) != (W, H):
                        print("xfit: window 0x%x %dx%d+%d+%d -> %dx%d" % (w, a.width, a.height, a.x, a.y, W, H))
                        sys.stdout.flush()
                    last[w] = (W, H)
            x.XSync(dpy, 0)
        if ONCE:
            break
        time.sleep(2)
    x.XCloseDisplay(dpy)
    return 0


if __name__ == "__main__":
    sys.exit(main())
