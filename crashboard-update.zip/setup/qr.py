"""Tiny QR code maker for the setup screen (byte mode, error-correction level M, versions 1-10).
Standard library only. qr_svg("text") returns an SVG string."""

_ECC_M = [-1, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26]      # error-correction codewords per block
_BLOCKS_M = [-1, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5]              # number of blocks


def _mul(x, y):
    z = 0
    for i in range(7, -1, -1):
        z = (z << 1) ^ ((z >> 7) * 0x11D)
        z ^= ((y >> i) & 1) * x
    return z


def _rs_divisor(degree):
    r = [0] * (degree - 1) + [1]
    root = 1
    for _ in range(degree):
        for j in range(degree):
            r[j] = _mul(r[j], root)
            if j + 1 < degree:
                r[j] ^= r[j + 1]
        root = _mul(root, 2)
    return r


def _rs_remainder(data, div):
    r = [0] * len(div)
    for b in data:
        f = b ^ r.pop(0)
        r.append(0)
        for i, c in enumerate(div):
            r[i] ^= _mul(c, f)
    return r


def _raw_modules(v):
    n = (16 * v + 128) * v + 64
    if v >= 2:
        a = v // 7 + 2
        n -= (25 * a - 10) * a - 55
        if v >= 7:
            n -= 36
    return n


def _data_codewords(v):
    return _raw_modules(v) // 8 - _ECC_M[v] * _BLOCKS_M[v]


def _align_positions(v, size):
    if v == 1:
        return []
    a = v // 7 + 2
    step = (v * 8 + a * 3 + 5) // (a * 4 - 4) * 2
    res, pos = [6], size - 7
    for _ in range(a - 1):
        res.insert(1, pos)
        pos -= step
    return res


class _QR:
    def __init__(self, v):
        self.v = v
        self.size = v * 4 + 17
        self.m = [[False] * self.size for _ in range(self.size)]
        self.fn = [[False] * self.size for _ in range(self.size)]

    def set_fn(self, x, y, dark):
        self.m[y][x] = dark
        self.fn[y][x] = True

    def draw_functions(self):
        s = self.size
        for i in range(s):
            self.set_fn(6, i, i % 2 == 0)
            self.set_fn(i, 6, i % 2 == 0)
        for cx, cy in ((3, 3), (s - 4, 3), (3, s - 4)):
            for dy in range(-4, 5):
                for dx in range(-4, 5):
                    x, y = cx + dx, cy + dy
                    if 0 <= x < s and 0 <= y < s:
                        self.set_fn(x, y, max(abs(dx), abs(dy)) not in (2, 4))
        al = _align_positions(self.v, s)
        n = len(al)
        for i in range(n):
            for j in range(n):
                if (i == 0 and j == 0) or (i == 0 and j == n - 1) or (i == n - 1 and j == 0):
                    continue
                for dy in range(-2, 3):
                    for dx in range(-2, 3):
                        self.set_fn(al[i] + dx, al[j] + dy, max(abs(dx), abs(dy)) != 1)
        self.draw_format(0)
        if self.v >= 7:
            rem = self.v
            for _ in range(12):
                rem = (rem << 1) ^ ((rem >> 11) * 0x1F25)
            bits = self.v << 12 | rem
            for i in range(18):
                bit = (bits >> i) & 1 == 1
                a, b = s - 11 + i % 3, i // 3
                self.set_fn(a, b, bit)
                self.set_fn(b, a, bit)

    def draw_format(self, mask):
        data = (0 << 3) | mask                      # level M = 0b00
        rem = data
        for _ in range(10):
            rem = (rem << 1) ^ ((rem >> 9) * 0x537)
        bits = (data << 10 | rem) ^ 0x5412
        b = lambda i: (bits >> i) & 1 == 1
        s = self.size
        for i in range(6):
            self.set_fn(8, i, b(i))
        self.set_fn(8, 7, b(6))
        self.set_fn(8, 8, b(7))
        self.set_fn(7, 8, b(8))
        for i in range(9, 15):
            self.set_fn(14 - i, 8, b(i))
        for i in range(8):
            self.set_fn(s - 1 - i, 8, b(i))
        for i in range(8, 15):
            self.set_fn(8, s - 15 + i, b(i))
        self.set_fn(8, s - 8, True)

    def draw_codewords(self, data):
        s, i, right = self.size, 0, self.size - 1
        while right >= 1:
            if right == 6:
                right = 5
            for vert in range(s):
                for j in range(2):
                    x = right - j
                    up = ((right + 1) & 2) == 0
                    y = s - 1 - vert if up else vert
                    if not self.fn[y][x] and i < len(data) * 8:
                        self.m[y][x] = (data[i >> 3] >> (7 - (i & 7))) & 1 == 1
                        i += 1
            right -= 2

    def apply_mask(self, k):
        for y in range(self.size):
            for x in range(self.size):
                if self.fn[y][x]:
                    continue
                inv = [(x + y) % 2 == 0, y % 2 == 0, x % 3 == 0, (x + y) % 3 == 0,
                       (x // 3 + y // 2) % 2 == 0, x * y % 2 + x * y % 3 == 0,
                       (x * y % 2 + x * y % 3) % 2 == 0, ((x + y) % 2 + x * y % 3) % 2 == 0][k]
                if inv:
                    self.m[y][x] = not self.m[y][x]

    def penalty(self):
        s, m, p = self.size, self.m, 0
        lines = [m[y] for y in range(s)] + [[m[y][x] for y in range(s)] for x in range(s)]
        for line in lines:
            run, prev = 0, None
            for c in line:
                if c == prev:
                    run += 1
                else:
                    if run >= 5:
                        p += 3 + run - 5
                    run, prev = 1, c
            if run >= 5:
                p += 3 + run - 5
            t = "".join("1" if c else "0" for c in line)
            p += 40 * (t.count("1011101" + "0000") + t.count("0000" + "1011101"))
        for y in range(s - 1):
            for x in range(s - 1):
                c = m[y][x]
                if c == m[y][x + 1] == m[y + 1][x] == m[y + 1][x + 1]:
                    p += 3
        dark = sum(sum(1 for c in row if c) for row in m)
        total = s * s
        p += ((abs(dark * 20 - total * 10) + total - 1) // total - 1) * 10
        return p


def qr_matrix(text):
    data = text.encode("utf-8")
    for v in range(1, 11):
        cap_bits = _data_codewords(v) * 8
        need = 4 + (8 if v < 10 else 16) + len(data) * 8
        if need <= cap_bits:
            break
    else:
        raise ValueError("text too long for QR")
    bits = [0, 1, 0, 0]
    nlen = 8 if v < 10 else 16
    bits += [(len(data) >> i) & 1 for i in range(nlen - 1, -1, -1)]
    for byte in data:
        bits += [(byte >> i) & 1 for i in range(7, -1, -1)]
    bits += [0] * min(4, cap_bits - len(bits))
    bits += [0] * ((8 - len(bits) % 8) % 8)
    cw = [int("".join(map(str, bits[i:i + 8])), 2) for i in range(0, len(bits), 8)]
    pad = 0xEC
    while len(cw) < _data_codewords(v):
        cw.append(pad)
        pad ^= 0xEC ^ 0x11
    # split into blocks, add error correction, interleave
    nb, ecl = _BLOCKS_M[v], _ECC_M[v]
    raw = _raw_modules(v) // 8
    nshort = nb - raw % nb
    shortlen = raw // nb
    div = _rs_divisor(ecl)
    blocks, k = [], 0
    for i in range(nb):
        dat = cw[k:k + shortlen - ecl + (0 if i < nshort else 1)]
        k += len(dat)
        ecc = _rs_remainder(dat, div)
        if i < nshort:
            dat = dat + [0]
        blocks.append(dat + ecc)
    out = []
    for i in range(len(blocks[0])):
        for j, b in enumerate(blocks):
            if i != shortlen - ecl or j >= nshort:
                out.append(b[i])
    best = None
    for mask in range(8):
        q = _QR(v)
        q.draw_functions()
        q.draw_codewords(out)
        q.apply_mask(mask)
        q.draw_format(mask)
        pen = q.penalty()
        if best is None or pen < best[0]:
            best = (pen, q)
    return best[1].m


def qr_svg(text, border=2, dark="#000", light="#fff"):
    m = qr_matrix(text)
    n = len(m) + border * 2
    path = "".join("M%d %dh1v1h-1z" % (x + border, y + border) for y, row in enumerate(m) for x, c in enumerate(row) if c)
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" shape-rendering="crispEdges">'
            '<rect width="100%%" height="100%%" fill="%s"/><path d="%s" fill="%s"/></svg>') % (n, n, light, path, dark)
