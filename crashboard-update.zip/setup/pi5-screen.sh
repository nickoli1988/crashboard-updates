#!/bin/bash
# Crash Board: Raspberry Pi 5 screen fix (runs as root at every start, before the screen comes up).
# A Pi 5 has several graphics devices: one does 3D only, one drives the HDMI ports and one drives the DSI
# ribbon-cable port. X can pick the wrong one and show a black screen, so point it at the device whose
# screen is actually plugged in (DSI first, then HDMI). Does nothing on other Pi models.
CONF=/etc/X11/xorg.conf.d/98-crashboard-pi5.conf
if ! grep -qaE "Raspberry Pi (5|500)|Compute Module 5" /proc/device-tree/model 2>/dev/null; then
  rm -f "$CONF"; exit 0
fi

pick() {      # $1 = connector type (DSI / HDMI-A / DPI ...): prints the card of the first one that's connected
  for c in /sys/class/drm/card*-"$1"-*; do
    [ -e "$c/status" ] || continue
    [ "$(cat "$c/status" 2>/dev/null)" = "connected" ] || continue
    c="$(basename "$c")"; echo "${c%%-*}"; return 0
  done
  return 1
}

CARD=""
for i in $(seq 1 20); do                           # the graphics drivers can take a moment to appear
  CARD="$(pick DSI || pick DPI || pick HDMI-A)"
  [ -n "$CARD" ] && break
  sleep 0.5
done
if [ -z "$CARD" ]; then
  # nothing reports "connected" (some screens don't say): leave X to choose by itself
  rm -f "$CONF"
  echo "pi5-screen: no connected screen found, letting X choose"
  exit 0
fi
mkdir -p /etc/X11/xorg.conf.d
NEW="$(printf '%s\n' 'Section "Device"' '    Identifier "CrashBoardPi5"' '    Driver     "modesetting"' \
  "    Option     \"kmsdev\" \"/dev/dri/$CARD\"" 'EndSection')"
[ "$(cat "$CONF" 2>/dev/null)" = "$NEW" ] || printf '%s\n' "$NEW" > "$CONF"
echo "pi5-screen: using /dev/dri/$CARD"
