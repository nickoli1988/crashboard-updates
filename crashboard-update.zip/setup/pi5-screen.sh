#!/bin/bash
# Crash Board: Raspberry Pi 5 screen fix (runs as root at every start, before the screen comes up).
# A Pi 5 has two graphics devices: one does 3D only, the other drives HDMI. X can pick the wrong one and
# show a black screen, so tell it which one has the HDMI ports. Does nothing on other Pi models.
CONF=/etc/X11/xorg.conf.d/98-crashboard-pi5.conf
if ! grep -qaE "Raspberry Pi (5|500)|Compute Module 5" /proc/device-tree/model 2>/dev/null; then
  rm -f "$CONF"; exit 0
fi
CARD=""
for i in $(seq 1 20); do                           # the graphics driver can take a moment to appear
  for c in /sys/class/drm/card*-HDMI-A-*; do
    [ -e "$c" ] || continue
    CARD="$(basename "$c")"; CARD="${CARD%%-*}"; break
  done
  [ -n "$CARD" ] && break
  sleep 0.5
done
[ -n "$CARD" ] || { echo "pi5-screen: no HDMI device found"; exit 0; }
mkdir -p /etc/X11/xorg.conf.d
NEW="$(printf '%s\n' 'Section "Device"' '    Identifier "CrashBoardPi5"' '    Driver     "modesetting"' \
  "    Option     \"kmsdev\" \"/dev/dri/$CARD\"" 'EndSection')"
[ "$(cat "$CONF" 2>/dev/null)" = "$NEW" ] || printf '%s\n' "$NEW" > "$CONF"
echo "pi5-screen: using /dev/dri/$CARD"
