#!/bin/bash
# Crash Board RADIO for Raspberry Pi: builds the RTL-SDR tools (with RTL-SDR Blog V4 support) and stops
# the TV-tuner driver from grabbing the stick. Run:  sudo bash setup/install-radio.sh   then reboot.
set -e
if [ "$(id -u)" != 0 ]; then echo "Run it with sudo:  sudo bash setup/install-radio.sh"; exit 1; fi
echo "== Crash Board radio: installing build tools"
apt-get update
apt-get install -y libusb-1.0-0-dev git cmake pkg-config build-essential
echo "== removing any old RTL-SDR driver"
apt-get purge -y '^librtlsdr' 'rtl-sdr' 2>/dev/null || true
rm -rf /usr/lib/librtlsdr* /usr/include/rtl-sdr* /usr/local/lib/librtlsdr* /usr/local/include/rtl-sdr* /usr/local/include/rtl_* /usr/local/bin/rtl_*
echo "== building rtl-sdr (a few minutes on a Pi)"
TMP=$(mktemp -d); cd "$TMP"
git clone --depth 1 https://github.com/osmocom/rtl-sdr
cd rtl-sdr; mkdir build; cd build
cmake ../ -DINSTALL_UDEV_RULES=ON
make -j"$(nproc)"
make install
cp ../rtl-sdr.rules /etc/udev/rules.d/
ldconfig
echo 'blacklist dvb_usb_rtl28xxu' > /etc/modprobe.d/blacklist-dvb_usb_rtl28xxu.conf
cd /; rm -rf "$TMP"
echo
echo "== Done. Reboot now (sudo reboot), then open the RADIO page on the board."
