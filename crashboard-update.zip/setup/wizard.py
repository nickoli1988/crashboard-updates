#!/usr/bin/env python3
"""CRASH BOARD first-time setup (runs as root from crashboard-wizard.service on the SD-card image).

First boot (no data/setup-done.json):
  The Pi makes an open Wi-Fi called CRASHBOARD-SETUP-XXXX. Phones that join it get a setup page
  (Wi-Fi, location, units, language, board name, optional password/SSH). The attached screen
  shows instructions and QR codes. After the Pi joins the home Wi-Fi it applies the settings,
  marks setup done and restarts into Crash Board.
Later boots:
  If no known Wi-Fi is reachable for a few minutes, the setup Wi-Fi comes back so a phone can
  pick a new network (moved house, new router). Known networks are retried every 10 minutes.
"""
import json, os, pwd, re, socket, subprocess, sys, threading, time, urllib.parse, urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import qr  # noqa: E402

DATA = os.path.join(APP, "data")
DONE = os.path.join(DATA, "setup-done.json")
RUN = os.environ.get("CB_RUN_DIR", "/run/crashboard-setup")
STATUS = os.path.join(RUN, "status.json")
PORT = int(os.environ.get("CB_SETUP_PORT", "80"))
IFACE = os.environ.get("CB_WIFI_IFACE", "wlan0")
AP_CON = "crashboard-setup"
AP_IP = "10.42.0.1"
TEST_ONLINE = os.environ.get("CB_TEST_ONLINE_FILE")      # tests: online == this file exists
MESH = os.path.basename(APP.rstrip("/")) == "crashboard-mesh"     # legacy Mesh folder only
LANGS = ("en", "es", "fr", "de", "pt")

ST = {"phase": "starting", "first": not os.path.exists(DONE), "ap": "", "networks": [], "target": "",
      "message": "", "error": "", "ip": "", "updated": 0}
LOCK = threading.Lock()
WORK = threading.Event()          # set while a submitted setup is being applied


def log(*a):
    print(time.strftime("%H:%M:%S"), *a, flush=True)


BOOT_LOG = os.environ.get("CB_BOOT_LOG") or next((d + "/crashboard-wifi-log.txt" for d in ("/boot/firmware", "/boot")
                                                  if os.path.exists(d + "/config.txt")), "")


def wlog(*a):
    """Wi-Fi events: the journal, plus crashboard-wifi-log.txt on the SD card so it can be read on a PC."""
    log(*a)
    if not BOOT_LOG:
        return
    try:
        if os.path.exists(BOOT_LOG) and os.path.getsize(BOOT_LOG) > 60000:
            os.replace(BOOT_LOG, BOOT_LOG + ".old")
        with open(BOOT_LOG, "a") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M:%S ") + " ".join(str(x) for x in a) + "\n")
    except OSError:
        pass


def save_status(**kw):
    with LOCK:
        ST.update(kw)
        ST["updated"] = time.time()
        snap = dict(ST)
    try:
        os.makedirs(RUN, exist_ok=True)
        tmp = STATUS + ".tmp"
        with open(tmp, "w") as f:
            json.dump(snap, f)
        os.chmod(tmp, 0o644)
        os.replace(tmp, STATUS)
    except OSError as e:
        log("status write failed", e)


def sh(*cmd, timeout=60):
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return p.returncode, (p.stdout + p.stderr).strip()
    except (OSError, subprocess.TimeoutExpired) as e:
        return 1, str(e)


def board_user():
    try:
        return pwd.getpwuid(os.stat(APP).st_uid).pw_name
    except KeyError:
        return "crashboard"


def board_port():
    try:
        return int(open(os.path.join(DATA, "port.txt")).read().strip())
    except (OSError, ValueError):
        return 8090 if MESH else 8080


# ---------------------------------------------------------------- network helpers
def online():
    if TEST_ONLINE:
        return os.path.exists(TEST_ONLINE)
    for host in ("api.open-meteo.com", "earthquake.usgs.gov"):
        try:
            socket.create_connection((host, 443), timeout=4).close()
            return True
        except OSError:
            pass
    return False


def my_ip():
    rc, out = sh("hostname", "-I")
    return out.split()[0] if rc == 0 and out.split() else ""


def ap_name():
    try:
        mac = open("/sys/class/net/%s/address" % IFACE).read().strip().replace(":", "")
        return "CRASHBOARD-SETUP-" + mac[-4:].upper()
    except OSError:
        return "CRASHBOARD-SETUP"


def nm_split(line):
    """nmcli -t output: fields split on ':' with '\\:' meaning a literal colon."""
    out, cur, esc = [], "", False
    for ch in line:
        if esc:
            cur += ch; esc = False
        elif ch == "\\":
            esc = True
        elif ch == ":":
            out.append(cur); cur = ""
        else:
            cur += ch
    out.append(cur)
    return out


def scan():
    sh("nmcli", "radio", "wifi", "on")
    rc, out = sh("nmcli", "-t", "-f", "SSID,SIGNAL,SECURITY", "device", "wifi", "list", "ifname", IFACE, "--rescan", "yes", timeout=40)
    nets = {}
    if rc == 0:
        for line in out.splitlines():
            f = nm_split(line)
            if len(f) < 3 or not f[0] or f[0].startswith("CRASHBOARD-SETUP"):
                continue
            sig = int(f[1]) if f[1].isdigit() else 0
            if f[0] not in nets or sig > nets[f[0]]["signal"]:
                nets[f[0]] = {"ssid": f[0], "signal": sig, "secure": f[2] not in ("", "--"), "security": f[2]}
    lst = sorted(nets.values(), key=lambda n: -n["signal"])[:25]
    log("scan:", len(lst), "networks")
    return lst


def set_country(cc):
    cc = (cc or "").upper()
    if not re.fullmatch(r"[A-Z]{2}", cc):
        return
    if sh("raspi-config", "nonint", "do_wifi_country", cc)[0] != 0:
        sh("iw", "reg", "set", cc)


def hotspot_up():
    name = ap_name()
    sh("rfkill", "unblock", "wifi")
    sh("nmcli", "connection", "delete", AP_CON)
    rc, out = sh("nmcli", "connection", "add", "type", "wifi", "ifname", IFACE, "con-name", AP_CON,
                 "autoconnect", "no", "ssid", name, "mode", "ap", "802-11-wireless.band", "bg",
                 "802-11-wireless.channel", "6", "ipv4.method", "shared", "ipv4.addresses", AP_IP + "/24",
                 "ipv6.method", "disabled")
    if rc == 0:
        rc, out = sh("nmcli", "connection", "up", AP_CON, timeout=40)
    log("hotspot", name, "rc", rc, out[-200:])
    save_status(ap=name, ip=AP_IP if rc == 0 else my_ip())
    return rc == 0


def hotspot_down():
    sh("nmcli", "connection", "down", AP_CON, timeout=30)


def hotspot_clients():
    rc, out = sh("iw", "dev", IFACE, "station", "dump")
    return rc == 0 and "Station" in out


def join(ssid, password, hidden):
    """Leave setup mode and join the user's Wi-Fi. True when the internet answers."""
    hotspot_down()
    time.sleep(3)
    sh("nmcli", "device", "wifi", "rescan", "ifname", IFACE, timeout=20)
    time.sleep(5)
    seen = [n for n in scan_safe() if n.get("ssid") == ssid]
    wlog("join", repr(ssid), "password", "%d chars" % len(password or ""),
         "seen: signal %s, security %s" % (seen[0].get("signal"), seen[0].get("security") or "open") if seen
         else "NOT SEEN in scan (5 GHz only, too far, or hidden)")
    con = "cb-" + ssid
    sh("nmcli", "connection", "delete", con)
    cmd = ["nmcli", "--wait", "45", "device", "wifi", "connect", ssid, "ifname", IFACE, "name", con]
    if password:
        cmd += ["password", password]
    if hidden:
        cmd += ["hidden", "yes"]
    rc, out = sh(*cmd, timeout=70)
    wlog("  try 1 rc", rc, out[-200:].replace(password or "\0", "***"))
    if rc != 0 and password:
        # Mixed WPA2/WPA3 routers: NetworkManager may pick WPA3, which the Pi Zero W's chip can't do.
        sh("nmcli", "connection", "delete", con)
        add = ["nmcli", "connection", "add", "type", "wifi", "ifname", IFACE, "con-name", con, "ssid", ssid,
               "wifi-sec.key-mgmt", "wpa-psk", "wifi-sec.psk", password, "wifi-sec.pmf", "disable",
               "connection.autoconnect-priority", "50"]
        if hidden:
            add += ["802-11-wireless.hidden", "yes"]
        rc2, out2 = sh(*add, timeout=20)
        if rc2 == 0:
            rc2, out2 = sh("nmcli", "--wait", "45", "connection", "up", con, timeout=70)
        wlog("  try 2 (WPA2 only) rc", rc2, out2[-200:].replace(password, "***"))
        if rc2 == 0:
            rc, out = 0, out2
        else:
            out = out + " " + out2
    if rc != 0:
        sh("nmcli", "connection", "delete", con)
        low = out.lower()
        if not seen and not hidden:
            return False, "network not found. The Pi Zero W only sees 2.4 GHz Wi-Fi"
        if "secrets" in low or "password" in low or "802-1x" in low or "psk" in low:
            return False, "wrong password (check capitals)"
        if "no network with ssid" in low or "not found" in low:
            return False, "network not found"
        return False, "could not connect"
    for _ in range(20):
        if online():
            return True, ""
        time.sleep(3)
    wlog("  joined, but no internet answer")
    return False, "joined the Wi-Fi but there is no internet"


# ---------------------------------------------------------------- applying settings
BOARD_ERR = {"text": ""}
PENDING = os.path.join(DATA, "pending-location.json")


def board_settings(body):
    BOARD_ERR["text"] = ""
    url = "http://127.0.0.1:%d/api/settings" % board_port()
    for _ in range(30):
        try:
            req = urllib.request.Request(url, data=json.dumps(body).encode(), headers={"Content-Type": "application/json"})
            r = json.loads(urllib.request.urlopen(req, timeout=60).read())
            return r.get("config", {})
        except urllib.error.HTTPError as e:
            BOARD_ERR["text"] = e.read()[:300].decode("utf-8", "replace")
            wlog("board refused settings", e.code, BOARD_ERR["text"])
            return {}
        except Exception:
            time.sleep(3)
    log("board did not answer")
    return {}


def set_timezone(lat, lon):
    try:
        u = "https://api.open-meteo.com/v1/forecast?latitude=%s&longitude=%s&current=temperature_2m&timezone=auto" % (lat, lon)
        tz = json.loads(urllib.request.urlopen(u, timeout=20).read()).get("timezone")
        if tz and re.fullmatch(r"[A-Za-z_]+(/[A-Za-z0-9_+\-]+)*", tz):
            sh("timedatectl", "set-timezone", tz)
            log("timezone", tz)
    except Exception as e:
        log("timezone lookup failed", e)


def apply_all(f):
    user = board_user()
    body = {"units": f["units"], "lang": f["lang"]}
    if f["location"]:
        body["location"] = f["location"]
        body["country"] = f["country"] or "AUTO"
    if f["callsign"]:
        body["callsign"] = f["callsign"]
    cfg = board_settings(body)
    if f["location"] and (cfg.get("location") or {}).get("lat") is None:
        # The location lookup failed. Right after joining Wi-Fi the internet can need a few more seconds.
        for _ in range(4):
            if "not found" in BOARD_ERR["text"]:
                break
            time.sleep(8)
            cfg = board_settings(body)
            if (cfg.get("location") or {}).get("lat") is not None:
                break
    if f["location"] and (cfg.get("location") or {}).get("lat") is None:
        # Still nothing: save everything else now, and let the board look the place up later by itself.
        why = BOARD_ERR["text"][:120] or "no answer"
        rest = {k: v for k, v in body.items() if k not in ("location", "country")}
        cfg = board_settings(rest)
        try:
            os.makedirs(DATA, exist_ok=True)
            with open(PENDING, "w") as fh:
                json.dump({"query": f["location"], "country": f["country"] or "AUTO", "time": time.time()}, fh)
            pw = pwd.getpwnam(board_user())
            os.chown(PENDING, pw.pw_uid, pw.pw_gid)
        except (OSError, KeyError):
            pass
        wlog("location lookup failed (%s); the board will retry it" % why)
        cfg["location"] = {"name": f["location"] + " (looking up)"}
    loc = cfg.get("location") or {}
    if loc.get("lat") is not None:
        set_timezone(loc["lat"], loc["lon"])
    if f["password"]:
        p = subprocess.run(["chpasswd"], input="%s:%s\n" % (user, f["password"]), text=True, capture_output=True)
        log("password set" if p.returncode == 0 else "chpasswd failed")
    if f["ssh"]:
        sh("systemctl", "enable", "--now", "ssh")
    os.makedirs(DATA, exist_ok=True)
    with open(DONE, "w") as fh:
        json.dump({"time": time.time(), "ssid": f["ssid"], "location": loc.get("name", "")}, fh)
    try:
        pw = pwd.getpwnam(user)
        os.chown(DONE, pw.pw_uid, pw.pw_gid)
    except (KeyError, OSError):
        pass
    return loc


def run_setup(f):
    WORK.set()
    try:
        if f["keep_wifi"]:
            ok, why = True, ""
        else:
            save_status(phase="connecting", target=f["ssid"], error="", message="")
            set_country(f["country"])
            time.sleep(2)                    # let the phone receive its "connecting" page first
            ok, why = join(f["ssid"], f["wifipass"], f["hidden"])
        if not ok:
            log("join failed:", why)
            nets = scan_safe() or ST["networks"]          # scan while the radio is free, then reopen setup
            hotspot_up()
            save_status(phase="hotspot", error="Couldn't join %s: %s." % (f["ssid"], why), networks=nets)
            return
        if f["wifi_only"]:                                 # rescue mode: only the Wi-Fi changed
            save_status(phase="online", error="", message="", ip=my_ip())
            log("rescue: joined", f["ssid"])
            return
        save_status(phase="applying", ip=my_ip())
        loc = apply_all(f)
        save_status(phase="done", first=False, message=loc.get("name", ""), ip=my_ip())
        log("setup done; restarting")
        time.sleep(8)
        if not os.environ.get("CB_NO_REBOOT"):
            sh("systemctl", "reboot")
    finally:
        WORK.clear()


def scan_safe():
    try:
        return scan()
    except Exception:
        return []


def clean_form(raw):
    g = lambda k, n=200: str(raw.get(k) or "").strip()[:n]
    f = {"ssid": g("ssid", 32), "wifipass": str(raw.get("wifipass") or "")[:63], "hidden": bool(raw.get("hidden")),
         "location": g("location", 80), "country": g("country", 4).upper(), "units": g("units", 10).lower(),
         "lang": g("lang", 2).lower(), "callsign": g("callsign", 24), "password": str(raw.get("password") or "")[:64],
         "ssh": bool(raw.get("ssh")), "wifi_only": bool(raw.get("wifi_only")) and not ST["first"],
         "keep_wifi": ST["phase"] == "lan"}
    if f["country"] == "AUTO":
        f["country"] = ""
    if f["units"] not in ("imperial", "metric"):
        f["units"] = "imperial"
    if f["lang"] not in LANGS:
        f["lang"] = "en"
    errs = []
    if not f["ssid"] and not f["keep_wifi"]:
        errs.append("Pick your Wi-Fi network.")
    if f["wifipass"] and not 8 <= len(f["wifipass"]) <= 63:
        errs.append("Wi-Fi passwords are 8 to 63 characters.")
    if f["ssh"] and len(f["password"]) < 8:
        errs.append("To turn on SSH, set a password of at least 8 characters.")
    if f["password"] and (len(f["password"]) < 8 or ":" in f["password"] or "\n" in f["password"]):
        errs.append("The board password needs 8+ characters and no colon.")
    return f, errs


# ---------------------------------------------------------------- change Wi-Fi from the board (CFG or the Pi's screen)
WIFI = {"state": "idle", "ssid": "", "error": "", "updated": 0}


def current_wifi():
    rc, out = sh("nmcli", "-t", "-f", "ACTIVE,SSID,SIGNAL", "device", "wifi", "list", "ifname", IFACE, "--rescan", "no", timeout=15)
    for line in out.splitlines() if rc == 0 else []:
        f = nm_split(line)
        if len(f) >= 3 and f[0] == "yes":
            return {"ssid": f[1], "signal": int(f[2]) if f[2].isdigit() else 0}
    return {"ssid": "", "signal": 0}


def active_wifi_con():
    rc, out = sh("nmcli", "-t", "-f", "NAME,TYPE", "connection", "show", "--active")
    for line in out.splitlines() if rc == 0 else []:
        f = nm_split(line)
        if len(f) >= 2 and f[1] == "802-11-wireless" and f[0] != AP_CON:
            return f[0]
    return ""


def run_wifi_change(ssid, password, hidden):
    WORK.set()
    prev = active_wifi_con()
    try:
        WIFI.update(state="connecting", ssid=ssid, error="", updated=time.time())
        ok, why = join(ssid, password, hidden)
        if ok:
            WIFI.update(state="ok", error="", updated=time.time())
            save_status(phase="online", error="", message="", ip=my_ip())
            wlog("wifi changed to", repr(ssid), "ip", my_ip())
        else:
            WIFI.update(state="failed", error="Couldn't join %s: %s." % (ssid, why), updated=time.time())
            if prev:                                   # go back to the network that worked
                sh("nmcli", "connection", "up", "id", prev, timeout=60)
            wlog("wifi change failed:", why, "- back to", repr(prev) if prev else "nothing")
    finally:
        WORK.clear()


def wifi_api(method, path, raw):
    """Local-only Wi-Fi control. Returns (code, body)."""
    if path == "/api/wifi/status" and method == "GET":
        return 200, dict(WIFI, current=current_wifi(), ip=my_ip(), online=online(), crashboard_setup=True)
    if path == "/api/wifi/scan" and method == "GET":
        if WORK.is_set():
            return 409, {"error": "busy"}
        return 200, {"networks": scan_safe(), "current": current_wifi(), "crashboard_setup": True}
    if path == "/api/wifi/connect" and method == "POST":
        if WORK.is_set():
            return 409, {"error": "Already connecting."}
        ssid = str(raw.get("ssid") or "").strip()[:32]
        pw = str(raw.get("password") or "")[:63]
        if not ssid:
            return 400, {"error": "Pick a Wi-Fi network."}
        if pw and not 8 <= len(pw) <= 63:
            return 400, {"error": "Wi-Fi passwords are 8 to 63 characters."}
        threading.Thread(target=run_wifi_change, args=(ssid, pw, bool(raw.get("hidden"))), daemon=True).start()
        return 200, {"ok": True, "ssid": ssid}
    return 404, {"error": "not found"}


# ---------------------------------------------------------------- web pages
def page(name):
    with open(os.path.join(HERE, name), encoding="utf-8") as fh:
        return fh.read()


def countries():
    try:
        sys.path.insert(0, APP)
        import regions
        return [list(c) for c in regions.country_list()]
    except Exception:
        return [["US", "United States"], ["CA", "Canada"], ["GB", "United Kingdom"], ["AU", "Australia"], ["NZ", "New Zealand"]]


STATIC_TYPES = {".js": "application/javascript", ".svg": "image/svg+xml", ".png": "image/png", ".css": "text/css"}


class Handler(BaseHTTPRequestHandler):
    server_version = "CrashBoardSetup/1"

    def log_message(self, *a):
        pass

    def send(self, code, body, ctype="application/json", extra=None):
        if isinstance(body, (dict, list)):
            body = json.dumps(body)
        if isinstance(body, str):
            body = body.encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype + ("; charset=utf-8" if ctype.startswith(("text", "application/json")) else ""))
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def allowed(self):
        """Setup pages are open while setting up (or in Wi-Fi rescue mode); afterwards only this Pi's screen."""
        local = self.client_address[0] in ("127.0.0.1", "::1")
        return local or ST["first"] or ST["phase"] in ("hotspot", "connecting", "applying", "lan", "done")

    def local(self):
        return self.client_address[0] in ("127.0.0.1", "::1")

    def do_GET(self):
        u = urllib.parse.urlsplit(self.path)
        p = u.path
        host = (self.headers.get("Host") or "").split(":")[0]
        if p.startswith("/api/wifi/"):
            if not self.local():
                return self.send(403, {"error": "local only"})
            return self.send(*wifi_api("GET", p, {}))
        if not self.allowed():
            return self.send(403, "Setup is finished. Change settings from CFG on the board.", "text/plain")
        if p == "/api/status":
            with LOCK:
                s = dict(ST)
            s["board_port"] = board_port()
            return self.send(200, s)
        if p == "/api/countries":
            return self.send(200, countries())
        if p == "/qr.svg":
            q = urllib.parse.parse_qs(u.query).get("t", [""])[0][:200]
            try:
                return self.send(200, qr.qr_svg(q), "image/svg+xml")
            except ValueError:
                return self.send(400, "too long", "text/plain")
        if p.startswith("/static/"):
            name = os.path.basename(p)
            for d in (os.path.join(APP, "static"), HERE):
                fp = os.path.join(d, name)
                if os.path.isfile(fp) and os.path.splitext(name)[1] in STATIC_TYPES:
                    with open(fp, "rb") as fh:
                        return self.send(200, fh.read(), STATIC_TYPES[os.path.splitext(name)[1]])
            return self.send(404, "not found", "text/plain")
        if p == "/screen":
            return self.send(200, page("screen.html"), "text/html")
        # captive portal: phones probe random sites; send them all to the setup page
        if host and host not in (AP_IP, "localhost", "127.0.0.1", ST.get("ip")) and not host.endswith(".local"):
            return self.send(302, "", "text/plain", {"Location": "http://%s/" % AP_IP})
        return self.send(200, page("phone.html"), "text/html")

    def do_POST(self):
        if self.path.startswith("/api/wifi/"):
            if not self.local():
                return self.send(403, {"error": "local only"})
            try:
                n = min(int(self.headers.get("Content-Length") or 0), 4096)
                raw = json.loads(self.rfile.read(n) or b"{}")
            except (ValueError, json.JSONDecodeError):
                return self.send(400, {"error": "bad request"})
            return self.send(*wifi_api("POST", self.path, raw))
        if not self.allowed():
            return self.send(403, {"error": "setup finished"})
        if self.path != "/api/setup":
            return self.send(404, {"error": "not found"})
        if WORK.is_set():
            return self.send(409, {"error": "Already connecting. Watch the board's screen."})
        try:
            n = min(int(self.headers.get("Content-Length") or 0), 8192)
            raw = json.loads(self.rfile.read(n) or b"{}")
        except (ValueError, json.JSONDecodeError):
            return self.send(400, {"error": "bad request"})
        f, errs = clean_form(raw)
        if errs:
            return self.send(400, {"error": " ".join(errs)})
        threading.Thread(target=run_setup, args=(f,), daemon=True).start()
        return self.send(200, {"ok": True, "ssid": f["ssid"]})


# ---------------------------------------------------------------- main loop
def setup_mode(rescue):
    nets = scan_safe()
    save_status(phase="hotspot", networks=nets, error="", message="rescue" if rescue else "")
    if not hotspot_up():
        save_status(phase="error", error="Couldn't start the setup Wi-Fi. Restart the board.")
        return False
    return True


def main():
    os.makedirs(RUN, exist_ok=True)
    srv = ThreadingHTTPServer(("0.0.0.0", PORT), Handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    log("setup server on port", PORT, "first boot" if ST["first"] else "rescue watch")
    sh("rfkill", "unblock", "wifi")

    if ST["first"]:
        for _ in range(5):                        # already online (Ethernet, or Wi-Fi set up some other way)?
            if online():
                break
            time.sleep(5)
        if online():
            save_status(phase="lan", ip=my_ip(), networks=[], error="")
            log("already online: setup page on http://%s/" % ST["ip"])
        else:
            setup_mode(rescue=False)
        while True:                               # wait for the phone; run_setup reboots when done
            time.sleep(5)
    # later boots: watch the connection; open the setup Wi-Fi if nothing known is reachable
    offline_since = None
    while True:
        if WORK.is_set():
            time.sleep(5); continue
        if online():
            offline_since = None
            if ST["phase"] != "online":
                save_status(phase="online", error="", ip=my_ip())
            time.sleep(30); continue
        offline_since = offline_since or time.time()
        save_status(phase="offline")
        if time.time() - offline_since < float(os.environ.get("CB_RESCUE_AFTER", "180")):
            time.sleep(10); continue
        wlog("no internet for a while: opening setup Wi-Fi", ap_name())
        if setup_mode(rescue=True):
            t0 = time.time()                      # keep it up 10 min, longer while a phone is on it
            while time.time() - t0 < float(os.environ.get("CB_RESCUE_HOLD", "600")) or hotspot_clients() or WORK.is_set():
                time.sleep(10)
                if ST["phase"] == "done":
                    break
            if ST["phase"] != "done" and not WORK.is_set():
                hotspot_down()                    # let NetworkManager retry the known networks
                save_status(phase="offline")
        offline_since = time.time()


if __name__ == "__main__":
    main()
