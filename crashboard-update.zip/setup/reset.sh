#!/bin/bash
# CRASH BOARD: put this board back to "first-time setup", like a freshly flashed card.
# Use it before giving or selling a board, or to make a master card to copy.
#   sudo ~/crashboard/setup/reset.sh              forget Wi-Fi + location, then restart into setup
#   sudo ~/crashboard/setup/reset.sh --shutdown   same, but power off (to copy the card afterwards)
# A PRO license key stays on the board.
set -u
[ "$(id -u)" -eq 0 ] || { echo "Run it with sudo:  sudo $0 $*"; exit 1; }
APP="$(cd "$(dirname "$0")/.." && pwd)"
USER_NAME="$(stat -c %U "$APP")"
echo "This forgets the Wi-Fi networks, location and settings on this board."
if [ "${CB_YES:-}" != 1 ]; then read -r -p "Type YES to continue: " a; [ "$a" = YES ] || { echo "Cancelled."; exit 1; }; fi

systemctl stop crashboard.service crashboard-mesh.service 2>/dev/null
rm -f "$APP/data/setup-done.json" "$APP/data/config.json" "$APP/data/cache.json" "$APP/data/events.json" "$APP/data/port.txt"
# saved Wi-Fi networks (everything NetworkManager knows except the setup hotspot)
nmcli -t -f NAME,TYPE connection show 2>/dev/null | while IFS=: read -r name type; do
  [ "$type" = 802-11-wireless ] && nmcli connection delete "$name" >/dev/null 2>&1
done
# back to the image defaults: SSH off, default password, fresh SSH keys on next start
systemctl disable --now ssh 2>/dev/null
echo "$USER_NAME:crashboard" | chpasswd
rm -f /etc/ssh/ssh_host_* && systemctl enable regenerate_ssh_host_keys 2>/dev/null
rm -f "/home/$USER_NAME/.bash_history" /root/.bash_history
echo "Done."
if [ "${1:-}" = --shutdown ]; then echo "Powering off. You can copy the card once the green light stops."; poweroff
else echo "Restarting into first-time setup..."; reboot; fi
