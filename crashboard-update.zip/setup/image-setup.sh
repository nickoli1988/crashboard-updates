#!/bin/bash
# CRASH BOARD appliance setup: board starts at boot, shows on the attached screen, and the
# phone setup (Wi-Fi + location) runs on first start.
#
# Used by the SD-card image build (runs inside the image while it is being made), and also works
# on a normal Raspberry Pi OS install:   sudo ~/crashboard/setup/image-setup.sh
set -e
APP="$(cd "$(dirname "$0")/.." && pwd)"
EDITION="$(basename "$APP")"
case "$EDITION" in crashboard|crashboard-mesh) ;; *) EDITION=crashboard ;; esac
U="${CB_USER:-$(stat -c %U "$APP")}"
[ "$U" = root ] && U="$(getent passwd 1000 | cut -d: -f1)"
[ -n "$U" ] || { echo "No user account found."; exit 1; }
HOME_DIR="$(getent passwd "$U" | cut -d: -f6)"
SERVICE="$EDITION.service"
PORT=8080; [ "$EDITION" = crashboard-mesh ] && PORT=8090
echo "== Crash Board appliance setup: $EDITION for user $U =="

PKGS="xserver-xorg xinit x11-xserver-utils unclutter surf fonts-dejavu-core network-manager dnsmasq-base iw rfkill python3 python3-pil"
if [ -z "${CB_IMAGE_BUILD:-}" ]; then          # the image build installs these itself
  apt-get update
  apt-get install -y --no-install-recommends $PKGS
fi

usermod -aG video,tty,input,audio "$U" 2>/dev/null || true      # draw on the screen directly (Pi Zero)
mkdir -p "$APP/data"
chown -R "$U":"$U" "$APP"
chmod +x "$APP"/*.sh "$APP"/setup/*.sh 2>/dev/null || true

# ---- RADIO page INSTALL RADIO SUPPORT button: the board may run only this root-owned helper
install -o root -g root -m 755 "$APP/setup/radio-helper.sh" /usr/local/sbin/crashboard-radio-setup
printf '%s ALL=(root) NOPASSWD: /usr/local/sbin/crashboard-radio-setup install, /usr/local/sbin/crashboard-radio-setup reboot\n' "$U" > /etc/sudoers.d/crashboard-radio
chmod 440 /etc/sudoers.d/crashboard-radio
visudo -cf /etc/sudoers.d/crashboard-radio >/dev/null 2>&1 || rm -f /etc/sudoers.d/crashboard-radio

# ---- the board itself (starts at boot, restarts if it crashes)
cat > "/etc/systemd/system/$SERVICE" <<EOF
[Unit]
Description=Crash Board threat monitor ($EDITION)
After=network-online.target
Wants=network-online.target

[Service]
User=$U
WorkingDirectory=$APP
Environment=CRASHBOARD_PORT=$PORT
ExecStart=/usr/bin/python3 $APP/server.py --port $PORT
Restart=always
RestartSec=10
Nice=5

[Install]
WantedBy=multi-user.target
EOF
systemctl enable "$SERVICE"

# ---- phone setup + Wi-Fi rescue
sed "s#@APP@#$APP#g" "$APP/setup/crashboard-wizard.service" > /etc/systemd/system/crashboard-wizard.service
systemctl enable crashboard-wizard.service
mkdir -p /etc/NetworkManager/dnsmasq-shared.d
echo "address=/#/10.42.0.1" > /etc/NetworkManager/dnsmasq-shared.d/crashboard-captive.conf   # every name -> setup page

# ---- Meshtastic radio support (COMMS): library + USB serial permission
if true; then
  usermod -aG dialout "$U"
  if ! runuser -u "$U" -- python3 -c "import meshtastic" 2>/dev/null; then
    apt-get install -y --no-install-recommends python3-pip || true
    runuser -u "$U" -- python3 -m pip install --user --break-system-packages meshtastic || \
      runuser -u "$U" -- python3 -m pip install --user meshtastic || \
      echo "WARNING: meshtastic library not installed. Install it later with: python3 -m pip install --user --break-system-packages meshtastic"
  fi
fi

# ---- show the board on the screen: auto-login on tty1, then start X + kiosk
mkdir -p /etc/systemd/system/getty@tty1.service.d
cat > /etc/systemd/system/getty@tty1.service.d/autologin.conf <<EOF
[Service]
ExecStart=
ExecStart=-/sbin/agetty --autologin $U --noclear --noissue --nohostname %I \$TERM
EOF
systemctl set-default multi-user.target
PROFILE="$HOME_DIR/.bash_profile"
sed -i '/# crashboard-kiosk/,/^fi$/d; /# crashboard-mesh-kiosk/,/^fi$/d' "$PROFILE" 2>/dev/null || true
MARK="# crashboard-kiosk"; [ "$EDITION" = crashboard-mesh ] && MARK="# crashboard-mesh-kiosk"
cat >> "$PROFILE" <<EOF

$MARK
if [ -z "\$DISPLAY" ] && [ "\$(tty)" = "/dev/tty1" ]; then
  CB_XFAIL=0
  while true; do
    CB_FB=0
    case "\$(uname -m)" in armv6l) CB_FB=1;; esac
    grep -qaE "Raspberry Pi ([123]|Zero)" /proc/device-tree/model 2>/dev/null && CB_FB=1
    [ -f $APP/data/use-fb ] && CB_FB=1
    [ -f $APP/data/use-browser ] && CB_FB=0
    [ \$CB_XFAIL -ge 3 ] && CB_FB=1                # the browser screen failed to start 3 times
    python3 -c "import PIL" 2>/dev/null || CB_FB=0  # no Pillow: only the browser can draw
    mkdir -p $APP/data
    if [ "\$CB_FB" = 1 ]; then
      # Pi Zero / Pi 1-3: draw the board straight onto the screen (no web browser)
      python3 $APP/zero/fbboard.py >$APP/data/fb.log 2>&1
    else
      CB_T0=\$(date +%s)
      startx $APP/kiosk.sh >$APP/data/x.log 2>&1
      [ \$(( \$(date +%s) - CB_T0 )) -lt 30 ] && CB_XFAIL=\$((CB_XFAIL+1))
    fi
    sleep 3
  done
fi
EOF
chown "$U":"$U" "$PROFILE"

# Pi 1-3: the browser draws, but with the "modesetting" driver the picture never reaches HDMI (black screen).
# Draw through the framebuffer instead (the same screen the light screen uses), and run the TV at 720p.
if grep -qaE "Raspberry Pi ([123]|Zero)" /proc/device-tree/model 2>/dev/null; then
  mkdir -p /etc/X11/xorg.conf.d
  printf '%s\n' 'Section "Device"' '    Identifier "CrashBoardScreen"' '    Driver     "fbdev"' \
    '    Option     "fbdev" "/dev/fb0"' '    Option     "ShadowFB" "on"' 'EndSection' | tee /etc/X11/xorg.conf.d/99-crashboard-screen.conf >/dev/null
  for c in /boot/firmware/cmdline.txt /boot/cmdline.txt; do
    [ -f "$c" ] && ! grep -q "video=HDMI" "$c" && sed -i '1 s/$/ video=HDMI-A-1:1280x720@60/' "$c" || true
  done
fi

# Pi 5: point the browser screen at the graphics device that drives HDMI (checked at every start)
if [ -f "$APP/setup/crashboard-pi5-screen.service" ]; then
  sed "s#@APP@#$APP#g" "$APP/setup/crashboard-pi5-screen.service" > /etc/systemd/system/crashboard-pi5-screen.service
  systemctl enable crashboard-pi5-screen.service
fi

# ---- never blank the console, quiet boot (no rainbow, logos or scrolling text), start-up splash
for c in /boot/firmware/cmdline.txt /boot/cmdline.txt; do
  [ -f "$c" ] || continue
  for opt in consoleblank=0 quiet loglevel=3 logo.nologo vt.global_cursor_default=0 udev.log_level=3; do
    grep -qw -- "$opt" "$c" || sed -i "1 s/\$/ $opt/" "$c"
  done
done
for c in /boot/firmware/config.txt /boot/config.txt; do
  if [ -f "$c" ] && ! grep -q '^disable_splash=1' "$c"; then printf '\n# Crash Board: no rainbow screen at power-on\ndisable_splash=1\n' >> "$c"; fi
done
touch "$HOME_DIR/.hushlogin"; chown "$U":"$U" "$HOME_DIR/.hushlogin"
if [ -f "$APP/setup/crashboard-splash.service" ]; then
  sed "s#@APP@#$APP#g" "$APP/setup/crashboard-splash.service" > /etc/systemd/system/crashboard-splash.service
  systemctl enable crashboard-splash.service
fi

echo "$EDITION $(date +%Y-%m-%d)" > /etc/crashboard-image
echo "== done. Restart to begin first-time setup. =="
