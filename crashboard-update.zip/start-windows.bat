@echo off
REM Crash Board for Windows - double-click to run.
title Crash Board
cd /d "%~dp0"

REM Find a REAL Python 3 (Windows has a fake "python" that only opens the Microsoft Store).
set "PY="
py -3 -c "import sys" >nul 2>nul && set "PY=py -3"
if not defined PY python -c "import sys; assert sys.version_info[0]==3" >nul 2>nul && set "PY=python"
if not defined PY (
  echo.
  echo  =====================================================
  echo   PYTHON IS NOT INSTALLED
  echo  =====================================================
  echo   1. Go to https://www.python.org/downloads/
  echo   2. Download and run the installer
  echo   3. On the FIRST screen, tick "Add python.exe to PATH"
  echo   4. Click Install Now, then run this file again
  echo.
  start "" https://www.python.org/downloads/
  pause
  exit /b 1
)

%PY% -c "import meshtastic" >nul 2>nul
if errorlevel 1 (
  echo  Adding Meshtastic radio support (one time, about a minute^)...
  %PY% -m pip install --user -q meshtastic >nul 2>nul
)
echo  Starting Crash Board server...
if exist "data\port.txt" del "data\port.txt"
start "Crash Board server" /min cmd /k %PY% server.py
set "PORT="
for /l %%i in (1,1,20) do (
  if not defined PORT if exist "data\port.txt" set /p PORT=<"data\port.txt"
  if not defined PORT timeout /t 1 /nobreak >nul
)
if not defined PORT (
  echo.
  echo  The server did not start. Open the "Crash Board server" window
  echo  on the taskbar to see the error, and send a screenshot of it.
  echo.
  pause
  exit /b 1
)
set "URL=http://127.0.0.1:%PORT%"

where msedge >nul 2>nul && (start "" msedge --app=%URL% & goto :done)
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
  start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app=%URL%
  goto :done
)
start "" %URL%

:done
echo.
echo  Crash Board is running at %URL%
echo  To stop it, close the "Crash Board server" window.
timeout /t 8 >nul
