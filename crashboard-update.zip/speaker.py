"""Crash Board speaker: plays the alert sounds straight through the Pi's sound card (ALSA).

On the SD-card image the board's screen is a light browser that can't always reach the speaker, so the
screen asks the board to play its alert sounds here instead. These are the same soft bells as the web
board (app.js SOUNDS), made by code, no recordings. Uses only libasound (always present with sound
on Linux) and the standard library: no extra packages.
"""
import array
import ctypes
import os
import re
import wave
import ctypes.util
import math
import threading
import queue as _queue

RATE = 48000
BOOST = 3.0          # small 3 W amp kits are quiet: loudest bell peaks around 60% at volume 100


class _Synth:
    def __init__(self, length):
        self.buf = array.array("f", bytes(4 * int(RATE * length)))

    def _env(self, i, n_att, n_end, peak, start=0.0001):
        if i < n_att:
            return start * (peak / start) ** (i / max(1, n_att))
        return peak * (0.0001 / peak) ** ((i - n_att) / max(1, n_end - n_att))

    def bell(self, f, t0, dur, vol=0.2):
        s0, n = int(t0 * RATE), int(dur * RATE)
        n_att = int(0.04 * RATE)
        b = self.buf
        for freq, part in ((f, 1.0), (f * 2, 0.18)):
            peak = vol * part
            w = 2 * math.pi * freq / RATE
            for i in range(min(n, len(b) - s0)):
                b[s0 + i] += math.sin(w * i) * self._env(i, n_att, n, peak)

    def swell(self, f, t0, dur, vol=0.12):
        s0, n = int(t0 * RATE), int(dur * RATE)
        n_att = int(dur * 0.4 * RATE)
        period = RATE / f
        b = self.buf
        for i in range(min(n, len(b) - s0)):
            ph = (i / period) % 1.0
            tri = 4 * ph - 1 if ph < 0.5 else 3 - 4 * ph
            b[s0 + i] += tri * self._env(i, n_att, n, vol)


def _klaxon(s):
    for k in range(2):
        s.bell(523, k * 1.1, 0.7); s.bell(659, k * 1.1 + 0.2, 0.7); s.bell(784, k * 1.1 + 0.4, 0.9)
    s.swell(131, 0, 2.2, 0.08)


SOUNDS = {      # kind: (length in seconds, recipe)  -- same as app.js
    "klaxon": (2.4, _klaxon),
    "seismic": (2.9, lambda s: (s.swell(98, 0, 1.4, 0.12), s.bell(660, 0.9, 1.1, 0.18), s.bell(660, 1.5, 1.3, 0.15))),
    "weather": (1.4, lambda s: (s.bell(659, 0, 0.9, 0.17), s.bell(880, 0.22, 1.1, 0.17))),
    "fire": (1.7, lambda s: (s.bell(988, 0, 0.8, 0.18), s.bell(784, 0.2, 0.8, 0.18), s.bell(659, 0.4, 1.2, 0.18), s.swell(165, 0, 1.4, 0.07))),
    "bio": (1.7, lambda s: (s.bell(440, 0, 0.8, 0.16), s.bell(330, 0.35, 1.2, 0.16))),
    "space": (1.4, lambda s: (s.bell(784, 0, 0.6, 0.15), s.bell(988, 0.18, 0.6, 0.15), s.bell(1175, 0.36, 0.9, 0.15))),
    "chirp": (0.8, lambda s: (s.bell(1046, 0, 0.35, 0.13), s.bell(1046, 0.2, 0.45, 0.13))),
}
_cache = {}


def render(kind):
    """Float samples (-1..1) for one sound, made once and kept."""
    kind = kind if kind in SOUNDS else "chirp"
    if kind not in _cache:
        length, recipe = SOUNDS[kind]
        s = _Synth(length)
        recipe(s)
        _cache[kind] = s.buf
    return _cache[kind]


def pcm(kind, volume=70, repeat=1):
    """16-bit stereo PCM bytes for one sound at the board's volume (same curve as the web board)."""
    g = (max(0, min(100, volume)) / 100.0) ** 2 * 0.9 * 32767 * BOOST
    one = render(kind)
    gap = int(0.4 * RATE)
    out = array.array("h")
    for r in range(repeat):
        if r:
            out.extend([0] * (gap * 2))
        for v in one:
            x = int(max(-1.0, min(1.0, v)) * g)
            out.append(x); out.append(x)
    return out.tobytes()


VOICE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static", "voice")
_voice_cache = {}


def voice_pcm(name, volume=70):
    """A spoken clip (static/voice/<name>.wav, 22 kHz mono) as 48 kHz 16-bit stereo at the board's volume."""
    if not name or not re.match(r"^[a-z0-9-]{1,24}$", name):
        return b""
    if name not in _voice_cache:
        path = os.path.join(VOICE_DIR, name + ".wav")
        if not os.path.isfile(path):
            return b""
        w = wave.open(path)
        src = array.array("h", w.readframes(w.getnframes()))
        rate, ch = w.getframerate(), w.getnchannels()
        w.close()
        if ch == 2:
            src = src[::2]
        n = int(len(src) * RATE / rate)
        step = rate / float(RATE)
        out = array.array("f", bytes(4 * n))
        last = len(src) - 1
        for i in range(n):                      # linear resample to 48 kHz
            pos = i * step
            j = int(pos)
            f = pos - j
            a = src[j]
            b = src[j + 1] if j < last else a
            out[i] = (a + (b - a) * f) / 32768.0
        _voice_cache[name] = out
    g = min(1.0, (max(0, min(100, volume)) / 100.0) ** 2 * 1.6) * 32767   # the clips are already loud: no boost
    res = array.array("h")
    for v in _voice_cache[name]:
        x = int(max(-1.0, min(1.0, v)) * g)
        res.append(x); res.append(x)
    return res.tobytes()


class Speaker:
    def __init__(self, log=print):
        self.log = log
        self.q = _queue.Queue(maxsize=6)
        self.error = ""
        self.lib = None
        try:
            self.lib = ctypes.CDLL(ctypes.util.find_library("asound") or "libasound.so.2")
            self.lib.snd_strerror.restype = ctypes.c_char_p
        except OSError as e:
            self.error = "no sound library (%s)" % e
        self.ok = self.lib is not None
        if self.ok:
            threading.Thread(target=self._loop, daemon=True, name="speaker").start()
            threading.Thread(target=lambda: [render(k) for k in SOUNDS], daemon=True, name="speaker-warm").start()

    def status(self):
        return {"ok": self.ok, "error": self.error}

    def play(self, kind, volume=70, sev=2, voice=None):
        """Bell (twice for critical alerts, like the web board), then the spoken clip if one is given."""
        if not self.ok:
            return False
        try:
            self.q.put_nowait((kind, int(volume), 2 if sev >= 3 else 1, voice))
            return True
        except _queue.Full:
            return False

    def _loop(self):
        while True:
            kind, volume, rep, voice = self.q.get()
            try:
                data = pcm(kind, volume, rep) if kind else b""
                if voice:
                    spoken = voice_pcm(voice, volume)
                    if spoken:
                        data += bytes(4 * int(0.3 * RATE)) + spoken if data else spoken
                if data:
                    self._write(data)
                self.error = ""
            except Exception as e:
                self.error = str(e)
                self.log("speaker:", e)

    def _write(self, data):
        a = self.lib
        h = ctypes.c_void_p()
        r = a.snd_pcm_open(ctypes.byref(h), b"default", 0, 0)
        if r < 0:
            raise RuntimeError("can't open the speaker: %s" % a.snd_strerror(r).decode())
        try:
            # S16_LE = 2, RW_INTERLEAVED = 3, 2 channels, 48 kHz, allow resampling, 0.5 s latency
            r = a.snd_pcm_set_params(h, 2, 3, 2, RATE, 1, 500000)
            if r < 0:
                raise RuntimeError("speaker setup failed: %s" % a.snd_strerror(r).decode())
            frames = len(data) // 4
            r = a.snd_pcm_writei(h, data, frames)
            if r < 0:
                a.snd_pcm_recover(h, r, 1)
                r = a.snd_pcm_writei(h, data, frames)
            a.snd_pcm_drain(h)
        finally:
            a.snd_pcm_close(h)
