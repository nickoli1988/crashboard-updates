#!/data/data/com.termux/files/usr/bin/bash
# CRASH BOARD for Android (runs inside Termux).
#   bash install-android.sh
set -e
APP_DIR="$(cd "$(dirname "$0")" && pwd)"
echo "== CRASH BOARD Android install =="

yes | pkg update >/dev/null 2>&1 || true
pkg install -y python termux-api
mkdir -p "$APP_DIR/data"
chmod +x "$APP_DIR"/*-android.sh

# Auto-start when the phone boots (needs the Termux:Boot app, opened once)
mkdir -p ~/.termux/boot
cat > ~/.termux/boot/crashboard.sh <<BOOT
#!/data/data/com.termux/files/usr/bin/sh
termux-wake-lock
cd "$APP_DIR" && CRASHBOARD_MOBILE=\${CRASHBOARD_MOBILE:-1} nohup python server.py > data/server.log 2>&1 &
BOOT
chmod +x ~/.termux/boot/crashboard.sh

# Home-screen shortcut (needs the Termux:Widget app; optional)
mkdir -p ~/.shortcuts
cat > ~/.shortcuts/Crash-Board <<SC
#!/data/data/com.termux/files/usr/bin/bash
bash "$APP_DIR/start-android.sh"
SC
chmod +x ~/.shortcuts/Crash-Board

echo
echo "== DONE =="
echo "Start it now:   bash $APP_DIR/start-android.sh"
echo "Stop it:        bash $APP_DIR/stop-android.sh"
echo "Test an alert:  bash $APP_DIR/start-android.sh test"
