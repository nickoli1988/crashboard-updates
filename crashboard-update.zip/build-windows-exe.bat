@echo off
REM Builds Crash Board for Windows as a normal program (CrashBoard.exe). Double-click to run.
REM Needs Python (the same one start-windows.bat uses) and an internet connection the first time.
title Build Crash Board for Windows
cd /d "%~dp0"

set "PY="
py -3 -c "import sys" >nul 2>nul && set "PY=py -3"
if not defined PY python -c "import sys; assert sys.version_info[0]==3" >nul 2>nul && set "PY=python"
if not defined PY (
  echo.
  echo  Python is not installed. Install it from https://www.python.org/downloads/
  echo  ^(tick "Add python.exe to PATH" on the first screen^), then run this file again.
  start "" https://www.python.org/downloads/
  pause
  exit /b 1
)

echo.
echo  ==== 1/3  Downloading PyInstaller and the tray-icon tools ====
%PY% -m pip install --user --upgrade pyinstaller pystray pillow pywebview meshtastic
if errorlevel 1 goto failed

echo.
echo  ==== 2/3  Building CrashBoard.exe (takes a few minutes) ====
REM a Crash Board started from an earlier build locks its files: close it first
tasklist /fi "imagename eq CrashBoard.exe" 2>nul | find /i "CrashBoard.exe" >nul && (
  echo  Closing the Crash Board that is already running...
  taskkill /im "CrashBoard.exe" /f >nul 2>nul
  timeout /t 3 /nobreak >nul
)
if exist "build" rmdir /s /q "build"
if exist "dist\CrashBoard" rmdir /s /q "dist\CrashBoard"
if exist "dist\CrashBoard" (
  echo.
  echo  Windows will not let me replace the old dist\CrashBoard folder. Something still has it open:
  echo  quit Crash Board from the icon by the clock, close any File Explorer window showing that
  echo  folder, then run this file again.
  pause
  exit /b 1
)
%PY% -m PyInstaller --noconfirm --clean --windowed --name "CrashBoard" --icon "windows\crashboard.ico" --paths . --add-data "static;static" --hidden-import pystray._win32 --collect-all webview --collect-all meshtastic --collect-all pubsub --collect-all bleak --collect-all google.protobuf "windows\launcher.py"
if errorlevel 1 goto failed
if not exist "dist\CrashBoard\CrashBoard.exe" goto failed

echo.
echo  ==== 3/3  Packing a zip you can share ====
REM Your settings and PRO key are NOT in it: they live in your Windows user folder, never in dist\.
powershell -NoProfile -Command "Compress-Archive -Path 'dist\CrashBoard' -DestinationPath 'CrashBoard-Windows.zip' -Force"
rmdir /s /q "build" >nul 2>nul
del /q "CrashBoard.spec" >nul 2>nul

echo.
echo  ==== DONE ====
echo  The program:   dist\CrashBoard\CrashBoard.exe   (keep it inside its folder)
echo  To share:      CrashBoard-Windows.zip
echo.
echo  Double-click CrashBoard.exe to start. It opens the board in its own window and adds an icon by the clock.
echo  If Windows Firewall asks, tick Private networks and click Allow (so phones on your Wi-Fi can see the board).
explorer "dist\CrashBoard"
pause
exit /b 0

:failed
echo.
echo  ==== THE BUILD STOPPED ====
echo  Scroll up to the first red ERROR line, and send Claude a screenshot or a copy of it.
pause
exit /b 1
