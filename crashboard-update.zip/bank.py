"""CRASH BANK: a local file library on the board (PRO).

Phones and laptops on the same Wi-Fi (your home Wi-Fi, a battery travel router, or the Pi's own
setup Wi-Fi) can browse and download files, and anyone with the upload PIN can add, rename and
delete them. Nothing leaves your network.

Storage: a USB stick if one is plugged into the Pi (a folder called CrashBank is made on it),
otherwise data/bank inside Crash Board. A different folder can be set in CFG.
"""
import json
import os
import re
import shutil
import time
import unicodedata

BASE = os.path.dirname(os.path.abspath(__file__))
DEFAULT = {
    "pin": "",                  # upload / change PIN ("" = anyone on the network can upload)
    "dir": "",                  # "" = automatic (USB stick if present, else data/bank)
    "max_upload_mb": 4096,
}
STARTER = ("Manuals", "Medical", "Maps", "Comms Plans", "Family Documents", "Photos")
README = """CRASH BANK
==========
This folder is your board's local file library. Phones and laptops on the same Wi-Fi can open it from
the BANK button on Crash Board, even with no internet.

Good things to keep here (all free, public-domain US government publications):
  * FEMA "Are You Ready? An In-Depth Guide to Citizen Preparedness"   (ready.gov)
  * US Army FM 21-76 / ATP 3-50.21 Survival                           (armypubs.army.mil)
  * US Army ATP 4-25.13 Casualty Care / first-aid manuals             (armypubs.army.mil)
  * Your county's emergency plan and evacuation maps                  (your county website)
  * Copies of IDs, insurance, prescriptions and contact lists          (Family Documents, set an upload PIN!)
"""
MIME = {
    ".pdf": "application/pdf", ".txt": "text/plain; charset=utf-8", ".md": "text/plain; charset=utf-8",
    ".csv": "text/csv; charset=utf-8", ".html": "text/plain; charset=utf-8", ".htm": "text/plain; charset=utf-8",
    ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".gif": "image/gif", ".webp": "image/webp",
    ".svg": "text/plain; charset=utf-8",                    # shown as text, never run as a web page
    ".mp3": "audio/mpeg", ".m4a": "audio/mp4", ".wav": "audio/wav", ".ogg": "audio/ogg",
    ".mp4": "video/mp4", ".webm": "video/webm", ".mov": "video/quicktime",
    ".gpx": "application/gpx+xml", ".kml": "application/vnd.google-earth.kml+xml",
    ".zip": "application/zip", ".epub": "application/epub+zip",
}


class BankError(ValueError):
    pass


def _usb_root():
    """First writable USB stick mounted by the Pi (Raspberry Pi OS mounts them under /media/<user>/)."""
    for top in ("/media",):                     # USB sticks only (never /mnt, /boot or other system mounts)
        try:
            users = sorted(os.listdir(top))
        except OSError:
            continue
        for u in users:
            p = os.path.join(top, u)
            cands = [p] + ([os.path.join(p, d) for d in sorted(os.listdir(p))] if os.path.isdir(p) else [])
            for c in cands:
                if os.path.ismount(c) and os.access(c, os.W_OK):
                    return c
    return None


class Bank:
    def __init__(self, data_dir):
        self.data_dir = data_dir
        self.cfg = dict(DEFAULT)
        self.root = None
        self.where = ""

    def configure(self, cfg):
        self.cfg = dict(DEFAULT)
        self.cfg.update(cfg or {})
        self.root = None

    # ------------------------------------------------------------------ storage
    def _root(self):
        if self.root and os.path.isdir(self.root):
            return self.root
        want = (self.cfg.get("dir") or "").strip()
        if want:
            root, self.where = os.path.abspath(os.path.expanduser(want)), "custom"
        else:
            usb = _usb_root()
            if usb:
                root, self.where = os.path.join(usb, "CrashBank"), "usb"
            else:
                root, self.where = os.path.join(self.data_dir, "bank"), "board"
        fresh = not os.path.isdir(root)
        os.makedirs(root, exist_ok=True)
        if fresh:
            for d in STARTER:
                os.makedirs(os.path.join(root, d), exist_ok=True)
            with open(os.path.join(root, "READ ME.txt"), "w", encoding="utf-8") as f:
                f.write(README)
        self.root = root
        return root

    def _path(self, rel, must_exist=True):
        """Resolve a library path safely (no escaping the library with .. or links)."""
        rel = (rel or "").replace("\\", "/").strip("/")
        parts = [p for p in rel.split("/") if p not in ("", ".")]
        if any(p == ".." or p.startswith(".") for p in parts):
            raise BankError("bad path")
        root = os.path.realpath(self._root())
        full = os.path.realpath(os.path.join(root, *parts)) if parts else root
        if full != root and not full.startswith(root + os.sep):
            raise BankError("bad path")
        if must_exist and not os.path.exists(full):
            raise BankError("not found")
        return full, "/".join(parts)

    @staticmethod
    def clean_name(name):
        name = unicodedata.normalize("NFC", str(name or "")).replace("\\", "/").split("/")[-1]
        name = re.sub(r'[\x00-\x1f<>:"|?*]', "", name).strip().strip(".")
        if not name:
            raise BankError("bad file name")
        return name[:150]

    # ------------------------------------------------------------------ reading
    def info(self):
        root = self._root()
        try:
            du = shutil.disk_usage(root)
            free, total = du.free, du.total
        except OSError:
            free = total = 0
        return {"where": self.where, "root_name": os.path.basename(root), "free": free, "total": total,
                "pin_set": bool(self.cfg.get("pin")), "max_upload_mb": int(self.cfg.get("max_upload_mb") or 4096)}

    def listdir(self, rel):
        full, rel = self._path(rel)
        if not os.path.isdir(full):
            raise BankError("not a folder")
        out = []
        for name in os.listdir(full):
            if name.startswith(".") or name.endswith(".part"):
                continue
            p = os.path.join(full, name)
            try:
                st = os.stat(p)
            except OSError:
                continue
            isdir = os.path.isdir(p)
            out.append({"name": name, "dir": isdir, "size": 0 if isdir else st.st_size, "mtime": int(st.st_mtime),
                        "items": (len([x for x in os.listdir(p) if not x.startswith(".")]) if isdir else None)})
        out.sort(key=lambda x: (not x["dir"], x["name"].lower()))
        return {"path": rel, "items": out}

    def search(self, q, limit=200):
        q = (q or "").strip().lower()
        if len(q) < 2:
            raise BankError("type at least 2 letters")
        root = self._root()
        hits = []
        for dp, dns, fns in os.walk(root):
            dns[:] = [d for d in dns if not d.startswith(".")]
            for n in dns + fns:
                if q in n.lower() and not n.endswith(".part"):
                    p = os.path.join(dp, n)
                    rel = os.path.relpath(p, root).replace(os.sep, "/")
                    st = os.stat(p)
                    hits.append({"path": rel, "name": n, "dir": os.path.isdir(p), "size": 0 if os.path.isdir(p) else st.st_size,
                                 "mtime": int(st.st_mtime)})
                    if len(hits) >= limit:
                        return {"items": hits}
        return {"items": hits}

    def file(self, rel):
        full, rel = self._path(rel)
        if not os.path.isfile(full):
            raise BankError("not a file")
        ext = os.path.splitext(full)[1].lower()
        return full, MIME.get(ext, "application/octet-stream"), os.path.getsize(full)

    # ------------------------------------------------------------------ changing (needs the PIN)
    def check_pin(self, pin):
        want = str(self.cfg.get("pin") or "")
        if want and str(pin or "") != want:
            raise PermissionError("Wrong or missing upload PIN")

    def upload(self, rel_dir, name, length, reader):
        full_dir, _ = self._path(rel_dir)
        if not os.path.isdir(full_dir):
            raise BankError("not a folder")
        name = self.clean_name(name)
        if length <= 0:
            raise BankError("empty file")
        if length > int(self.cfg.get("max_upload_mb") or 4096) * 1024 * 1024:
            raise BankError("file is bigger than the upload limit")
        if shutil.disk_usage(full_dir).free < length + 50 * 1024 * 1024:
            raise BankError("not enough free space")
        base, ext = os.path.splitext(name)
        target, k = os.path.join(full_dir, name), 2
        while os.path.exists(target):                        # never overwrite: "name (2).pdf"
            target = os.path.join(full_dir, "%s (%d)%s" % (base, k, ext)); k += 1
        tmp = target + ".part"
        got = 0
        try:
            with open(tmp, "wb") as f:
                while got < length:
                    chunk = reader(min(1 << 20, length - got))
                    if not chunk:
                        raise BankError("upload was cut off")
                    f.write(chunk)
                    got += len(chunk)
            os.replace(tmp, target)
        finally:
            if os.path.exists(tmp):
                os.remove(tmp)
        return {"name": os.path.basename(target), "size": got}

    def mkdir(self, rel_dir, name):
        full_dir, _ = self._path(rel_dir)
        p = os.path.join(full_dir, self.clean_name(name))
        if os.path.exists(p):
            raise BankError("already exists")
        os.makedirs(p)
        return {"ok": True}

    def rename(self, rel, new):
        full, rel = self._path(rel)
        if not rel:
            raise BankError("can't rename the library itself")
        dst = os.path.join(os.path.dirname(full), self.clean_name(new))
        if os.path.exists(dst):
            raise BankError("a file with that name already exists")
        os.rename(full, dst)
        return {"ok": True}

    def delete(self, rel):
        full, rel = self._path(rel)
        if not rel:
            raise BankError("can't delete the library itself")
        if os.path.isdir(full):
            shutil.rmtree(full)
        else:
            os.remove(full)
        return {"ok": True}
