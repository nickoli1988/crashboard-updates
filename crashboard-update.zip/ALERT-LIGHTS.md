# Alert lights: flash an LED strip on alerts

Crash Board™ can make an IR-remote LED strip flash the alert colour: YELLOW, ORANGE or RED. It then stays that colour until things calm down. It does this through a small **Wi-Fi IR blaster**, a gadget that pretends to be the strip's remote.

It works with Crash Board on a Windows PC, on a Raspberry Pi, and on Crash Board Lite.

## 1. What to buy (about $6–15)

- **A Wemos D1 mini** (ESP8266) board.
- **An IR controller shield for the D1 mini**, which has IR LEDs and an IR receiver on it. You can also use a separate IR LED module (KY-005) plus an IR receiver module (KY-022 or VS1838B).
- **A USB power plug** for the D1 mini. Put it near the LED strip, with a clear view of the strip's IR sensor.

Your strip needs a small IR remote. The common 24-key remote (OFF/ON and R G B W buttons) works straight away. Any other IR remote works too, after you teach Crash Board its buttons (step 4).

## 2. Put Tasmota on it (about 5 minutes, from your browser)

1. Plug the D1 mini into your PC with a USB cable.
2. In **Chrome or Edge**, go to **https://tasmota.github.io/install/**.
3. Pick **Tasmota IR**, click **Connect**, choose the board's port, then click **Install Tasmota IR**.
4. When it asks, enter your Wi-Fi name and password. Use a 2.4 GHz network. The installer then shows the blaster's **IP address**. Write it down.

   *If it doesn't ask for Wi-Fi:* on your phone, join the Wi-Fi network called **tasmota-XXXX**, open **192.168.4.1**, and enter your Wi-Fi there.

## 3. Tell Tasmota which pins the IR parts use

1. On your PC, type the blaster's IP address into the browser.
2. Click **Configuration → Configure Module**.
3. Set **Module type** to **Generic (18)**, click **Save**, and wait for it to restart.
4. Back in **Configure Module**, look at the pin labels printed on your shield:
   - set the IR LED's pin to **IRsend**
   - set the receiver's pin to **IRrecv**

   On many D1 mini IR shields the LED is on **D3** (GPIO0) and the receiver on **D4** (GPIO2).
5. Click **Save**.
6. To check it works: click **Console**, point the strip's remote at the blaster and press a button. A line with **IrReceived** should appear.

**Tip:** in your router, reserve the blaster's IP address (the same "lock the IP" step we did for your PC) so it never changes.

## 4. Turn it on in Crash Board

Open **CFG** and scroll to **ALERT LIGHTS**:

1. Type the blaster's IP address into **IR BLASTER ADDRESS**.
2. Tick **FLASH MY LED STRIP ON ALERTS**. The line under the settings should say **✓ CONNECTED**.
3. Pick your remote:
   - **24-KEY REMOTE**: the codes are already built in.
   - **OTHER**: press **LEARN** next to each button (ON, OFF, RED, ORANGE, YELLOW, ALL CLEAR). Then point the strip's remote at the blaster and press the matching button within 25 seconds.

   You can also use LEARN on a 24-key remote if one colour looks wrong.
4. Choose **FLASH FOR** (which alert levels flash the strip) and **WHEN ALL CLEAR** (turn the strip off, switch it to your all-clear colour, or leave it).
5. Press the **TEST LIGHTS** buttons to try each level.

These settings save as soon as you change them.

### What the strip does

| Alert | Strip |
|---|---|
| YELLOW | turns yellow and blinks once, slowly |
| ORANGE | turns orange and blinks twice |
| RED | turns red and blinks 4 times, fast |
| Back to GREEN | whatever you chose under WHEN ALL CLEAR |

It won't flash the same level again within 45 seconds, so a burst of alerts doesn't strobe the house.

### Crash Board Lite

- **If the Lite shows your PC's or Pi's board:** set the lights up on that board, not on the Lite.
- **If the Lite runs on its own (standalone):** tap **PHONE SETUP** on the Lite and fill in **ALERT LIGHTS** with the blaster's address. If you're staying on the same Wi-Fi, you can leave the password blank. The Lite uses the 24-key remote codes.
