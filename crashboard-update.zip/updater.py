"""
CRASH BOARD(TM) updater - new versions with no typing.

Three ways a board gets an update, all checked against LL3D's signature (the same public key as PRO
keys), so nobody else can push software to your board:
  1. Online: about once a day the board looks at UPDATE_URL (a small JSON file LL3D publishes, e.g. on
     GitHub Releases). Newer + correctly signed -> downloaded and installed, then the board restarts.
  2. CFG > SOFTWARE > CHECK FOR UPDATES / INSTALL UPDATE (same thing, on demand).
  3. USB: put <edition>-update.zip and <edition>-update.json (made by the seller tool) on a USB stick and
     plug it in. The board finds it within ~20 seconds, installs it and restarts. No internet needed.

Your settings (the data folder) are never touched. Self-restart needs the board to run as a service
(Raspberry Pi installs do); on Windows the board just says a new version is ready.
"""
import hashlib
import json
import os
import shutil
import tempfile
import threading
import time
import urllib.parse
import urllib.request
import zipfile

# Where this edition's update manifest lives. Set with:  python keygen.py set-update-url <url> <app folders>
UPDATE_URL = "https://raw.githubusercontent.com/nickoli1988/crashboard-updates/main/crashboard-update.json"

SKIP = ("data/", "data\\", "__pycache__", ".secret", "dist/", "build/", ".git/")


def _vt(v):
    out = []
    for part in str(v).replace("-", ".").split("."):
        out.append(int(part) if part.isdigit() else 0)
    return tuple(out + [0] * (4 - len(out)))


def sig_message(edition, version, sha):
    return ("CBUPDATE|%s|%s|%s" % (edition, version, sha)).encode()


class Updater:
    def __init__(self, base, data_dir, edition, version, public_hex, verify, log=print, can_restart=None):
        self.base, self.data, self.edition, self.version = base, data_dir, edition, version
        self.public_hex, self.verify, self.log = public_hex, verify, log
        self.can_restart = bool(os.environ.get("INVOCATION_ID")) if can_restart is None else can_restart   # systemd sets this
        self.restart_hook = None         # phone app: relaunches the app so the new version loads (set by app_main.py)
        self.state_path = os.path.join(data_dir, "update-state.json")
        self.lock = threading.Lock()
        self.available = None            # manifest of a newer signed version (online)
        self.busy, self.msg, self.error, self.checked = False, "", "", 0
        try:
            self.st = json.load(open(self.state_path))
        except Exception:
            self.st = {}
        if self.st.get("installed_version") == version and self.st.get("installed_at", 0) > time.time() - 600:
            self.msg = "Updated to v%s" % version

    # ---------------------------------------------------------------- checks
    def _valid(self, man):
        try:
            if man.get("edition") != self.edition:
                return False
            return self.verify(bytes.fromhex(self.public_hex), sig_message(man["edition"], man["version"], man["sha256"]),
                               bytes.fromhex(man["sig"]))
        except Exception:
            return False

    def check_online(self, timeout=20):
        if not UPDATE_URL:
            self.error = ""
            return None
        try:
            req = urllib.request.Request(UPDATE_URL, headers={"User-Agent": "CrashBoard-updater", "Cache-Control": "no-cache"})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                man = json.loads(r.read().decode())
        except Exception as e:
            self.error = "couldn't reach the update server (%s)" % str(e)[:60]
            self.checked = time.time()
            return None
        self.checked = time.time()
        if not self._valid(man):
            self.error = "update file ignored (signature not valid)"
            return None
        self.error = ""
        if _vt(man["version"]) > _vt(self.version):
            man["zip_url"] = urllib.parse.urljoin(UPDATE_URL, man.get("url") or "%s-update.zip" % self.edition)
            self.available = man
            return man
        self.available = None
        return None

    # ---------------------------------------------------------------- install
    def install_online(self):
        man = self.available or self.check_online()
        if not man:
            raise ValueError("No newer version available.")
        tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".zip", dir=self.data)
        tmp.close()
        try:
            self.msg = "Downloading v%s…" % man["version"]
            req = urllib.request.Request(man["zip_url"], headers={"User-Agent": "CrashBoard-updater"})
            with urllib.request.urlopen(req, timeout=120) as r, open(tmp.name, "wb") as f:
                shutil.copyfileobj(r, f)
            return self.install_zip(tmp.name, man)
        finally:
            try:
                os.remove(tmp.name)
            except Exception:
                pass

    def install_zip(self, path, man):
        """Verify a downloaded/USB zip against its signed manifest, copy it over the app (keeping data/), restart."""
        with self.lock:
            if self.busy:
                raise ValueError("An update is already being installed.")
            self.busy = True
        try:
            if not self._valid(man):
                raise ValueError("Update rejected: not signed by LL3D.")
            h = hashlib.sha256()
            with open(path, "rb") as f:
                for chunk in iter(lambda: f.read(1 << 16), b""):
                    h.update(chunk)
            if h.hexdigest() != man["sha256"]:
                raise ValueError("Update rejected: file is damaged or was changed.")
            self.msg = "Installing v%s…" % man["version"]
            stage = tempfile.mkdtemp(dir=self.data, prefix="update-")
            try:
                with zipfile.ZipFile(path) as z:
                    for info in z.infolist():
                        n = info.filename.replace("\\", "/")
                        if n.startswith("/") or ".." in n.split("/") or any(s in n for s in SKIP):
                            continue
                        z.extract(info, stage)
                        mode = (info.external_attr >> 16) & 0o777
                        if mode and not info.is_dir():
                            os.chmod(os.path.join(stage, n), mode)
                for root, dirs, files in os.walk(stage):
                    rel = os.path.relpath(root, stage)
                    dst_dir = os.path.normpath(os.path.join(self.base, rel))
                    os.makedirs(dst_dir, exist_ok=True)
                    for fn in files:
                        src, dst = os.path.join(root, fn), os.path.join(dst_dir, fn)
                        shutil.copy2(src, dst + ".new")
                        os.replace(dst + ".new", dst)
            finally:
                shutil.rmtree(stage, ignore_errors=True)
            self.st.update({"installed_version": man["version"], "installed_sha": man["sha256"], "installed_at": time.time()})
            json.dump(self.st, open(self.state_path, "w"))
            self.log("update: installed v%s" % man["version"])
            if self.can_restart:
                self.msg = "Installed v%s - restarting…" % man["version"]
                threading.Timer(2.0, lambda: os._exit(0)).start()      # the service brings the board straight back
            elif self.restart_hook:
                self.msg = "Installed v%s - restarting the app…" % man["version"]
                threading.Timer(2.0, self.restart_hook).start()        # phone app reopens itself on the new version
            else:
                self.msg = "Installed v%s - close and reopen Crash Board to finish." % man["version"]
            self.available = None
            return man["version"]
        finally:
            self.busy = False

    # ---------------------------------------------------------------- USB stick
    def usb_scan(self):
        if os.environ.get("CRASHBOARD_APP") == "1":
            return                                         # phones have no USB drive to look at
        name = "%s-update" % self.edition
        roots = []
        for top in ("/media", "/mnt", "/run/media"):
            if os.path.isdir(top):
                for a in os.listdir(top):
                    p = os.path.join(top, a)
                    roots.append(p)
                    if os.path.isdir(p):
                        roots += [os.path.join(p, b) for b in os.listdir(p)]
        for r in roots:
            mj, mz = os.path.join(r, name + ".json"), os.path.join(r, name + ".zip")
            if os.path.isfile(mj) and os.path.isfile(mz):
                try:
                    man = json.load(open(mj))
                except Exception:
                    continue
                if not self._valid(man) or man.get("sha256") == self.st.get("installed_sha"):
                    continue
                if _vt(man["version"]) < _vt(self.version):
                    continue                                     # never go backwards
                if _vt(man["version"]) == _vt(self.version) and man.get("sha256") == self.st.get("installed_sha"):
                    continue
                self.log("update: found v%s on a USB drive (%s)" % (man["version"], r))
                self.msg = "Updating from USB drive…"
                try:
                    self.install_zip(mz, man)
                except Exception as e:
                    self.error = str(e)
                    self.log("update: USB install failed:", e)
                return

    def loop(self, auto, quiet_ok):
        """Background: USB every 20 s; online once a day (installs by itself when auto() is on and quiet_ok())."""
        time.sleep(40)
        last_online = 0
        while True:
            try:
                self.usb_scan()
                if UPDATE_URL and time.time() - last_online > 86400:
                    last_online = time.time()
                    if self.check_online() and auto() and quiet_ok() and self.can_restart:
                        self.install_online()
            except Exception as e:
                self.error = str(e)[:120]
                self.log("update:", e)
            time.sleep(20)

    def info(self):
        a = self.available or {}
        return {"version": self.version, "available": a.get("version"), "notes": a.get("notes", ""),
                "busy": self.busy, "msg": self.msg, "error": self.error, "configured": bool(UPDATE_URL),
                "can_restart": self.can_restart or bool(self.restart_hook), "checked": self.checked,
                "phone": bool(self.restart_hook)}
