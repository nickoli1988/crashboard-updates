#!/bin/bash
# CRASH BOARD first-boot setup.
# make-sd-card.bat copies this onto a freshly flashed Raspberry Pi OS card. It then runs by itself:
#   setup.sh stage [now]   called once by Raspberry Pi OS's own first-boot step (firstrun.sh or cloud-init)
#   setup.sh run           called by crashboard-setup.service once Wi-Fi is up; installs, then reboots
# Progress shows on the Pi's screen. The full log is crashboard-setup/install.log on the SD card,
# so you can read it on your PC if something goes wrong.
set -u
SELF="$(readlink -f "$0")"
DIR="$(dirname "$SELF")"
LOG="$DIR/install.log"
ETC="${CB_TEST_ETC:-/etc}"            # tests point this somewhere harmless
UNIT="$ETC/systemd/system/crashboard-setup.service"
SUDOERS="$ETC/sudoers.d/099-crashboard-setup"
APTCONF="$ETC/apt/apt.conf.d/99-crashboard-setup"

say() {   # to the log and to the attached screen
  echo "$*" >> "$LOG"
  { printf '%s\n' "$*" > /dev/tty1; } 2>/dev/null || true
}

setting() {   # setting NAME default   (reads settings.txt; Windows line endings are fine)
  local v
  v="$(tr -d '\r' < "$DIR/settings.txt" 2>/dev/null | grep -E "^[[:space:]]*$1[[:space:]]*=" | tail -n 1 | cut -d= -f2- |
       sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//')"
  echo "${v:-$2}"
}

stage() {
  cat > "$UNIT" <<EOF
[Unit]
Description=Crash Board first-boot setup
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=/bin/bash $SELF run
TimeoutStartSec=0

[Install]
WantedBy=multi-user.target
EOF
  systemctl enable crashboard-setup.service >> "$LOG" 2>&1
  echo "$(date): staged" >> "$LOG"
  if [ "${1:-}" = now ]; then systemctl start --no-block crashboard-setup.service; fi
}

cleanup_temp() { rm -f "$SUDOERS" "$APTCONF"; }

run() {
  { printf '\033c' > /dev/tty1; } 2>/dev/null || true
  say "=============================================="
  say "  CRASH BOARD SETUP  -  $(date '+%Y-%m-%d %H:%M')"
  say "  This takes 20-40 minutes on a Pi Zero W."
  say "  Leave it plugged in. It restarts by itself."
  say "=============================================="

  local U APP_SRC NAME HOME_DIR MODE ARGS rc n=0
  U="$(getent passwd 1000 | cut -d: -f1)"
  if [ -z "$U" ]; then say "ERROR: no user account on this card. Set a username in Raspberry Pi Imager and flash again."; exit 1; fi
  APP_SRC="$(ls -d "$DIR"/crashboard*/ 2>/dev/null | head -n 1)"; APP_SRC="${APP_SRC%/}"
  if [ -z "$APP_SRC" ] || [ ! -f "$APP_SRC/server.py" ]; then
    if [ -f "$DIR/DONE.txt" ]; then systemctl disable crashboard-setup.service; exit 0; fi
    say "ERROR: Crash Board files are missing from the card. Run make-sd-card.bat again."; exit 1
  fi
  NAME="$(basename "$APP_SRC")"
  HOME_DIR="$(getent passwd "$U" | cut -d: -f6)"

  say "[1/4] Waiting for internet..."
  until getent hosts archive.raspberrypi.com >/dev/null 2>&1; do
    n=$((n + 1))
    if [ $((n % 10)) -eq 0 ]; then
      say "      Still no internet. Check the Wi-Fi name and password you typed in Raspberry Pi Imager."
      say "      The Pi Zero W only sees 2.4 GHz Wi-Fi (not 5 GHz)."
    fi
    sleep 6
  done
  say "      Online."

  say "[2/4] Copying Crash Board to $HOME_DIR/$NAME"
  mkdir -p "$HOME_DIR/$NAME"
  cp -r "$APP_SRC/." "$HOME_DIR/$NAME/"
  chown -R "$U":"$U" "$HOME_DIR/$NAME"

  # temporary: let the installer use sudo without a password, and wait for apt instead of failing
  echo "$U ALL=(ALL) NOPASSWD:ALL" > "$SUDOERS"; chmod 440 "$SUDOERS"
  echo 'DPkg::Lock::Timeout "900";' > "$APTCONF"

  MODE="$(setting MODE appliance | tr 'A-Z' 'a-z')"
  if [ "$MODE" = appliance ] && [ -f "$HOME_DIR/$NAME/setup/image-setup.sh" ]; then
    say "[3/4] Installing (phone-setup mode). Downloading the screen software is the slow part..."
    CB_USER="$U" bash "$HOME_DIR/$NAME/setup/image-setup.sh" < /dev/null >> "$LOG" 2>&1
    rc=$?
    if [ $rc -ne 0 ]; then
      say "SETUP FAILED (code $rc). It will try again next time the Pi starts."
      say "Details: open the SD card on your PC -> crashboard-setup -> install.log"
      cleanup_temp; exit 1
    fi
    say "[4/4] Location and language are set from your phone after the restart."
    finish
  fi
  case "$MODE" in
    host)    ARGS="" ;;
    display) ARGS="--display $(setting DISPLAY_HOST '')" ;;
    *)       ARGS="--kiosk"; MODE=kiosk ;;
  esac
  if [ "$MODE" = display ] && ! grep -q -- "--display" "$HOME_DIR/$NAME/install.sh"; then ARGS="--kiosk"; MODE=kiosk; fi

  say "[3/4] Installing ($MODE). Downloading the screen software is the slow part..."
  runuser -l "$U" -c "cd ~/$NAME && bash ./install.sh $ARGS" < /dev/null >> "$LOG" 2>&1
  rc=$?
  if [ $rc -ne 0 ]; then
    say "SETUP FAILED (code $rc). It will try again next time the Pi starts."
    say "Details: open the SD card on your PC -> crashboard-setup -> install.log"
    cleanup_temp; exit 1
  fi

  if [ "$MODE" != display ]; then
    say "[4/4] Applying your settings..."
    CB_DIR="$HOME_DIR/$NAME" CB_LOC="$(setting LOCATION '')" CB_CC="$(setting COUNTRY '')" \
    CB_UNITS="$(setting UNITS '')" CB_LANG="$(setting LANGUAGE '')" CB_CALL="$(setting CALLSIGN '')" \
    python3 - >> "$LOG" 2>&1 <<'PY'
import json, os, time, urllib.request
d = os.environ["CB_DIR"]
port = "8090" if d.rstrip("/").endswith("mesh") else "8080"
try: port = open(os.path.join(d, "data", "port.txt")).read().strip() or port
except OSError: pass
body = {}
if os.environ["CB_LOC"]: body["location"] = os.environ["CB_LOC"]; body["country"] = os.environ["CB_CC"].upper() or "AUTO"
if os.environ["CB_UNITS"].lower() in ("imperial", "metric"): body["units"] = os.environ["CB_UNITS"].lower()
if os.environ["CB_LANG"].lower() in ("en", "es", "fr", "de", "pt"): body["lang"] = os.environ["CB_LANG"].lower()
if os.environ["CB_CALL"]: body["callsign"] = os.environ["CB_CALL"][:24]
if not body: print("no settings to apply"); raise SystemExit
url = "http://127.0.0.1:%s/api/settings" % port
for i in range(40):
    try:
        req = urllib.request.Request(url, data=json.dumps(body).encode(), headers={"Content-Type": "application/json"})
        print("settings:", urllib.request.urlopen(req, timeout=60).read()[:200]); break
    except urllib.error.HTTPError as e:
        print("settings refused:", e.code, e.read()[:200]); break
    except Exception as e:
        time.sleep(3)
else:
    print("board did not answer; set your location from CFG instead")
PY
  fi

  finish
}

finish() {
  cleanup_temp
  systemctl disable crashboard-setup.service >> "$LOG" 2>&1
  rm -f "$UNIT"
  rm -rf "$APP_SRC"                      # the copy on the card is no longer needed
  date > "$DIR/DONE.txt"
  say ""
  say "DONE. Restarting into Crash Board..."
  sleep 8
  systemctl reboot
  exit 0
}

case "${1:-}" in
  stage) stage "${2:-}" ;;
  run)   run ;;
  *)     echo "usage: setup.sh stage [now] | run"; exit 1 ;;
esac
