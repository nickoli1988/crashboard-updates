# CRASH BOARD - make a microSD card that sets itself up on first boot.
# Start it with make-sd-card.bat (double-click). Works with Windows PowerShell 5.1 and PowerShell 7.
$ErrorActionPreference = "Stop"
$utf8 = New-Object System.Text.UTF8Encoding($false)

function Say($t, $c) { if ($c) { Write-Host $t -ForegroundColor $c } else { Write-Host $t } }
function Fail($t) { Say ""; Say "  $t" Red; Say ""; if (-not $env:CB_NONINTERACTIVE) { Read-Host "Press Enter to close" | Out-Null }; exit 1 }
function Ask($q, $def) {
  if ($env:CB_NONINTERACTIVE) { return $def }
  $a = Read-Host $q
  if ([string]::IsNullOrWhiteSpace($a)) { return $def } else { return $a.Trim() }
}
function ReadText($p) { return [System.IO.File]::ReadAllText($p) }
function WriteText($p, $t) { [System.IO.File]::WriteAllText($p, ($t -replace "`r`n", "`n"), $utf8) }

Say ""
Say "  ===========================================" Yellow
Say "   CRASH BOARD  -  SD CARD MAKER" Yellow
Say "  ===========================================" Yellow
Say ""

# ---- the Crash Board folder this script lives in
$app = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
if (-not (Test-Path (Join-Path $app "server.py"))) { Fail "Can't find Crash Board next to this script. Keep make-sd-card.bat inside the crashboard folder." }
$name = Split-Path $app -Leaf
if ($name -notlike "crashboard*") { $name = "crashboard" }
$isMesh = (Split-Path $app -Leaf) -like "*mesh*"     # legacy Mesh folder only
if ($isMesh -and $name -notlike "*mesh*") { $name = "crashboard-mesh" }

# ---- find the card's boot drive (it has cmdline.txt and config.txt)
if ($env:CB_BOOT) { $drives = @($env:CB_BOOT) }
else {
  $drives = @(Get-PSDrive -PSProvider FileSystem | ForEach-Object { $_.Root } |
    Where-Object { (Test-Path (Join-Path $_ "cmdline.txt")) -and (Test-Path (Join-Path $_ "config.txt")) })
}
if ($drives.Count -eq 0) {
  Fail ("No Raspberry Pi SD card found.`n  1. Flash it with Raspberry Pi Imager (fill in username, password and Wi-Fi in its settings).`n" +
        "  2. Take the card out and put it back in, then run this again.")
}
$boot = $drives[0]
if ($drives.Count -gt 1) {
  Say "  More than one Raspberry Pi card is plugged in:"
  for ($i = 0; $i -lt $drives.Count; $i++) { Say ("   {0}. {1}" -f ($i + 1), $drives[$i]) }
  $pick = [int](Ask "  Which one? Type the number" "1")
  $boot = $drives[$pick - 1]
}
Say "  SD card found: $boot" Green

# ---- which first-boot system does this card use?
$userData = Join-Path $boot "user-data"
$firstrun = Join-Path $boot "firstrun.sh"
$hook = $null
if (Test-Path $userData) { $hook = "cloud-init" } elseif (Test-Path $firstrun) { $hook = "firstrun" }
if (-not $hook) {
  Fail ("This card has no Imager settings (username / Wi-Fi), so it couldn't get online by itself.`n" +
        "  In Raspberry Pi Imager, click EDIT SETTINGS (or 'Customisation'), fill in a username, password and your Wi-Fi, then flash again.")
}
if ($hook -eq "cloud-init") {
  $nc = Join-Path $boot "network-config"
  if (-not ((Test-Path $nc) -and ((ReadText $nc) -match "(?m)^\s*wifis:"))) {
    Say "  WARNING: I don't see Wi-Fi settings on this card. Without Wi-Fi the Pi Zero W can't finish setup." Yellow
    if ((Ask "  Continue anyway? (y/N)" "n") -notmatch "^[yY]") { Fail "Stopped. Add your Wi-Fi in Raspberry Pi Imager's settings and flash again." }
  }
}

# ---- a few questions (all can be changed later from CFG)
Say ""
Say "  How will this Pi be used?"
Say "   1. Own screen + phone setup, same as the SD-card image  (recommended)"
Say "   2. Own screen, answer the setup questions here instead"
Say "   3. No screen. Other phones and PCs view it over Wi-Fi"
if (-not $isMesh) { Say "   4. It's only a screen for a Crash Board running on another device" }
$m = Ask "  Type a number and press Enter [1]" "1"
$mode = "appliance"; $displayHost = ""
if ($m -eq "2") { $mode = "kiosk" }
if ($m -eq "3") { $mode = "host" }
if ($m -eq "4" -and -not $isMesh) {
  $mode = "display"
  $displayHost = Ask "  Address of the device running Crash Board (e.g. 192.168.1.40)" ""
  if (-not $displayHost) { Fail "A display needs the other device's address. Run this again when you have it." }
}
$loc = ""; $units = "imperial"; $lang = "en"
if ($mode -ne "appliance") {          # appliance mode asks these on the phone instead
  $loc = Ask "  Your ZIP / postcode or city (Enter to skip, set it later in CFG)" ""
  $u = Ask "  Units: 1 = imperial (F, mph), 2 = metric (C, km/h) [1]" "1"
  if ($u -eq "2") { $units = "metric" }
  $langs = @{ "1" = "en"; "2" = "es"; "3" = "fr"; "4" = "de"; "5" = "pt" }
  $l = Ask "  Language: 1 English, 2 Espanol, 3 Francais, 4 Deutsch, 5 Portugues [1]" "1"
  $lang = $langs[$l]; if (-not $lang) { $lang = "en" }
}

# ---- copy everything onto the card
$dest = Join-Path $boot "crashboard-setup"
Say ""
Say "  Copying Crash Board onto the card..."
if (Test-Path $dest) { Remove-Item -Recurse -Force $dest }
New-Item -ItemType Directory -Path $dest | Out-Null
$appDest = Join-Path $dest $name
New-Item -ItemType Directory -Path $appDest | Out-Null
$skipDirs = @("data", "sdcard", "tests", "__pycache__", ".git")
Get-ChildItem -Force $app | Where-Object { $skipDirs -notcontains $_.Name -and $_.Name -notlike "*android*" -and $_.Name -notlike "*.secret" } |
  ForEach-Object { Copy-Item -Recurse -Force $_.FullName $appDest }
Get-ChildItem -Recurse -Force $appDest | Where-Object { $_.Name -eq "__pycache__" -or $_.Name -like "*.secret" } |
  Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
Copy-Item -Force (Join-Path $PSScriptRoot "setup.sh") (Join-Path $dest "setup.sh")

$settings = @"
# CRASH BOARD first-boot settings. You can edit this file on the SD card before the first boot.
# MODE: appliance (own screen + phone setup), kiosk (own screen), host (no screen), display (screen for another Crash Board)
MODE=$mode
DISPLAY_HOST=$displayHost
# LOCATION: ZIP / postcode, "City, ST", or "lat, lon". Leave empty to set it later in CFG.
LOCATION=$loc
# COUNTRY: leave empty for automatic, or US, CA, GB, AU, NZ, DE, FR ...
COUNTRY=
UNITS=$units
# LANGUAGE: en, es, fr, de, pt
LANGUAGE=$lang
CALLSIGN=
"@
WriteText (Join-Path $dest "settings.txt") ($settings + "`n")

# ---- hook into Raspberry Pi OS's own first-boot step
if ($hook -eq "cloud-init") {
  $t = (ReadText $userData) -replace "`r`n", "`n"
  if ($t -notmatch "crashboard-setup") {
    $item = "- [ bash, /boot/firmware/crashboard-setup/setup.sh, stage, now ]"
    $mm = [regex]::Match($t, "(?m)^runcmd:[ \t]*\n(?<ind>[ \t]*)-")
    if ($mm.Success) {
      $ind = $mm.Groups["ind"].Value
      $at = $t.IndexOf("`n", $mm.Index) + 1
      $t = $t.Insert($at, "$ind$item`n")
    } elseif ($t -match "(?m)^runcmd:[ \t]*\[[ \t]*\][ \t]*$") {
      $t = [regex]::Replace($t, "(?m)^runcmd:[ \t]*\[[ \t]*\][ \t]*$", "runcmd:`n  $item")
    } elseif ($t -match "(?m)^runcmd:") {
      Fail "This card's user-data has a runcmd section I don't recognise. Send Claude a copy of the user-data file from the card."
    } else {
      if (-not $t.EndsWith("`n")) { $t += "`n" }
      $t += "`n# Crash Board: install on first boot`nruncmd:`n  $item`n"
    }
    WriteText $userData $t
  }
} else {
  $t = (ReadText $firstrun) -replace "`r`n", "`n"
  if ($t -notmatch "crashboard-setup") {
    $line = "for d in /boot/firmware /boot; do if [ -f `$d/crashboard-setup/setup.sh ]; then bash `$d/crashboard-setup/setup.sh stage; break; fi; done"
    $mm = [regex]::Match($t, "(?m)^rm -f [^\n]*firstrun\.sh")
    if (-not $mm.Success) { $mm = [regex]::Match($t, "(?m)^exit 0[ \t]*$") }
    if ($mm.Success) { $t = $t.Insert($mm.Index, "$line`n") }
    else { if (-not $t.EndsWith("`n")) { $t += "`n" }; $t += "$line`n" }
    WriteText $firstrun $t
  }
}

Say ""
Say "  READY." Green
Say "  1. Eject the card (right-click the drive in File Explorer > Eject)."
Say "  2. Put it in the Pi Zero W, connect the screen, then plug in power."
Say "  3. Setup runs by itself: 20-40 minutes. The screen shows progress, then the Pi restarts."
if ($mode -eq "appliance") { Say "  4. After the restart, the screen shows a QR code. Scan it with your phone to finish setup." }
Say "  If it gets stuck, put the card back in your PC and open crashboard-setup\install.log."
Say ""
if (-not $env:CB_NONINTERACTIVE) { Read-Host "Press Enter to close" | Out-Null }
