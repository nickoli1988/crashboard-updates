# Crash Board™ radio

The **RADIO** page (the button next to CFG, or `http://<board>/radio.html` on any phone or PC) does two jobs:

- **Listen:** FM, AM and NOAA Weather Radio, played in your browser. You can save stations as presets.
- **NOAA alert watch:** Crash Board decodes the digital header (SAME) at the start of every National Weather Service warning broadcast on NOAA Weather Radio. A warning for your county turns the board **ORANGE or RED**, sounds the alarm and flashes the alert lights. **No internet is needed.**

It works on the **Windows PC** and on a **Raspberry Pi 4 or 5**. A Pi Zero is too slow to run both the radio and the board. Crash Board Lite can't take a USB stick, but it still shows radio warnings when it's linked to a PC or Pi that has the stick.

## What to buy

| Item | Why | About |
|---|---|---|
| **RTL-SDR Blog V4 with the dipole antenna kit** | The radio stick and an antenna that covers FM and NOAA. Get the genuine RTL-SDR Blog one, not a no-name copy. | $55 (stick only: $45) |
| *Optional:* a **second RTL-SDR Blog V4** (stick only) | One stick watches NOAA all the time while the other plays music or news. | $45 |
| *Optional:* a USB extension cable (1–2 m) | Lets you put the antenna near a window, away from the computer's electrical noise. | $8 |
| *Optional for AM:* 5–10 m of any wire | A long wire antenna for AM stations. The short telescoping antennas can barely hear AM. | $5 |

Buy it from the official store at **rtl-sdr.com/buy**, or search Amazon for "**RTL-SDR Blog V4 dipole**" and make sure the seller is RTL-SDR Blog.

**Antenna tips:** for NOAA, pull each half of the dipole out to about **46 cm (18")** and stand it up vertically. For FM, extend it fully. The higher it is and the closer to a window, the better.

## Set it up from the RADIO page (no typing)

1. Plug the stick into a USB port directly on the computer, not a hub.
2. Open **RADIO**. If radio support isn't installed yet, the top box shows a button.
3. Press it:
   - **Raspberry Pi: INSTALL RADIO SUPPORT.** The board downloads and installs the drivers by itself (needs internet, 1–5 minutes; an RTL-SDR Blog V4 takes the longest). If it then asks, press **RESTART THE PI**. The board comes back by itself in about a minute.
   - **Windows PC: INSTALL RADIO TOOLS.** The board downloads the tools and opens **Zadig**. Click **Yes** when Windows asks. In Zadig, click **Options → List All Devices**, pick **Bulk-In, Interface (Interface 0)**, make sure the box on the right says **WinUSB**, and click **Replace Driver**. Then press **RE-DETECT** on the RADIO page.
4. Tick **USE THE SDR STICK ON THIS BOARD**.

**Pi boards installed before this button existed:** the page asks for a one-time step. Open the Crash Board folder on the Pi, double-click **Install Crash Board.sh** and choose **Execute in Terminal**. When it says DONE, the button works. You only do this once; after that, everything is done from the board.

## Using it

- **Stations:** tap a preset to listen and tap **STOP** to end. To add one, type the frequency, pick **FM**, **AM** or **NOAA**, add a name, and press **+ SAVE**.
- **NOAA channel:** press **FIND STRONGEST**, which scans all 7 NOAA channels and picks the best. You can also look up your local transmitter at weather.gov/nwr.
- **One stick:** NOAA watch pauses while you listen to a different station. Internet alerts keep working, and watch resumes as soon as you stop, or 20 seconds after the last listener closes the page. Listening to NOAA itself doesn't interrupt the watch.
- **Two sticks:** the first stick watches NOAA nonstop, and the second is used for listening.
- **County matching:** warnings only count for your county. Crash Board gets your county code from the location set in CFG. Until it knows your county, every warning on your channel counts.
- **Tests:** weekly and monthly tests (RWT and RMT) show up in the list but never sound the alarm.
